// Apex champion logic: farm camp groups efficiently, bank gems at altars, shop on spawn,
// and take good fights while avoiding bad ones.
#include "bot.h"
#include "neural_policy.h"
#include "economic_cycle.h"
#if A2_MLPLAN
#include "ml_plan.h"
#endif
#include "strategy.h"
#include "fight.h"
#include "learner.h"
#if A2_LAB
#include <algorithm>
#include <cmath>
#include "lab.h"
#endif
#if A2_ASSESS
#include <cmath>
#include "assess_model.h"
#endif
#include "runtime_budget.h"
#include "tsearch.h"
#include "a2map.h"

#include <span>
#include <string_view>
#include <tuple>
#include <variant>

namespace d = cambc::detail;

int nova_map_id(int w, int h, unsigned size, int groups); // draft.cpp: official map index, -1 = unseen
float a2_gem_density(); // draft.cpp: camp gems per tile, -1 = unreadable

namespace {

bc::bitboard single(vec2 p) {
    bc::bitboard b;
    b.clear();
    b.set(p, true);
    return b;
}

bool in_bounds(vec2 p, int w, int h) { return p.x >= 0 && p.y >= 0 && p.x < w && p.y < h; }

// Shards a champion keeps buying, in order, with the total count wanted of each.
struct BuildStep {
    bc::item_type item;
    int total;
};

// Disconnected maps need the original farming build: defensive purchases slow
// the resource race there. Set once, before any champion shops.
bool mobility_farming_map = false;

std::vector<BuildStep> build_for(bc::champion_type t) {
    using it = bc::item_type;
#if A3_ITEMS
    {
        // A3_ITEMS: earlier combat stats. Power counts 6 shards for 5 bought and Bruiser adds one of each other stat, so
        // the second and third emblems turn gold into fighting stats ~20% faster than Monster / Capture / Collectors.
        // 1: top-team opening (Treasure, Jungle, Bruiser, Power); 2: keep v61's Prospector opener, then Jungle, Power, Bruiser.
        using ct = bc::champion_type;
        const bool caster = t == ct::cassi || t == ct::stellar || t == ct::prism || t == ct::willow || t == ct::marcella;
        const bool hor = t == ct::heart_of_ruin, ryth = t == ct::ryth;
        const it treasure = caster || hor ? it::treasure_shard_of_focus : ryth ? it::treasure_shard_of_health : it::treasure_shard_of_strength;
        const it prospector = t == ct::vesper_vale || t == ct::tavi ? it::prospector_shard_of_strength
                            : caster ? it::prospector_shard_of_focus : it::prospector_shard_of_health;
        const it power = caster || hor ? it::power_shard_of_focus : ryth ? it::power_shard_of_health : it::power_shard_of_strength;
        const it jungle = caster ? it::jungle_shard_of_health : it::jungle_shard_of_strength;
        const it greed_main = caster || hor ? it::greed_shard_of_focus : ryth ? it::greed_shard_of_health : it::greed_shard_of_strength;
        std::vector<BuildStep> plan;
        if (A3_ITEMS == 1) plan.push_back({treasure, 5});
        else plan.push_back({prospector, 5});
        plan.push_back({jungle, 5});
        if (A3_ITEMS == 1) {
            plan.push_back({it::bruiser_shard_of_health, 5});
            plan.push_back({power, 5});
        } else {
            plan.push_back({power, 5});
            plan.push_back({it::bruiser_shard_of_health, 5});
        }
        plan.push_back({it::durability_shard_of_health, 5});
        plan.push_back({power, 10});
        plan.push_back({caster || hor ? it::capture_shard_of_health : it::capture_shard_of_strength, 5});
        plan.push_back({power, 15});
        for (int n : {25, 50, 75}) {
            plan.push_back({greed_main, n});
            plan.push_back({it::greed_shard_of_health, n});
        }
        return plan;
    }
#endif
#if V58_ITEM_PLAN
    // Same-stat Prospector replaces the nerfed Treasure opening. Capture follows survival purchases;
    // late Greed is bought in full25-shard milestones, with mixed health/offense before another stack.
    using ct = bc::champion_type;
    const bool focus_user = t == ct::cassi || t == ct::stellar || t == ct::prism || t == ct::willow || t == ct::marcella;
    const bool tank = t == ct::heart_of_ruin;
    const it main = focus_user ? it::greed_shard_of_focus : it::greed_shard_of_strength;
    std::vector<BuildStep> plan;
    if (t == ct::marcella) {
        plan = {{it::jungle_shard_of_strength,5}, {it::prospector_shard_of_focus,5},
            {it::durability_shard_of_health,5}, {it::monster_shard_of_focus,5},
            {it::capture_shard_of_health,5}, {it::bruiser_shard_of_health,5}, {it::bruiser_shard_of_strength,5}};
    } else if (tank) {
        plan = {{it::prospector_shard_of_health,5}, {it::jungle_shard_of_focus,5},
            {it::durability_shard_of_health,5}, {it::capture_shard_of_health,5},
            {it::monster_shard_of_focus,5}, {it::bruiser_shard_of_focus,5}, {it::bruiser_shard_of_strength,5}};
    } else if (focus_user) {
        if (t == ct::prism) plan.push_back({it::durability_shard_of_health,5});
        plan.push_back({it::prospector_shard_of_focus,5});
        if (t != ct::prism) plan.push_back({it::durability_shard_of_health,5});
        plan.push_back({it::monster_shard_of_focus,5});
        plan.push_back({it::capture_shard_of_health,5});
    } else {
        plan = {{t == ct::vesper_vale || t == ct::tavi ? it::prospector_shard_of_strength : it::prospector_shard_of_health,5}};
        if (t != ct::tavi) plan.push_back({it::jungle_shard_of_strength,5});
        plan.push_back({it::durability_shard_of_health,5});
        plan.push_back({it::monster_shard_of_strength,5});
        plan.push_back({it::capture_shard_of_strength,5});
    }
    plan.push_back({focus_user || tank ? it::collectors_shard_of_focus : it::collectors_shard_of_strength,5});
    if (tank) {
        for (int n : {25,50,75}) {
            plan.push_back({it::greed_shard_of_health,n});
            plan.push_back({it::greed_shard_of_focus,n});
        }
    } else {
        for (int n : {25,50,75}) {
            plan.push_back({main,n});
            plan.push_back({it::greed_shard_of_health,n});
        }
    }
    return plan;
#endif
#if A2_LAB
    {
        // Engine lab build table (lab.h builds): a type with steps uses them instead of the presets below.
        const int ti = static_cast<int>(t);
        if (ti >= 0 && ti < 16 && lab::builds[ti * lab::kBuildSlot] > 0 && !mobility_farming_map) { // split terrain keeps the original build
            std::vector<BuildStep> v;
            const std::int32_t* b = lab::builds + ti * lab::kBuildSlot;
            for (int k = 0; k < b[0] && k < 8; ++k) v.push_back({it{static_cast<std::uint32_t>(b[1 + 2 * k])}, b[2 + 2 * k]});
            return v;
        }
    }
#endif
#if V58_KIT_MARCELLA
    if (t == bc::champion_type::marcella)
#if V58_KIT_MARCELLA >= 2
        // Observed top-team order: camp mitigation/attack, general mitigation, then a balanced support stat core.
        return {{it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::bruiser_shard_of_focus, 5}, {it::bruiser_shard_of_health, 5}, {it::bruiser_shard_of_strength, 5},
            {it::bruiser_shard_of_focus, 60}, {it::bruiser_shard_of_health, 60}, {it::bruiser_shard_of_strength, 60}};
#else
        return {{it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::bruiser_shard_of_strength, 60}, {it::bruiser_shard_of_health, 60}};
#endif
#endif
#if V58_KIT_TAVI
    if (t == bc::champion_type::tavi)
        return {{it::treasure_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::monster_shard_of_strength, 5}, {it::bruiser_shard_of_strength, 60}, {it::bruiser_shard_of_health, 60}};
#endif
#if V58_KIT_HEART
    if (t == bc::champion_type::heart_of_ruin)
        return {{it::treasure_shard_of_health, 5}, {it::jungle_shard_of_focus, 5},
            {it::durability_shard_of_health, 5}, {it::bruiser_shard_of_health, 60}, {it::bruiser_shard_of_strength, 60}};
#endif
    const bool caster = t == bc::champion_type::stellar || t == bc::champion_type::cassi || t == bc::champion_type::prism
        || (NOVA_CASTER_SET >= 1 && (t == bc::champion_type::tavi))
        || (NOVA_CASTER_SET >= 2 && (t == bc::champion_type::willow || t == bc::champion_type::marcella));
#if V54_ITEMS
    // v54 item milestones. Bit 1: the first emblem is Treasure (+20% of all later gold; its five shards give the same
    // stats as any other emblem, so the price is only the passive it displaces). Every winning lineup in the decoded
    // top-team games has it on nearly every champion by round 250; v53 never bought it (first purchase median R148
    // against R72). Bit 2: stat stacking with Bruiser (5 shards of the stat plus one of each other: 7 shards of
    // stats for 150 gold) instead of Power (6). Camp emblems (Jungle, Durability) keep their place.
    {
        using ct = bc::champion_type;
        const bool tre = (V54_ITEMS & 1) != 0, bru = (V54_ITEMS & 2) != 0;
        const it main_s = caster ? it::bruiser_shard_of_focus : it::bruiser_shard_of_strength;
        std::vector<BuildStep> v;
        auto add = [&](it item, int n) { v.push_back({item, n}); };
        if (t == ct::vesper_vale) {
            if (tre) add(it::treasure_shard_of_strength, 5);
            add(it::jungle_shard_of_strength, 5), add(it::durability_shard_of_health, 5);
        } else if (t == ct::prism) {
            add(it::durability_shard_of_health, 5), add(it::monster_shard_of_focus, 5);
            if (tre) add(it::treasure_shard_of_focus, 5);
        } else if (t == ct::heart_of_ruin) {
            if (tre) add(it::treasure_shard_of_health, 5);
            add(it::jungle_shard_of_focus, 5);
        } else if (caster) {
            if (tre) add(it::treasure_shard_of_focus, 5);
            add(it::durability_shard_of_health, 5);
        } else {
            if (tre) add(it::treasure_shard_of_health, 5);
            add(it::jungle_shard_of_strength, 5), add(it::durability_shard_of_health, 5);
        }
        if (bru) {
            if (t == ct::heart_of_ruin) add(it::bruiser_shard_of_health, 60), add(it::bruiser_shard_of_strength, 60);
            else add(main_s, t == ct::vesper_vale || caster ? 60 : 40), add(it::bruiser_shard_of_health, 60);
        } else {
            const it pw = caster ? it::power_shard_of_focus : it::power_shard_of_strength;
            add(pw, 20), add(it::power_shard_of_health, 60);
        }
        return v;
    }
#endif
#if UB_PROXY
    // Ladder proxy (engine 1.0.3 top teams, ladder/analyse.py): treasure emblem first, then jungle / durability,
    // then bruiser stacks (a bruiser emblem is 5 shards of its stat plus one of each other).
    switch (t) {
    case bc::champion_type::vesper_vale:
        return {{it::treasure_shard_of_strength, 5}, {it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::bruiser_shard_of_strength, 60}, {it::bruiser_shard_of_health, 60}};
    case bc::champion_type::prism:
        return {{it::durability_shard_of_health, 5}, {it::monster_shard_of_focus, 5}, {it::treasure_shard_of_focus, 5},
            {it::bruiser_shard_of_focus, 60}, {it::bruiser_shard_of_health, 60}};
    case bc::champion_type::heart_of_ruin:
        return {{it::treasure_shard_of_health, 5}, {it::jungle_shard_of_focus, 5}, {it::bruiser_shard_of_health, 60},
            {it::bruiser_shard_of_strength, 60}};
    default:
        if (caster)
            return {{it::treasure_shard_of_focus, 5}, {it::durability_shard_of_health, 5}, {it::bruiser_shard_of_focus, 60},
                {it::bruiser_shard_of_health, 60}};
        return {{it::treasure_shard_of_health, 5}, {it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::bruiser_shard_of_strength, 40}, {it::bruiser_shard_of_health, 60}};
    }
#endif
#if A2_SPARSE_BUILD
    // Sparse maps are farming races (few fights): the camp-clearing default build below races faster than the
    // top teams' fight build (solo race expanse 505.8 -> 486.6 rounds; pool on expanse 53.6% -> 88.4%).
    // Low gem density alone also flags small crowded maps (fragment, contest: fight maps); a race map is also roomy.
    static const float dens = a2_gem_density();
    static const float room = static_cast<float>(bc::map::width() * bc::map::height()) /
        static_cast<float>(std::max<std::size_t>(1, bc::champions(team::ally).size()));
    const int build = dens >= 0.0f && dens < A2_SPARSE_DENS && room >= A2_SPARSE_AREA ? 0 : tune::kBuild;
#else
    const int build = (A2_MAP_PROFILE & 8) && a2map::farm_build() ? 0 : tune::kBuild;
#endif
    switch (build) {
    case 1: // raw power: strength first, health later
        return {{it::power_shard_of_strength, 20}, {it::power_shard_of_health, 10}, {it::power_shard_of_strength, 40},
            {it::power_shard_of_health, 60}};
    case 2: // survive camps first: jungle health emblem, then monster strength
        return {{it::jungle_shard_of_health, 5}, {it::monster_shard_of_strength, 5}, {it::power_shard_of_strength, 30},
            {it::power_shard_of_health, 60}};
    case 3: // balanced: alternate strength and health emblems
        return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_health, 5}, {it::power_shard_of_strength, 5},
            {it::durability_shard_of_health, 5}, {it::power_shard_of_strength, 30}, {it::power_shard_of_health, 60}};
    case 4: // the top teams' build (Mite, WHIM): passives taken as strength shards, strength only
        if (caster) break;
        return {{it::jungle_shard_of_strength, 5}, {it::power_shard_of_strength, 25}, {it::durability_shard_of_strength, 5},
            {it::power_shard_of_strength, 90}};
    case 5: // our order, with every shard as strength
        if (caster) break;
        return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_strength, 5}, {it::power_shard_of_strength, 30},
            {it::durability_shard_of_strength, 5}, {it::power_shard_of_strength, 90}};
    case 6: // our order with the home emblem (recall 3 turns) in place of durability
        if (caster) break;
        return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_health, 5}, {it::power_shard_of_strength, 30},
            {it::home_shard_of_health, 5}, {it::power_shard_of_health, 60}};
    case 7: // home emblem right after the two camp emblems
        if (caster) break;
        return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_health, 5}, {it::home_shard_of_health, 5},
            {it::power_shard_of_strength, 30}, {it::durability_shard_of_health, 5}, {it::power_shard_of_health, 60}};
    case 8: // v26 ladder study: the teams that beat us carried 2-3x our item health from round 100 on
        if (caster)
            return {{it::power_shard_of_health, 5}, {it::monster_shard_of_focus, 5}, {it::power_shard_of_health, 10},
                {it::power_shard_of_focus, 30}, {it::power_shard_of_health, 60}};
        return {{it::power_shard_of_health, 5}, {it::monster_shard_of_strength, 5}, {it::power_shard_of_health, 10},
            {it::power_shard_of_strength, 30}, {it::power_shard_of_health, 60}};
    case 10: // top bot B (4 decoded top-vs-top games): power main stat (or bruiser health) first, durability
             // health, then power of the main stat; casters and Ren take focus. No monster emblem.
    case 11: { // top bot A: jungle, durability and bruiser emblems of the main stat first, then power
        const bool foc = t == bc::champion_type::stellar || t == bc::champion_type::cassi || t == bc::champion_type::prism ||
            t == bc::champion_type::tavi || t == bc::champion_type::ren || t == bc::champion_type::willow;
        if (tune::kBuild == 10) {
            if (foc)
                return {{it::bruiser_shard_of_health, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_focus, 40},
                    {it::power_shard_of_health, 60}};
            return {{it::power_shard_of_strength, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_strength, 40},
                {it::power_shard_of_health, 60}};
        }
        if (foc)
            return {{it::jungle_shard_of_focus, 5}, {it::durability_shard_of_focus, 5}, {it::bruiser_shard_of_health, 5},
                {it::power_shard_of_focus, 40}, {it::power_shard_of_health, 60}};
        return {{it::jungle_shard_of_strength, 5}, {it::durability_shard_of_strength, 5}, {it::bruiser_shard_of_health, 5},
            {it::power_shard_of_strength, 40}, {it::power_shard_of_health, 60}};
    }
    case 12: { // consensus of the top-12 teams' purchases in 1,076 platform games (tools: summaries, buyItem):
               // durability health emblem (-10% damage taken) on almost every champion, bruiser health on the
               // frontline, Ren and Tavi on focus, jungle first for the junglers, monster emblems mostly skipped.
        using ct = bc::champion_type;
        switch (t) {
        case ct::stellar:
            return {{it::jungle_shard_of_focus, 5}, {it::power_shard_of_focus, 10}, {it::durability_shard_of_health, 5},
                {it::power_shard_of_focus, 25}, {it::bruiser_shard_of_health, 5}, {it::power_shard_of_focus, 60}};
        case ct::cassi:
            return {{it::jungle_shard_of_focus, 5}, {it::power_shard_of_focus, 5}, {it::bruiser_shard_of_health, 5},
                {it::durability_shard_of_focus, 5}, {it::power_shard_of_focus, 60}};
        case ct::issac:
            return {{it::jungle_shard_of_strength, 5}, {it::power_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
                {it::power_shard_of_strength, 30}, {it::bruiser_shard_of_health, 5}, {it::power_shard_of_strength, 60}};
        case ct::ren:
            return {{it::bruiser_shard_of_health, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_focus, 40},
                {it::jungle_shard_of_focus, 5}, {it::power_shard_of_focus, 60}};
        case ct::ryth:
        case ct::marcella:
            return {{it::bruiser_shard_of_health, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_strength, 30},
                {it::jungle_shard_of_strength, 5}, {it::power_shard_of_strength, 60}};
        case ct::varg:
            return {{it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_strength, 30},
                {it::durability_shard_of_strength, 5}, {it::power_shard_of_strength, 60}};
        case ct::tavi:
            return {{it::durability_shard_of_focus, 5}, {it::power_shard_of_focus, 10}, {it::durability_shard_of_health, 5},
                {it::power_shard_of_focus, 60}};
        case ct::prism:
            return {{it::bruiser_shard_of_focus, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_focus, 60}};
        case ct::vendetta:
            return {{it::jungle_shard_of_strength, 5}, {it::power_shard_of_strength, 5}, {it::monster_shard_of_strength, 5},
                {it::power_shard_of_strength, 60}};
        case ct::willow:
            return {{it::bruiser_shard_of_strength, 5}, {it::durability_shard_of_health, 5}, {it::power_shard_of_strength, 60}};
        case ct::vesper_vale:
            return {{it::durability_shard_of_health, 5}, {it::jungle_shard_of_strength, 5}, {it::monster_shard_of_strength, 5},
                {it::power_shard_of_strength, 60}};
        default: break;
        }
        break;
    }
    case 9: // health and the build's own stat alternating, durability emblem early
        if (caster)
            return {{it::power_shard_of_health, 5}, {it::power_shard_of_focus, 5}, {it::durability_shard_of_health, 5},
                {it::power_shard_of_focus, 30}, {it::power_shard_of_health, 60}};
        return {{it::power_shard_of_health, 5}, {it::power_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::power_shard_of_strength, 30}, {it::power_shard_of_health, 60}};
    default: break;
    }
    // v44: finish camp damage reduction first, then add health and PvP damage
    // reduction before scaling damage. Keep the original build on split terrain.
    if (UB_BUILD && !caster && !mobility_farming_map)
        return {{it::jungle_shard_of_strength, 5}, {it::durability_shard_of_health, 5},
            {it::power_shard_of_strength, 20}, {it::power_shard_of_health, 60}};
    // NOVA_CASSI_BUILD: every Cassi & Issac double death started with Cassi (700 health) dying, and
    // it costs two bodies; buy her health first (71 per shard), focus after.
    if (NOVA_CASSI_BUILD && t == bc::champion_type::cassi)
        return {{it::jungle_shard_of_health, 5}, {it::power_shard_of_health, 5}, {it::monster_shard_of_focus, 5},
            {it::power_shard_of_focus, 30}, {it::power_shard_of_health, 60}};
    // Casters' spells scale with focus (Stellar: 2.0x and 1.4x focus every 8 turns), and their
    // strength growth is only 3.5 per shard, so a focus shard is worth more than a strength one.
    if (caster && tune::kCasterFocus)
        return {{it::monster_shard_of_focus, 5}, {it::jungle_shard_of_health, 5}, {it::power_shard_of_focus, 30},
            {it::power_shard_of_health, 60}};
    if (caster)
        return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_health, 5}, {it::power_shard_of_focus, 5},
            {it::power_shard_of_strength, 30}, {it::power_shard_of_health, 60}};
    return {{it::monster_shard_of_strength, 5}, {it::jungle_shard_of_health, 5}, {it::power_shard_of_strength, 30},
        {it::durability_shard_of_health, 5}, {it::power_shard_of_health, 60}};
}

// Base stats and growth per shard (health, strength, focus), indexed by champion_type.
struct BaseStats {
    float hp, str, focus, ghp, gstr, gfocus;
};
#if V58_PATCH
std::array<BaseStats, 13> kBase{}; // Filled once per guest from current immutable champion designs.
#elif A2_KITFIX & 16 // cambc 3.0.4 starting stats and growth (Vesper, Vendetta, Stellar, Tavi, Heart of Ruin changed)
constexpr BaseStats kBase[13] = {
    {1200, 45, 100, 100, 5, 10},  // ryth (+1% of bonus health as strength)
    {1000, 55, 100, 100, 5, 10},  // vesper vale
    {1000, 70, 100, 100, 6, 10},  // vendetta
    {600, 30, 70, 65, 3, 13},     // cassi
    {900, 40, 100, 80, 3, 10},    // issac
    {650, 30, 70, 65, 3.5f, 7},   // stellar
    {700, 35, 80, 60, 2.5f, 8},   // prism
    {1200, 45, 60, 100, 5, 15},   // marcella
    {700, 55, 120, 50, 3, 5},     // willow
    {900, 35, 100, 100, 5, 9},    // ren
    {1000, 40, 100, 100, 5, 10},  // varg
    {900, 45, 110, 75, 5, 10},    // tavi
    {1000, 30, 100, 100, 3.5f, 12}, // heart of ruin
};
#elif A2_KITFIX & 8 // engine 3.0 starting stats and growth (GameRules, 21 Oct)
constexpr BaseStats kBase[13] = {
    {1200, 45, 100, 100, 5, 10},  // ryth (+1% of bonus health as strength)
    {900, 50, 100, 100, 5, 10},   // vesper vale
    {800, 70, 100, 100, 6, 10},   // vendetta
    {600, 30, 70, 65, 3, 13},     // cassi
    {900, 40, 100, 80, 3, 10},    // issac
    {750, 30, 85, 75, 3.5f, 9},   // stellar
    {700, 35, 80, 60, 2.5f, 8},   // prism
    {1200, 45, 60, 100, 5, 15},   // marcella
    {700, 55, 120, 50, 3, 5},     // willow
    {900, 35, 100, 100, 5, 9},    // ren
    {1000, 40, 100, 100, 5, 10},  // varg
    {750, 45, 100, 75, 5, 10},    // tavi
    {1000, 40, 100, 100, 4, 12},  // heart of ruin
};
#else
constexpr BaseStats kBase[12] = {
    {1200, 50, 100, 100, 5, 10},  // ryth (+1% of bonus health as strength)
    {900, 45, 100, 100, 5, 10},   // vesper vale
    {800, 70, 100, 100, 5, 10},   // vendetta
    {700, 30, 70, 71.25f, 3.5f, 15}, // cassi
    {900, 40, 100, 95, 4.75f, 10}, // issac
    {750, 35, 100, 75, 3.5f, 10}, // stellar
    {700, 35, 80, 75, 3.5f, 10},  // prism
    {1200, 45, 50, 100, 5, 10},   // marcella
    {700, 45, 105, 50, 3, 5},     // willow
    {900, 40, 100, 100, 5, 10},   // ren
    {1000, 50, 100, 100, 5, 10},  // varg
    {750, 35, 100, 75, 5, 10},    // tavi
};
#endif
float items_of(bc::champion_type t, float max_hp, float str, float focus) {
    const int i = static_cast<int>(t);
    if (i < 0 || i >= static_cast<int>(std::size(kBase))) return 0.0f;
    const auto& b = kBase[i];
    const float bonus_hp = std::max(0.0f, max_hp - b.hp);
    if (t == bc::champion_type::ryth) str -= 0.01f * bonus_hp;
    float items = bonus_hp / b.ghp + std::max(0.0f, str - b.str) / b.gstr + std::max(0.0f, focus - b.focus) / b.gfocus;
    // Lab knob 35: Vesper (+33% gold) counts as poorer, so camp rewards go to her more often.
    if (t == bc::champion_type::vesper_vale) items -= 3.0f * LABK(35);
    return items;
}

} // namespace

// ---------------------------------------------------------------- setup

void Bot::init() {
#if V58_PATCH
    for (int i = 0; i < 13; ++i) {
        d::champion_design design{};
        d::check(d::sdk_champion_design(i, &design));
        const auto& s = design.base_stats;
        kBase[i] = {s.base_health,s.base_strength,s.base_focus,s.health_growth,s.strength_growth,s.focus_growth};
    }
#endif
#if A2_MAP_PROFILE
    { // which official map (same identity as the draft and is_official_map), before any bush labelling
        std::uint32_t ngroups = 0;
        const int ng = d::sdk_map_num_camp_groups(&ngroups) == 0 ? static_cast<int>(ngroups) : -1;
        unsigned picks = static_cast<unsigned>(bc::champions(team::ally).size());
        try {
            picks = bc::draft::team_size();
        } catch (...) {
        }
        a2map::id = nova_map_id(static_cast<int>(bc::map::width()), static_cast<int>(bc::map::height()), picks, ng);
    }
#endif
#if A2_SPARSE_BUILD
    (void)a2_gem_density(); // measured now, with every camp full (it reads live camp gems; cached for the build)
#endif
    w.init();
    mobility_farming_map = w.value_cut_off();
#if A2_MLPLAN && A2_LAB
    // The draft net's game plan (draft-memory byte 7 = 0x80 | preset): this game's knob vector.
    try {
        if (bc::draft_memory.size() >= 8) {
            const auto b = static_cast<std::uint8_t>(bc::draft_memory[7]);
            if (b & 0x80) {
                const int pl = b & 7;
                for (int i = 0; i < ml_plan::kKnobs && i < lab::kKnobs; ++i) lab::knobs[i] = ml_plan::kPreset[pl][i];
            }
        }
    } catch (...) {
    }
#endif
    auto& me = bc::self();
    const auto allies = bc::champions(team::ally);
    for (std::size_t i = 0; i < allies.size(); ++i) {
        if (allies[i] == me) slot = static_cast<int>(i);
        if (i < ally_handle.size()) ally_handle[i] = static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(allies[i]));
        if (i < slot_type.size()) {
            try {
                slot_type[i] = allies[i].champion_name(); // throws for allies out of vision
            } catch (...) {
                slot_type[i] = bc::champion_type::vesper_vale; // unknown until seen (never in a pack)
            }
        }
    }
    team_size = static_cast<int>(allies.size());
#if X3_TRACE
    std::printf("X3_CONFIG slot%d mastery%d secure%d alone%d hunt%d anti%d heart%d soak%d prune%d hold%d drop%d teamwin%d siege%d bag%d cover%d paths%d use%d team%d farm%d race%d cycle%d plan%d end%d wait%.2f stage%.2f need%.2f\n",
        slot,X1_MASTERY,X1_SECURE,X1_ALONE,X1_HUNT_SOLO,X1_ANTIFEED,X1_HEARTFIX,X1_SOAK64,X1_PRUNEFIX,
        X1_FLEEHOLD,X1_FLEEDROP,X1_TEAMWIN,X1_SIEGE_STRICT,X1_BAGRISK,X3_COVER_SAFE,X3_DRAFT_PATHS,X3_DRAFT_USE,
        X3_TEAM,X3_TEAM_FARM,X3_TEAM_RACE,X3_BANKCYCLE,tune::kPlan,X3_PLAN_END,X1_WAIT_MULT,X1_STAGE_MULT,X1_NEED_MULT);
#endif
#if X3_TEAM >= 2
    team_economic_init();
#endif
#if V58_DIRECTOR
    if (bc::draft_memory.size() >= 1016 && static_cast<std::uint8_t>(bc::draft_memory[1008]) == 0x58 &&
        static_cast<int>(bc::draft_memory[1009]) == team_size) {
        for (int s = 0; s < std::min(team_size, kClaimSlots); ++s)
            slot_type[s] = static_cast<bc::champion_type>(static_cast<std::uint8_t>(bc::draft_memory[1010 + s]));
    }
#endif
    my_id = static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(me));
    type = me.champion_name();
    const auto abilities = me.abilities();
    for (int s = 0; s < 2; ++s) {
        const auto& info = abilities[s].info();
        Spell sp;
        if (info) {
            sp.present = true;
            std::visit(
                [&](const auto& a) {
                    using A = std::decay_t<decltype(a)>;
                    sp.kind = A::kind;
                    sp.excludes_walk = a.exclusive_with_movement;
                    sp.camps = a.valid_targets.contains(bc::ability_target_mask::camps);
                    sp.enemies = a.valid_targets.contains(bc::ability_target_mask::enemies);
                    sp.allies = a.valid_targets.contains(bc::ability_target_mask::allies);
                    sp.ground = a.valid_targets.contains(bc::ability_target_mask::ground);
                    if constexpr (requires { a.range; }) sp.range = a.range;
                    if constexpr (requires { a.modifier; }) sp.modifier = a.modifier;
                    if constexpr (requires { a.radius; }) sp.radius = a.radius;
                },
                *info);
        }
        spells[s] = sp;
#if A2_MICLOG
        std::printf("KIT %d %d %d %.2f %.2f %.2f %d %d %d %d\n", static_cast<int>(type), s, static_cast<int>(sp.kind), sp.range, sp.modifier,
            sp.radius, sp.excludes_walk ? 1 : 0, sp.enemies ? 1 : 0, sp.camps ? 1 : 0, sp.ground ? 1 : 0);
#endif
    }
#if A2_BRIDGES
    for (int s = 0; s < 2; ++s)
        if (spells[s].kind == bc::ability_kind::dash) {
            w.enable_bridges(); // our fields cross one-tile hole gaps; the travel dash jumps them
            break;
        }
#endif
#if X3_DRAFT_PATHS
    draft_paths_load(w); // after champion-specific bridge topology is established
#endif
    seen_claim.fill(-1);
    onsite_ok = V54_ONSITE && w.groups.size() <= static_cast<std::size_t>(kOnsiteGroups);
    shared = read_shared();
    decode_claims();
#if X3_TEAM >= 11
    // The first actor can publish the opening before later actors initialize.
    // Preserve a real pending assignment; the all-idle initial word is not one.
    if (!(team_size<kClaimSlots && ((shared>>(35+slot))&1) &&
          claim_of(slot)>=0 && claim_of(slot)<static_cast<int>(w.groups.size()))) write_claim(-1);
#else
    write_claim(-1);
#endif
    inited = true;
}

void Bot::refresh_self() {
    auto& me = bc::self();
    d::champion_info info{};
    d::check(d::sdk_champion(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(me)), &info));
    pos = {info.x, info.y};
    prev_hp = hp;
    hp = info.health;
    max_hp = std::max(1.0f, info.max_health);
    strength = info.strength;
    focus = info.focus;
    range = info.attack_range;
    melee = range <= 1;
    gems = static_cast<int>(me.gem_count());
    gold = static_cast<int>(me.gold_count());
    for (int s = 0; s < 2; ++s) {
        std::int32_t cd = 99;
        if (spells[s].present) d::sdk_champion_cooldown(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(me)), s, &cd);
        cooldown[s] = cd;
    }
    ally_score = static_cast<int>(bc::global_submitted_gems(team::ally));
    enemy_score = static_cast<int>(bc::global_submitted_gems(team::enemy));
#if V55_HEART_MODEL
    // These stats are already snapshotted for this turn. Keep invariant damage work outside group scoring.
    cached_dps = strength;
    for (const auto& sp : spells) {
        if (!sp.present) continue;
        if (sp.kind == bc::ability_kind::attack_reset) cached_dps += strength / 8.0f;
        if ((sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc || sp.kind == bc::ability_kind::aoe_damage) && sp.camps)
            cached_dps += sp.modifier * focus / 8.0f;
        if (type == bc::champion_type::heart_of_ruin && sp.kind == bc::ability_kind::dash && sp.modifier > 0.0f)
            cached_dps += sp.modifier * focus / 8.0f;
    }
    if (type == bc::champion_type::heart_of_ruin)
        cached_dps *= 1.0f + 0.5f * (1.0f - hp / max_hp);
#endif
}

bool Bot::spell_ready(int s) const { return spells[s].present && cooldown[s] == 0 && !cast_done; }

// ---------------------------------------------------------------- shared memory

std::uint64_t Bot::read_shared() const {
    std::uint64_t v = 0;
    bc::shared_memory.read(0, std::span<std::uint64_t, 1>{&v, 1});
    return v;
}

void Bot::write_claim(int group, bool onsite) {
    if (slot >= kClaimSlots) return;
    std::uint64_t v = read_shared();
    if (!inited && v == 0) v = (std::uint64_t{1} << (kClaimBits * kClaimSlots)) - 1; // first writer: all slots idle
    // 8 bits per slot (teams have 3-5 champions; 100x100 maps can hold over 125 groups):
    // 255 = alive without a target, 254 = dead, otherwise the claimed group index.
    std::uint64_t code = group == kClaimDead ? kClaimCodeDead
        : group < 0 || group >= static_cast<int>(kClaimCodeDead) ? kClaimCodeIdle : static_cast<std::uint64_t>(group);
#if V54_ONSITE
    // Rewriting the same claim keeps an on-site mark; only mark_onsite sets it and a new target clears it.
    if (onsite_ok && group >= 0 && group < kOnsiteGroups && (onsite || (claim_onsite(slot) && claim_cache[slot] == group)))
        code = static_cast<std::uint64_t>(kOnsiteBase + group);
#else
    (void)onsite;
#endif
    v &= ~(kClaimMask << (slot * kClaimBits));
    v |= code << (slot * kClaimBits);
#if X3_TEAM >= 11
    if (team_size<kClaimSlots) v&=~(std::uint64_t{1}<<(35+slot)); // this actor consumed its command
#endif
    bc::shared_memory.write(0, std::span<std::uint64_t, 1>{&v, 1});
    shared = v;
    decode_claims();
}

// Claims are read in the camp-scoring loops: decode the shared word once per change, not per lookup.
void Bot::decode_claims() {
    onsite_bits = 0;
    for (int s = 0; s < kClaimSlots; ++s) {
        int c = static_cast<int>((shared >> (s * kClaimBits)) & kClaimMask);
#if V54_ONSITE
        if (onsite_ok && c >= kOnsiteBase && c < kOnsiteBase + kOnsiteGroups) {
            c -= kOnsiteBase;
            onsite_bits |= 1u << s;
        }
#endif
#if V58_DIRECTOR
        if (team_size < kClaimSlots && s == 5) c = static_cast<int>(kClaimCodeIdle); // reserved job, never a phantom claimant
#endif
#if X3_TEAM >= 11
        if (team_size<kClaimSlots && s==5) c=static_cast<int>(kClaimCodeIdle); // command flags, not a sixth body
#endif
        claim_cache[static_cast<std::size_t>(s)] = static_cast<std::int16_t>(c);
    }
}

void Bot::unmark_onsite() {
    if (slot >= kClaimSlots || !claim_onsite(slot)) return;
    std::uint64_t v = read_shared();
    v &= ~(kClaimMask << (slot * kClaimBits));
    v |= static_cast<std::uint64_t>(claim_cache[static_cast<std::size_t>(slot)]) << (slot * kClaimBits);
    bc::shared_memory.write(0, std::span<std::uint64_t, 1>{&v, 1});
    shared = v;
    decode_claims();
}

void Bot::mark_onsite(int group) {
#if V54_ONSITE
    if (!onsite_ok || group < 0 || group >= kOnsiteGroups || slot >= kClaimSlots) return;
    if (claim_onsite(slot) && claim_cache[static_cast<std::size_t>(slot)] == group) return;
    write_claim(group, true);
#else
    (void)group;
#endif
}

// A raw code in our claim slot (fight orders 112-118: engage enemy k, retreat).
void Bot::write_order(int code) {
    if (slot >= kClaimSlots) return;
    std::uint64_t v = read_shared();
    v &= ~(kClaimMask << (slot * kClaimBits));
    v |= (static_cast<std::uint64_t>(code) & kClaimMask) << (slot * kClaimBits);
    bc::shared_memory.write(0, std::span<std::uint64_t, 1>{&v, 1});
    shared = v;
    decode_claims();
}

void Bot::share_sighting(bool call_for_help) {
#if X3_TEAM >= 4 && X3_TEAM < 10
    (void)call_for_help;return; // upper bits carry a leased team assignment epoch
#endif
    // Publish the enemy nearest to us; teammates fold it into their threat map. With
    // call_for_help (we are fleeing it) bit 62 marks a distress call that allies may answer.
    const EnemyRec* best = nullptr;
    for (const auto& e : w.enemies)
        if (!best || cheb(e.pos, pos) < cheb(best->pos, pos)) best = &e;
    if (!best) return;
    std::uint64_t v = read_shared();
    if (!call_for_help && ((v >> kDistressBit) & 1)) {
        // Leave a teammate's fresh distress call in place.
        int age = (round & kSightRoundMask) - static_cast<int>((v >> kSightRound) & kSightRoundMask);
        if (age < 0) age += kSightRoundMask + 1;
        if (age <= 2) return;
    }
    v &= (std::uint64_t{1} << kSightX) - 1;
    v |= static_cast<std::uint64_t>(best->pos.x & 127) << kSightX;
    v |= static_cast<std::uint64_t>(best->pos.y & 127) << kSightY;
    v |= static_cast<std::uint64_t>(round & kSightRoundMask) << kSightRound;
    if (call_for_help) v |= std::uint64_t{1} << kDistressBit;
    bc::shared_memory.write(0, std::span<std::uint64_t, 1>{&v, 1});
    shared = v;
    decode_claims();
}

void Bot::read_sighting() {
#if X3_TEAM >= 4 && X3_TEAM < 10
    return;
#endif
#if APEX_EVENTS
    if ((shared >> 63) & 1) {
        // A teammate's group event: group (7 bits) and its respawn-ready round mod 256 (8 bits).
        const int gi = static_cast<int>((shared >> kSightX) & 127);
        const int mod = static_cast<int>((shared >> kSightY) & 255);
        const int base = round - 64;
        const int ready = base + ((mod - base) % 256 + 256) % 256;
        w.apply_event(gi, ready, round);
        return;
    }
#endif
    const int r = static_cast<int>((shared >> kSightRound) & kSightRoundMask);
    if ((shared >> kSightX) == 0) return; // nothing published yet
    int age = (round & kSightRoundMask) - r;
    if (age < 0) age += kSightRoundMask + 1;
    if (age > 10) return;
    const vec2 p{static_cast<int>((shared >> kSightX) & 127), static_cast<int>((shared >> kSightY) & 127)};
    if (p.x < w.width && p.y < w.height) {
        w.add_sighting(p, round - age);
        if ((shared >> kDistressBit) & 1) distress = {p, round - age};
    }
}

// Claims on a group by allies acting before us (lower slots) and after us.
std::pair<int, int> Bot::claims_split(int group) const {
    int lower = 0, higher = 0;
    for (int s = 0; s < std::min(team_size, kClaimSlots); ++s) {
        if (s == slot || s == duo_ignore_slot || claim_of(s) != group) continue;
        (s < slot ? lower : higher) += 1;
    }
    return {lower, higher};
}

bool Bot::open_call_by_lower() {
    for (int s = 0; s < std::min(team_size, slot); ++s) {
        const int c = claim_of(s);
        if (c >= static_cast<int>(w.groups.size())) continue;
        const auto& g = w.groups[c];
        if (g.state != GroupState::alive || g.harmless) continue;
        if (claim_count(c) + 1 < champions_needed(g, g.hp_left(w.camps))) return true;
    }
    return false;
}

void Bot::track_claims() {
    for (int s = 0; s < kClaimSlots; ++s) {
        const int c = claim_of(s);
        if (c != seen_claim[s]) {
            seen_claim[s] = c;
            claim_since[s] = round;
        }
    }
}

// Other claimants of `group` that were there before us (all of them when it is not our target).
int Bot::senior_claims(int group) const {
    const bool ours = group == target_group;
    int n = 0;
    for (int s = 0; s < std::min(team_size, kClaimSlots); ++s) {
        if (s == slot || s == duo_ignore_slot || claim_of(s) != group) continue;
        if (!ours || claim_since[s] < my_claim_since || (claim_since[s] == my_claim_since && s < slot)) ++n;
    }
    return n;
}

int Bot::claim_count(int group) const {
    int n = 0;
    for (int s = 0; s < kClaimSlots; ++s)
        if (s != slot && claim_of(s) == group) ++n;
    return n;
}

// ---------------------------------------------------------------- shopping

void Bot::shop() {
    PROF(shop);
    auto& me = bc::self();
#if V58_PATCH
    if (gold < 10) return;
    const auto counts = me.item_count();
    std::array<int, static_cast<std::size_t>(bc::item_type::count)> purchased{};
#if A2_LAB
    const auto plan = build_for(type);
#else
    static const auto plan = build_for(type);
#endif
    bool reserve_items = false;
    if (!plan.empty()) {
        const auto first = plan.front();
        int owned = static_cast<int>(counts[first.item]);
        if (auto result = first.item.result()) owned += static_cast<int>(counts[*result] * first.item.combine_count());
        reserve_items = owned < first.total;
    }
#else
    constexpr bool reserve_items = false;
#endif
#if V58_DIRECTOR && V58_CARRY_SHOP
    const bool reserve_treasure = economy_enabled() && slot == economy_carry() && ec_treasure_shards < 5;
#else
    constexpr bool reserve_treasure = false;
#endif
    try {
        if (!reserve_treasure && !reserve_items && tune::kAltarLocks && gold >= 10 && me.can_buy(bc::consumable_type::altar_lock)) {
            me.buy(bc::consumable_type::altar_lock);
            gold -= 10;
        }
    } catch (const std::exception& e) {
        LOG("lock buy error %s\n", e.what());
    }
#if V54_TP
    try {
        // A crystal costs 10 gold; winners re-buy one for the same few terrain shortcuts every trip (ladder replays:
        // up to 53 hops by one champion on concentrated-wealth, none ever by us).
        if (!reserve_treasure && (!reserve_items || mobility_farming_map) && gold >= 10 && me.can_buy(bc::consumable_type::tp_crystal)) {
            me.buy(bc::consumable_type::tp_crystal);
            gold -= 10;
        }
        tp_held = static_cast<int>(me.consumables()[bc::consumable_type::tp_crystal].count());
    } catch (const std::exception& e) {
        LOG("crystal buy error %s\n", e.what());
    }
#endif
    if (gold < 30) return;
    try {
#if !V58_PATCH
        const auto counts = me.item_count();
#endif
#if V58_DIRECTOR && V58_CARRY_SHOP
        ec_treasure_shards = static_cast<int>(counts[bc::item_type::treasure_shard_of_strength] + counts[bc::item_type::treasure_shard_of_health] + counts[bc::item_type::treasure_shard_of_focus]) +
            5 * static_cast<int>(counts[bc::item_type::treasure_emblem_of_strength] + counts[bc::item_type::treasure_emblem_of_health] + counts[bc::item_type::treasure_emblem_of_focus]);
#endif
        bool complete = true; // V56_SHOP_DONE: every step's total reached after this visit
#if V58_PATCH
        for (const auto& step : plan) {
            const int cost = std::max(1, static_cast<int>(step.item.cost()));
            int owned = purchased[static_cast<std::size_t>(step.item)] + static_cast<int>(counts[step.item]);
            if (const auto emblem = step.item.result()) owned += static_cast<int>(counts[*emblem] * step.item.combine_count());
            const int want = std::min(step.total - owned, gold / cost);
#else
        for (const auto& step : build_for(type)) {
            int owned = static_cast<int>(counts[step.item]);
            if (const auto emblem = step.item.result()) owned += static_cast<int>(counts[*emblem]) * 5;
            int want = std::min(step.total - owned, gold / 30);
#endif
            if (step.total - owned > std::max(want, 0)) complete = false;
            if (want <= 0) continue;
            if (!me.can_buy(step.item, static_cast<std::uint32_t>(want))) {
                // On spawn with the gold for it, a refusal is terminal (inventory or stat limit): nothing left to buy.
                if (V56_SHOP_DONE && bit(w.ally_spawn, pos)) shop_done = true;
                return;
            }
            me.buy(step.item, static_cast<std::uint32_t>(want));
#if V58_DIRECTOR && V58_CARRY_SHOP
            if (step.item == bc::item_type::treasure_shard_of_strength || step.item == bc::item_type::treasure_shard_of_health || step.item == bc::item_type::treasure_shard_of_focus)
                ec_treasure_shards += want; // purchase event, not work in a scoring loop
#endif
#if V58_PATCH
            purchased[static_cast<std::size_t>(step.item)] += want; // Same item can appear at several milestones.
            inventory_dirty = true;
            gold -= want * cost;
#else
            gold -= want * 30;
#endif
            if (gold < 30) return; // later steps unchecked: completion is recorded on a visit that walks the whole plan
        }
        if (complete) shop_done = V56_SHOP_DONE != 0;
    } catch (const std::exception& e) {
        LOG("shop error %s\n", e.what());
    }
}

// Emblem passives change how much damage we take from and deal to camps; the soak model uses them.
void Bot::refresh_emblems() {
    if (!tune::kEmblemModel) return;
#if V58_PATCH
    if (!inventory_dirty) return; // Purchases/combinations are the only inventory mutations in this policy.
#endif
    try {
        using it = bc::item_type;
        const auto counts = bc::self().item_count();
        auto has = [&](it a, it b, it c) { return counts[a] + counts[b] + counts[c] > 0; };
        camp_taken_mult = 1.0f;
        if (has(it::jungle_emblem_of_strength, it::jungle_emblem_of_focus, it::jungle_emblem_of_health)) camp_taken_mult *= 0.7f;
        if (has(it::durability_emblem_of_strength, it::durability_emblem_of_focus, it::durability_emblem_of_health)) camp_taken_mult *= 0.9f;
        camp_dealt_mult = has(it::monster_emblem_of_strength, it::monster_emblem_of_focus, it::monster_emblem_of_health)
            ? 1.0f + it::monster_emblem_of_strength.passive_magnitude() : 1.0f;
#if V58_PATCH
        unsigned families = 0;
        for (unsigned f = 0; f < 14; ++f)
            if (has(it{f*6+1},it{f*6+3},it{f*6+5})) ++families;
        float collector = has(it::collectors_emblem_of_strength,it::collectors_emblem_of_focus,it::collectors_emblem_of_health)
            ? 1.0f + static_cast<float>(families) * it::collectors_emblem_of_strength.passive_magnitude() : 1.0f;
        camp_dealt_mult *= collector;
        champion_dealt_mult = collector;
        if (has(it::skirmish_emblem_of_strength,it::skirmish_emblem_of_focus,it::skirmish_emblem_of_health))
            champion_dealt_mult *= 1.0f + it::skirmish_emblem_of_strength.passive_magnitude();
        capture_time = has(it::capture_emblem_of_strength,it::capture_emblem_of_focus,it::capture_emblem_of_health)
            ? static_cast<int>(it::capture_emblem_of_strength.passive_magnitude()) : bc::constants::capture_time;
        prospector_bonus = has(it::prospector_emblem_of_strength,it::prospector_emblem_of_focus,it::prospector_emblem_of_health)
            ? it::prospector_emblem_of_strength.passive_magnitude() : 0.0f;
        tribute_bonus = has(it::tribute_emblem_of_strength,it::tribute_emblem_of_focus,it::tribute_emblem_of_health)
            ? it::tribute_emblem_of_strength.passive_magnitude() : 0.0f;
        inventory_dirty = false;
#endif
    } catch (const std::exception& e) {
        LOG("emblem error %s\n", e.what());
    }
}

// ---------------------------------------------------------------- movement

namespace {
// Sets a flag for the rest of a scope (dashes inside fights and hunts are combat moves).
struct FlagScope {
    bool& flag;
    explicit FlagScope(bool& f) : flag(f) { flag = true; }
    ~FlagScope() { flag = false; }
};
} // namespace

bool Bot::travel_dash_ok() const {
    if (tune::kSaveDash >= 2) return false;
    for (const auto& sg : w.sightings)
        if (round - sg.round <= 15 && cheb(sg.pos, pos) <= 15) return false;
    return true;
}

bool Bot::try_dash(const bc::distance_field& field, const bc::bitboard& blocked) {
    if (tune::kSaveDash && !combat_move && !travel_dash_ok()) return false;
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s) || spells[s].kind != bc::ability_kind::dash) continue;
        const std::uint16_t here = fdist(field, pos);
        bool bridge_next = false; // A2_BRIDGES: the way on is over a hole gap, so dash however close the goal is
#if A2_BRIDGES
        if (w.bridges_on)
            for (vec2 dir : kDirs) {
                const vec2 h = pos + dir;
                if (in_bounds(h, w.width, w.height) && bit(w.bridges, h) && fdist(field, h) < here) bridge_next = true;
            }
#endif
        if (here == kUnreach || (here < 3 && !bridge_next)) return false;
        vec2 best = pos;
        std::uint16_t best_d = here;
        for (int dx = -2; dx <= 2; ++dx)
            for (int dy = -2; dy <= 2; ++dy) {
                const vec2 q{pos.x + dx, pos.y + dy};
                if (!in_bounds(q, w.width, w.height) || bit(blocked, q)) continue;
                const std::uint16_t dq = fdist(field, q);
                if (dq + 1 < best_d) {
                    best_d = dq;
                    best = q;
                }
            }
        if (best == pos) return false;
        try {
            if (bc::self().abilities()[s].use(best)) {
#if A2_MICLOG
                {
                    int nd = 99;
                    for (const auto& e : w.enemies) nd = std::min(nd, cheb(e.pos, pos));
                    int sr = 99;
                    for (const auto& sg : w.sightings) if (cheb(sg.pos, pos) <= 15) sr = std::min(sr, round - sg.round);
                    std::printf("TD %d %d %d %d %d %d\n", round, slot, static_cast<int>(type), combat_move ? 1 : 0, nd, sr);
                }
#endif
                pos = best;
                cast_done = true;
                return true;
            }
        } catch (const std::exception& e) {
            LOG("dash error %s\n", e.what());
        }
        return false;
    }
    return false;
}

bool Bot::follow_field(const bc::distance_field& field, const bc::bitboard& blocked, bool allow_dash) {
    auto& me = bc::self();
    if (!me.can_move()) return false;
    if (allow_dash) try_dash(field, blocked);
    const std::uint16_t here = fdist(field, pos);
    if (here == 0) return walked;
    struct Cand {
        vec2 p;
        int score;
    };
    std::array<Cand, 8> cands{};
    int n = 0;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(blocked, q)) continue;
        const std::uint16_t dq = fdist(field, q);
        if (dq == kUnreach || dq >= here) continue;
        // Prefer the steepest descent, then diagonals (they reveal more tiles).
        cands[n++] = {q, dq * 4 + ((dir.x != 0 && dir.y != 0) ? 0 : 1)};
    }
    std::sort(cands.begin(), cands.begin() + n, [](const Cand& a, const Cand& b) { return a.score < b.score; });
#if A2_BRIDGES
    if (n == 0 && w.bridges_on && !walked && bridge_hold < 12)
        for (vec2 dir : kDirs) {
            // The only way on is over a hole gap and the dash is recharging: hold here rather than wander off
            // (at most 12 turns: a gap whose far side stays occupied must not hold us for good).
            const vec2 h = pos + dir;
            if (in_bounds(h, w.width, w.height) && bit(w.bridges, h) && fdist(field, h) < here) {
                ++bridge_hold;
                return true;
            }
        }
    if (n > 0) bridge_hold = 0;
#endif
    for (int i = 0; i < n; ++i) {
        try {
            if (me.move_absolute(cands[i].p)) {
                pos = cands[i].p;
                walked = true;
                return true;
            }
        } catch (const std::exception& e) {
            LOG("move error %s\n", e.what());
        }
    }
    return walked;
}

#if V54_TP
// Teleport shortcut: a legal landing tile within 3 whose walking distance to the goal is at least V54_TP_GAIN turns
// shorter, net of the 3-turn channel. Only out of every enemy's sight and every awake camp's reach (stuns and death
// cancel the channel). One crystal count read per call while we may hold one; nothing else when we do not.
bool Bot::try_teleport(const bc::distance_field& field) {
    if (bit(w.hot_zone, pos) || bc::fuel_remaining() < 20000) return false;
    auto& me = bc::self();
    if (tp_held < 0) tp_held = static_cast<int>(me.consumables()[bc::consumable_type::tp_crystal].count());
    if (tp_held <= 0) return false;
    const int here = fdist(field, pos);
    if (here == kUnreach || here < 3 + V54_TP_GAIN) return false;
    vec2 best{-1, -1};
    int best_d = here - 3 - V54_TP_GAIN;
    const bc::bitboard blocked = w.static_blocked | w.unit_tiles | w.hot_zone;
    for (int dy = -3; dy <= 3; ++dy)
        for (int dx = -3; dx <= 3; ++dx) {
            const vec2 q{pos.x + dx, pos.y + dy};
            if (q.x < 0 || q.y < 0 || q.x >= w.width || q.y >= w.height || bit(blocked, q)) continue;
            const int d = fdist(field, q);
            if (d < best_d) best_d = d, best = q;
        }
    if (best.x < 0) return false;
    try {
        if (me.consumables()[bc::consumable_type::tp_crystal].use(best)) {
            tp_held = 0;
            mode = "teleport";
            return true;
        }
    } catch (const std::exception& e) {
        LOG("teleport error %s\n", e.what());
        tp_held = 0;
    }
    return false;
}
#endif

bool Bot::walk_toward(const bc::bitboard& goals_in) {
    PROF(move);
#if A2_TEL && X1_TEL
    PROF_CHECK("wt_in");
    struct X1Out { ~X1Out() { PROF_CHECK("wt_out"); } } x1_out;
#endif
#if A2_TEL
    a2tel::CallCost a2_cost{9};
#endif
    walk_unreachable = false;
    // A path search could suspend the turn (APEX_DET: a floor nearer its real cost, so it binds less often).
    if (bc::fuel_remaining() < (tune::kDet ? 9000 : tune::kMinMoveFuel)) return false;
    bc::bitboard blocked = w.static_blocked | w.unit_tiles;
    blocked.set(pos, false);
    const bc::bitboard goals = goals_in & ~blocked;
    if (goals.is_empty() || bit(goals, pos)) return false;
    // Fields plan over walk_terrain (A2_BRIDGES: hole gaps a dash crosses); steps still treat holes as blocked.
    const bc::bitboard fblocked = (blocked & ~w.static_blocked) | w.walk_terrain;
    bc::distance_field field;
    bc::bitboard visited;
    walk_boxed = false;
#if A2_GOV_WALK
    // Search no deeper than the fuel left can pay for. A search the cap stopped (not a truly unreachable goal) takes a
    // greedy step instead of suspending the turn; with room to spare the result is the uncapped one.
    std::uint16_t cap = rb::search_cap(X1_WALK_RESERVE);
    if (cap == 0) {
        ++rb::skipped[rb::kWalk];
        return greedy_step(goals);
    }
    std::uint16_t levels = field.compute_to_with_expansion_count(fblocked, goals, single(pos), visited, cap);
    if (fdist(field, pos) == kUnreach && levels + 1 >= cap) {
        ++rb::capped[rb::kWalk];
        return greedy_step(goals);
    }
    ++rb::ran[rb::kWalk];
    if (fdist(field, pos) == kUnreach) {
        // Units block every route: plan over terrain only and let the step check occupancy.
        bc::bitboard terrain = w.walk_terrain;
        terrain.set(pos, false);
        cap = rb::search_cap(X1_WALK_RESERVE);
        if (cap == 0) {
            ++rb::skipped[rb::kWalkTerrain];
            return greedy_step(goals);
        }
        levels = field.compute_to_with_expansion_count(terrain, goals_in & ~w.static_blocked, single(pos), visited, cap);
        if (fdist(field, pos) == kUnreach) {
            if (levels + 1 >= cap) {
                ++rb::capped[rb::kWalkTerrain];
                return greedy_step(goals);
            }
            walk_unreachable = true;
            return false;
        }
        ++rb::ran[rb::kWalkTerrain];
        walk_boxed = true;
    }
#else
    field.compute_to(fblocked, goals, single(pos), visited);
    if (fdist(field, pos) == kUnreach) {
        // Units block every route: plan over terrain only and let the step check occupancy.
        bc::bitboard terrain = w.walk_terrain;
        terrain.set(pos, false);
        field.compute_to(terrain, goals_in & ~w.static_blocked, single(pos), visited);
        if (fdist(field, pos) == kUnreach) {
            walk_unreachable = true;
            return false;
        }
        walk_boxed = true;
    }
#endif
#if V54_TP
    if (tp_held != 0 && !combat_move && w.enemies.empty() && try_teleport(field)) return true;
#endif
    if (tune::kThreatPath > 0 && !combat_move && hp < max_hp * tune::kThreatHp && travel_around_threats(field, blocked, goals))
        return walked;
#if (A2_TEAM & 1)
    // Team layer, hold: outside fights, a hurt or locally outnumbered champion does not step into a visible enemy's
    // reach (its range + 1); with no other downhill step it holds. Top teams hold distance 56% of such turns, we 25%.
    if (!combat_move && !w.enemies.empty()) {
        int foes = 0, friends = 1;
        for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 6;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 4 && a.hp >= a.max_hp * 0.4f;
        if (hp < max_hp * 0.7f || foes > friends) {
            bc::bitboard reach;
            reach.clear();
            for (const auto& e : w.enemies) reach.draw_chebyshev(e.pos, static_cast<float>(e.range + 1));
            if (!bit(reach, pos)) return follow_field(field, blocked | reach, true);
        }
    }
#endif
#if A2_DANGERMAP
    // Danger map: outside fights, never end a step inside the kill zone - tiles where two turns of visible enemies'
    // hits, their ready spells and a stun round (one ready within 5) would exceed our health (C&I: the weaker body).
    // On the ladder we die 2.3x as often as our opponents, half the time from above 80% health. Skipped when healthy
    // allies within 3 outnumber the foes within 6 (a fight we are in as a group). No safe downhill step: hold.
    if (!combat_move && !w.enemies.empty()) {
        int foes = 0, friends = 1;
        for (const auto& e : w.enemies) foes += e.hp > 0 && cheb(e.pos, pos) <= 6;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 3 && a.hp >= a.max_hp * 0.5f;
        if (foes > 0 && friends <= foes) {
            float my_hp2 = hp;
            if (type == bc::champion_type::cassi || type == bc::champion_type::issac)
                for (const auto& a : w.allies)
                    if (a.type == (type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi))
                        my_hp2 = std::min(my_hp2, a.hp);
            struct Src {
                vec2 p;
                int range;
                float str, nuke;
                bool stun;
            };
            Src src[16];
            int ns = 0;
            for (const auto& e : w.enemies) {
                if (e.hp <= 0 || ns >= 16 || cheb(e.pos, pos) > e.range + 8) continue;
                const auto kit = spell_kit(e.type, e.focus);
                bool ready = false;
                for (std::uint32_t s2 = 0; s2 < 2; ++s2) {
                    std::int32_t cd = 3;
                    if (d::sdk_champion_cooldown(e.id, s2, &cd) == 0 && cd <= 2) ready = true;
                }
                src[ns++] = {e.pos, std::max(1, e.range), e.strength, ready ? kit.nuke : 0.0f, ready && kit.stun};
            }
            bc::bitboard kill;
            kill.clear();
            for (int dy = -3; dy <= 3; ++dy)
                for (int dx = -3; dx <= 3; ++dx) {
                    const vec2 q{pos.x + dx, pos.y + dy};
                    if (q.x < 0 || q.y < 0 || q.x >= w.width || q.y >= w.height) continue;
                    float dmg = 0.0f, round_dmg = 0.0f;
                    bool stun = false;
                    for (int i = 0; i < ns; ++i) {
                        const int d2 = cheb(src[i].p, q);
                        if (d2 <= src[i].range + 1) dmg += 2.0f * src[i].str, round_dmg += src[i].str;
                        else if (d2 <= src[i].range + 2) dmg += src[i].str, round_dmg += src[i].str;
                        if (d2 <= 6) dmg += src[i].nuke;
                        if (src[i].stun && d2 <= 5) stun = true;
                    }
                    if (stun) dmg += round_dmg;
                    if (dmg >= my_hp2) set_bit(kill, q);
                }
            if (!bit(kill, pos)) {
                mode = "danger-avoid";
                return follow_field(field, blocked | kill, true);
            }
        }
    }
#endif
#if A2_THREAT
    // Threat-aware travel: an exposed champion takes a route around the threat zone when the detour is short.
    if (!combat_move && (hp < max_hp * A2_THREAT_HP || gems >= A2_THREAT_GEMS) && a2_route_around(field, blocked, goals))
        return walked;
#endif
    return follow_field(field, blocked, true);
}

#if A2_PLAN
// Team camp plan: every champion computes the same kind of greedy team assignment and takes its own row. Champions:
// us, plus each live ally at its visible position, else at the first camp of the group it claims. Pairs (champion,
// group) are taken best first by gems per turn = solo value / (travel + respawn wait + kill and capture time), one group
// per champion. Groups not safe alone (solo value 0) stay with the usual logic. Returns our group or -1.
int Bot::a2_team_plan() {
    refresh_follow_ups();
    const int n = static_cast<int>(w.groups.size());
    if (n == 0) return -1;
    struct Champ {
        vec2 p;
        int slot;
    };
    Champ ch[kClaimSlots];
    int nc = 0;
    ch[nc++] = {pos, slot};
    for (int s = 0; s < std::min(team_size, kClaimSlots); ++s) {
        if (s == slot) continue;
        const int c = claim_of(s);
        if (c == kClaimDead) continue;
        vec2 p{-1, -1};
        for (const auto& a : w.allies)
            if (s < static_cast<int>(ally_handle.size()) && a.id == ally_handle[static_cast<std::size_t>(s)]) p = a.pos;
        if (p.x < 0 && c >= 0 && c < n && !w.groups[static_cast<std::size_t>(c)].camps.empty())
            p = w.camps[static_cast<std::size_t>(w.groups[static_cast<std::size_t>(c)].camps[0])].pos;
        if (p.x < 0) continue;
        ch[nc++] = {p, s};
    }
    auto travel = [&](int g, vec2 p) {
        if (w.has_field(g)) {
            const int d = w.group_distance(g, p);
            if (d != kUnreach) return d;
        }
        const auto& gr = w.groups[static_cast<std::size_t>(g)];
        return gr.camps.empty() ? 999 : cheb(p, w.camps[static_cast<std::size_t>(gr.camps[0])].pos);
    };
    // Rates computed once (champions x candidate groups), then a greedy pick over the table.
    if (!rb::fits(static_cast<std::uint64_t>(nc) * static_cast<std::uint64_t>(n) * 150 + 10000, 30000)) return -1;
    static std::vector<float> rate;
    static std::vector<int> cand;
    cand.clear();
    for (int g = 0; g < n; ++g)
        if (follow_value[static_cast<std::size_t>(g)] > 0.0f && avoid_until[static_cast<std::size_t>(g)] <= round) cand.push_back(g);
    const int ng = static_cast<int>(cand.size());
    if (ng == 0) return -1;
    rate.assign(static_cast<std::size_t>(nc * ng), 0.0f);
    for (int i = 0; i < nc; ++i)
        for (int k = 0; k < ng; ++k) {
            const int g = cand[static_cast<std::size_t>(k)];
            const int d = travel(g, ch[i].p);
            if (d >= 999) continue;
            const int resp = follow_respawn[static_cast<std::size_t>(g)];
            const int wait = resp >= 0 ? std::max(0, resp - round - d) : 0;
            rate[static_cast<std::size_t>(i * ng + k)] =
                follow_value[static_cast<std::size_t>(g)] / (static_cast<float>(d + wait) + follow_fixed[static_cast<std::size_t>(g)]);
#if A2_PLAN >= 2
            // Stickiness: a champion's current job (ours: target_group; an ally's: its claim) keeps a bonus, so the
            // assignment does not swap champions between groups as travel distances shrink (flip-flopping).
            if (g == (i == 0 ? target_group : claim_of(ch[i].slot))) rate[static_cast<std::size_t>(i * ng + k)] *= 1.3f;
#endif
        }
    bool champ_done[kClaimSlots] = {};
    static std::vector<char> group_done;
    group_done.assign(static_cast<std::size_t>(ng), 0);
    for (int step = 0; step < nc; ++step) {
        float best_rate = 0.0f;
        int bi = -1, bk = -1;
        for (int i = 0; i < nc; ++i) {
            if (champ_done[i]) continue;
            for (int k = 0; k < ng; ++k) {
                const float r = rate[static_cast<std::size_t>(i * ng + k)];
                if (!group_done[static_cast<std::size_t>(k)] && r > best_rate) best_rate = r, bi = i, bk = k;
            }
        }
        if (bi < 0) break;
        champ_done[bi] = true;
        group_done[static_cast<std::size_t>(bk)] = 1;
        if (bi == 0) return cand[static_cast<std::size_t>(bk)];
    }
    return -1;
}
#endif

#if A2_BELIEF
// Enemies out of sight now, last seen 1..A2_BELIEF_AGE rounds ago. Counted when last seen within `radius` of us
// (plus the rounds since, when grow is set: it may have walked closer).
int Bot::a2_hidden_near(int radius, int grow) {
    int n = 0;
    for (const auto& s : a2bel::seen) {
        const int age = round - s.round;
        if (s.id == 0 || age < 1 || age > A2_BELIEF_AGE) continue;
        bool visible = false;
        for (const auto& e : w.enemies) visible |= e.id == s.id;
        if (visible) continue;
        n += cheb(vec2{s.x, s.y}, pos) <= radius + (grow ? age : 0);
    }
    return n;
}

// Basic-attack damage hidden enemies could land on us next turn: walked (and possibly dashed) into reach since seen.
float Bot::a2_hidden_burst() {
    float b = 0.0f;
    for (const auto& s : a2bel::seen) {
        const int age = round - s.round;
        if (s.id == 0 || age < 1 || age > A2_BELIEF_AGE) continue;
        bool visible = false;
        for (const auto& e : w.enemies) visible |= e.id == s.id;
        if (!visible && cheb(vec2{s.x, s.y}, pos) <= s.range + 1 + age) b += s.strength;
    }
    return b;
}
#endif

#if (A2_TEAM & 2)
// Team layer, join: a healthy, light champion that sees an ally within 8 fighting (a visible enemy within 3 of it, and
// that ally not outnumbering its enemies) walks to stand beside that ally, so the fight is taken together. Local and
// visible only (long-range distress calls lost); never while hurt, carrying, capturing or channelling.
bool Bot::a2_join_fight() {
    if (hp < max_hp * 0.6f || gems >= 20 || !bc::self().can_move()) return false;
    if (target_group >= 0 && target_group < static_cast<int>(w.groups.size()) &&
        w.groups[static_cast<std::size_t>(target_group)].state == GroupState::reward && bit(w.groups[static_cast<std::size_t>(target_group)].tiles, pos))
        return false;
    const AllyRec* best = nullptr;
    int best_d = 99;
    for (const auto& a : w.allies) {
        const int d = cheb(a.pos, pos);
        if (d > 8 || d <= 2 || a.hp < a.max_hp * 0.25f) continue;
        int foes = 0, friends = 1;
        for (const auto& e : w.enemies) foes += e.hp > 0 && cheb(e.pos, a.pos) <= 3;
        if (foes == 0) continue;
        for (const auto& b : w.allies) friends += b.id != a.id && cheb(b.pos, a.pos) <= 3;
        if (friends > foes + 1) continue; // already winning there without us
        if (d < best_d || (d == best_d && a.id < best->id)) best = &a, best_d = d;
    }
    if (!best) return false;
    bc::bitboard goal;
    goal.clear();
    goal.draw_chebyshev(best->pos, 1.0f);
    const bool moved = walk_toward(goal);
    if (moved) mode = "join";
    return moved;
}
#endif

#if A2_THREAT
// Tiles enemies could reach soon: Chebyshev discs around sightings up to A2_THREAT_AGE rounds old (visible enemies are
// sightings of this round), radius A2_THREAT_R plus the sighting's age. Built once per round.
const bc::bitboard& Bot::a2_threat_zone(World& world, int now) {
    static bc::bitboard zone;
    static int built = -1;
    if (built != now) {
        built = now;
        zone.clear();
        for (const auto& s : world.sightings) {
            const int age = now - s.round;
            if (age <= A2_THREAT_AGE) zone.draw_chebyshev(s.pos, static_cast<float>(A2_THREAT_R + age));
        }
    }
    return zone;
}

// A route around the threat zone when it is at most A2_THREAT_DETOUR steps longer; false keeps the shortest route.
bool Bot::a2_route_around(const bc::distance_field& field, const bc::bitboard& blocked, const bc::bitboard& goals) {
    if (bc::fuel_remaining() < tune::kMinMoveFuel * 2) return false;
    bc::bitboard zone = a2_threat_zone(w, round);
    if (zone.is_empty() || !bit(zone, pos) && fdist(field, pos) <= 1) return false;
    clear_bit(zone, pos);
    const bc::bitboard safe_goals = goals & ~zone;
    if (safe_goals.is_empty()) return false;
    bc::distance_field safe;
    bc::bitboard visited;
#if A2_GOV_WALK
    const std::uint16_t cap = rb::search_cap(rb::kTailReserve + tune::kMinMoveFuel);
    if (cap == 0) return false;
    safe.compute_to(blocked | zone, safe_goals, single(pos), visited, cap);
#else
    safe.compute_to(blocked | zone, safe_goals, single(pos), visited);
#endif
    const int around = fdist(safe, pos), direct = fdist(field, pos);
    if (around == kUnreach || around > direct + A2_THREAT_DETOUR) return false;
    return follow_field(safe, blocked | zone, true);
}
#endif

#if A2_GOV_WALK
// Governor fallback when no path search fits: one step that brings us strictly closer (Chebyshev) to the nearest
// goal tile, over free tiles. Cheap and legal; the next turn plans properly with a fresh budget.
bool Bot::greedy_step(const bc::bitboard& goals) {
    auto& me = bc::self();
    if (!me.can_move()) return false;
    vec2 goal{-1, -1};
    int gd = 1 << 20;
    for (vec2 g : goals.positions()) {
        const int d = cheb(g, pos);
        if (d < gd) gd = d, goal = g;
    }
    if (goal.x < 0) return false;
    const bc::bitboard blocked = w.static_blocked | w.unit_tiles;
    vec2 best = pos;
    int bd = gd;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(blocked, q)) continue;
        const int d = cheb(q, goal);
        if (d < bd) bd = d, best = q;
    }
    if (best == pos) return false;
    try {
        if (me.move_absolute(best)) {
            pos = best;
            walked = true;
            return true;
        }
    } catch (const std::exception& e) {
        LOG("greedy step error %s\n", e.what());
    }
    return false;
}
#endif

// APEX_THREAT_PATH: take a route that keeps clear of recent enemy sightings when it is only a little
// longer than the shortest one. Returns false (use the shortest route) when no sighting is recent, no goal
// lies outside the zone, the detour is too long, or there is no fuel for a second search.
bool Bot::travel_around_threats(const bc::distance_field& field, const bc::bitboard& blocked, const bc::bitboard& goals) {
    if (bc::fuel_remaining() < tune::kMinMoveFuel * 2) return false;
    bc::bitboard zone;
    zone.clear();
    bool any = false;
    for (const auto& s : w.sightings) {
        const int age = round - s.round;
        if (age > tune::kThreatAge || cheb(s.pos, pos) > 20) continue;
        zone.draw_chebyshev(s.pos, static_cast<float>(tune::kThreatPath + age / 2));
        any = true;
    }
    if (!any) return false;
    clear_bit(zone, pos);
    const bc::bitboard safe_goals = goals & ~zone;
    if (safe_goals.is_empty()) return false;
    bc::distance_field safe;
    bc::bitboard visited;
#if A2_GOV_WALK
    // Capped like walk_toward; a detour the cap cuts off reads as unreachable and the shortest route is used.
    const std::uint16_t cap = rb::search_cap(rb::kTailReserve + tune::kMinMoveFuel);
    if (cap == 0) {
        ++rb::skipped[rb::kThreatPath];
        return false;
    }
    ++rb::ran[rb::kThreatPath];
    safe.compute_to(blocked | zone, safe_goals, single(pos), visited, cap);
#else
    safe.compute_to(blocked | zone, safe_goals, single(pos), visited);
#endif
    const int around = fdist(safe, pos), direct = fdist(field, pos);
    if (around == kUnreach || around > direct + tune::kThreatDetour) return false;
    follow_field(safe, blocked | zone, true);
    return true;
}

// A bush tile no nearby enemy shares a cluster with: they cannot see it, so cannot target us there.
bool Bot::hidden_from_threats(vec2 q) {
    if (!tune::kHideLos) {
        if (w.bush_cluster(q) < 0 || w.warded(w.bush_cluster(q))) return false;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, q) <= 9 && !w.bush_hides(q, e.pos)) return false;
        return true;
    }
    // Full line of sight: out of every nearby enemy's vision (walls and bushes block it).
    if (threat_vision_round != round) {
        threat_vision_round = round;
        threat_vision.clear();
        for (const auto& e : w.enemies) {
            if (cheb(e.pos, pos) > 10 || threat_vision.size() >= 5) continue;
            w.vision_from(e.pos, threat_vision.emplace_back());
        }
    }
    for (const auto& vis : threat_vision)
        if (bit(vis, q)) return false;
    return true;
}

// NOVA_BUDDY: a fixed partner slot (-1 = none). Cassi and Issac pair (one fate); the others pair a melee
// champion with a ranged one where possible, in slot order; an odd champion out farms alone.
int Bot::buddy() {
    if (buddy_slot != -2) return buddy_slot;
    const int n = std::min(team_size, kClaimSlots);
    std::array<int, 8> partner;
    partner.fill(-1);
    auto melee_type = [](bc::champion_type t) {
        return t == bc::champion_type::ryth || t == bc::champion_type::vendetta || t == bc::champion_type::issac ||
            t == bc::champion_type::marcella || t == bc::champion_type::ren || t == bc::champion_type::varg;
    };
    int ci = -1, is = -1;
    for (int s = 0; s < n; ++s) {
        if (slot_type[static_cast<std::size_t>(s)] == bc::champion_type::cassi) ci = s;
        if (slot_type[static_cast<std::size_t>(s)] == bc::champion_type::issac) is = s;
    }
    if (ci >= 0 && is >= 0) {
        partner[static_cast<std::size_t>(ci)] = is;
        partner[static_cast<std::size_t>(is)] = ci;
    }
    std::vector<int> mel, rng;
    for (int s = 0; s < n; ++s)
        if (partner[static_cast<std::size_t>(s)] < 0) (melee_type(slot_type[static_cast<std::size_t>(s)]) ? mel : rng).push_back(s);
    auto link = [&](int a, int b) {
        partner[static_cast<std::size_t>(a)] = b;
        partner[static_cast<std::size_t>(b)] = a;
    };
    std::size_t i = 0, j = 0;
    for (; i < mel.size() && j < rng.size(); ++i, ++j) link(mel[i], rng[j]);
    std::vector<int> rest(mel.begin() + static_cast<std::ptrdiff_t>(i), mel.end());
    rest.insert(rest.end(), rng.begin() + static_cast<std::ptrdiff_t>(j), rng.end());
    for (std::size_t k = 0; k + 1 < rest.size(); k += 2) link(rest[k], rest[k + 1]);
    buddy_slot = slot < 8 ? partner[static_cast<std::size_t>(slot)] : -1;
    debug_block({ std::printf("BUDDY slot %d %s -> %d\n", slot, bc::to_string(type).c_str(), buddy_slot); });
    return buddy_slot;
}

// Where our buddy works: its claimed group, else where we see it; (-1, -1) when unknown, dead or alone.
vec2 Bot::buddy_anchor() {
    const int b = buddy();
    if (b < 0) return {-1, -1};
    const int c = claim_of(b);
    if (c >= 0 && c < static_cast<int>(w.groups.size()) && !w.groups[static_cast<std::size_t>(c)].camps.empty())
        return w.camps[static_cast<std::size_t>(w.groups[static_cast<std::size_t>(c)].camps[0])].pos;
    if (c == static_cast<int>(kClaimCodeDead)) return {-1, -1};
    for (const auto& a : w.allies)
        if (a.id == ally_handle[static_cast<std::size_t>(b)]) return a.pos;
    return {-1, -1};
}

// NOVA_FIGHT2 bit 4, regroup: flee toward the nearest healthy teammate that stands farther from the threat
// than we do (top bots keep a teammate within 3 tiles in 57% of contact turns, we in 28%).
bool Bot::regroup_from(vec2 threat) {
    const AllyRec* best = nullptr;
    int best_d = 1 << 20;
    const int mine = cheb(pos, threat);
    for (const auto& a : w.allies) {
        if (a.id == my_id || a.hp < a.max_hp * 0.3f) continue;
        const int d = cheb(a.pos, pos);
        if (d < 2 || d > 12 || cheb(a.pos, threat) <= mine) continue;
        if (d < best_d) {
            best_d = d;
            best = &a;
        }
    }
    if (!best) return false;
    bc::bitboard goal;
    goal.clear();
    goal.draw_chebyshev(best->pos, 1.0f);
    return walk_toward(goal);
}

bool Bot::retreat_from(vec2 threat) {
    auto& me = bc::self();
    if (!me.can_move()) return false;
    // Step to the free neighbour that is farthest from the threat, breaking ties toward spawn. A
    // hidden unit on the tile makes the move return false without spending it, so fall through to
    // the next-best tile.
    struct Cand {
        vec2 p;
        int score;
    };
    Cand cands[8];
    int n = 0;
    // Optionally run toward the nearest healthy ally: the chaser follows us into its reach.
    const AllyRec* friend_near = nullptr;
    if (tune::kFleeAlly > 0)
        for (const auto& a : w.allies)
            if (a.hp >= a.max_hp * 0.5f && cheb(a.pos, pos) <= 10 &&
                (!friend_near || cheb(a.pos, pos) < cheb(friend_near->pos, pos)))
                friend_near = &a;
    auto ally_pull = [&](vec2 q) { return friend_near ? tune::kFleeAlly * cheb(q, friend_near->pos) : 0; };
    // Spawn heals fully and enemies cannot enter it; APEX_FLEE_HOME weights the way home.
    const int home_w = 1 + tune::kFleeHome;
    // Distance from the threats: the nearest one, or (APEX_FLEE_MULTI, two or more enemies close)
    // every visible enemy weighted by its damage share.
    float total_dps = 0.0f;
    int close = 0;
    if (tune::kFleeMulti)
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= 8) ++close, total_dps += e.strength + e.focus * 0.25f;
    auto away = [&](vec2 q) {
        if (close < 2 || total_dps <= 0.0f) return cheb(q, threat) * 100;
        float sum = 0.0f;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= 8) sum += static_cast<float>(std::min(cheb(q, e.pos), 6)) * (e.strength + e.focus * 0.25f);
        return static_cast<int>(sum / total_dps * 100.0f);
    };
    int here = away(pos) - home_w * fdist(w.spawn_field, pos) - ally_pull(pos);
    if (tune::kBushHide && hidden_from_threats(pos)) here += tune::kBushHide;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
        int sc = away(q) - home_w * static_cast<int>(fdist(w.spawn_field, q)) - ally_pull(q);
        if (tune::kBushHide && hidden_from_threats(q)) sc += tune::kBushHide;
        if (sc <= here) continue;
        int i = n++;
        for (; i > 0 && cands[i - 1].score < sc; --i) cands[i] = cands[i - 1];
        cands[i] = {q, sc};
    }
    for (int i = 0; i < n; ++i) {
        try {
            if (me.move_absolute(cands[i].p)) {
                pos = cands[i].p;
                walked = true;
                return true;
            }
        } catch (...) {
        }
    }
    return false;
}

// ---------------------------------------------------------------- combat helpers

float Bot::my_dps(const GroupRec* g) const {
#if V55_HEART_MODEL
    float dps = cached_dps;
#else
    float dps = strength;
    for (int s = 0; s < 2; ++s) {
        const auto& sp = spells[s];
        if (!sp.present) continue;
        if (sp.kind == bc::ability_kind::attack_reset) dps += strength / 8.0f;
        if ((sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc || sp.kind == bc::ability_kind::aoe_damage)
            && sp.camps)
            dps += sp.modifier * focus / 8.0f;
    }
#endif
    if (type == bc::champion_type::varg && g && g->camps.size() > 1) dps *= 1.6f;
    if (g) dps *= camp_dealt_mult;
#if V58_PATCH
    else dps *= champion_dealt_mult;
#endif
    return std::max(dps, 1.0f);
}

bool Bot::attack_unit(const bc::unit& target, vec2 where) {
    auto& me = bc::self();
    if (!me.can_attack() || cheb(pos, where) > range) return false;
    try {
        me.attack(target);
        return true;
    } catch (const std::exception& e) {
        LOG("attack error %s\n", e.what());
        return false;
    }
}

#if A2_BURST_HOLD
// A2_BURST_HOLD (duel lab, E32): Tavi, Willow, Ren and Vendetta spend their burst (spell, reset combo) in lone duels while
// behind on health where a plain attack or step scored better; set per turn in handle_enemies.
static bool a2_hold_burst = false;
#endif
bool Bot::use_reset_and_attack(const bc::unit& target, vec2 where) {
#if A2_BURST_HOLD
    if (a2_hold_burst) return false;
#endif
#if A2_RESETFIX
    // A2_RESETFIX: the first hit may have killed the target; the reset then went to a dead unit (the follow-up attack
    // failed). Hit another living enemy champion in reach instead (lowest health), or keep the reset.
    {
        bool alive = false;
        try {
            alive = target.is_visible() && target.health() > 0.0f;
        } catch (...) {
        }
        if (!alive) {
            const EnemyRec* nt = nullptr;
            for (const auto& e : w.enemies) {
                if (e.pos == where || cheb(e.pos, pos) > range) continue;
                bool ok = false;
                try {
                    ok = e.unit.is_visible() && e.unit.health() > 0.0f;
                } catch (...) {
                }
                if (ok && (!nt || e.hp < nt->hp)) nt = &e;
            }
            if (!nt) return false;
            for (int s = 0; s < 2; ++s) {
                if (!spell_ready(s) || spells[s].kind != bc::ability_kind::attack_reset) continue;
                try {
                    if (bc::self().abilities()[s].use()) {
                        cast_done = true;
                        return attack_unit(nt->unit, nt->pos);
                    }
                } catch (const std::exception& e) {
                    LOG("reset error2 %s\n", e.what());
                }
            }
            return false;
        }
    }
#endif
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s) || spells[s].kind != bc::ability_kind::attack_reset) continue;
        try {
            if (bc::self().abilities()[s].use()) {
                cast_done = true;
#if A2_MICLOG
                const bool ok2 = attack_unit(target, where);
                std::printf("RS %d %d %d %d\n", round, slot, static_cast<int>(type), ok2 ? 1 : 0);
                return ok2;
#else
                return attack_unit(target, where);
#endif
            }
        } catch (const std::exception& e) {
            LOG("reset error %s\n", e.what());
        }
    }
    return false;
}

#if V55_HEART_CAMP
bool Bot::cast_camp_strike(int ci) {
    if (type != bc::champion_type::heart_of_ruin || cast_done) return false;
    const auto& target = w.camps[static_cast<std::size_t>(ci)];
    const int gi = w.camp_group[static_cast<std::size_t>(ci)];
    if (gi < 0 || !bit(w.visible, target.pos)) return false;
    for (int s = 0; s < 2; ++s) {
        const auto& sp = spells[s];
        if (!spell_ready(s) || sp.kind != bc::ability_kind::dash || sp.modifier <= 0.0f) continue;
        const int radius = std::max(1, static_cast<int>(sp.radius));
        if (cheb(pos, target.pos) > static_cast<int>(sp.range) + radius) continue;
        vec2 best{-1, -1};
        int best_hits = 0, best_home = kUnreach;
        for (int dx = -radius; dx <= radius; ++dx) for (int dy = -radius; dy <= radius; ++dy) {
            const vec2 q{target.pos.x + dx, target.pos.y + dy};
            if (!in_bounds(q, w.width, w.height) || q == pos || cheb(pos, q) > static_cast<int>(sp.range) ||
                bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
            bool extra_group = false;
            for (int x = -radius; x <= radius; ++x) for (int y = -radius; y <= radius; ++y) {
                const int other = w.group_of_camp_tile({q.x + x, q.y + y});
                if (other >= 0 && other != gi && w.groups[static_cast<std::size_t>(other)].state == GroupState::alive) extra_group = true;
            }
            if (extra_group) continue;
            int hits = 0;
            for (int c : w.groups[static_cast<std::size_t>(gi)].camps)
                if (!w.camps[c].dead && bit(w.visible, w.camps[c].pos) && cheb(w.camps[c].pos, q) <= radius) ++hits;
            const int home = fdist(w.spawn_field, q);
            if (hits > best_hits || (hits == best_hits && home < best_home)) best = q, best_hits = hits, best_home = home;
        }
        if (best.x < 0 || best_hits <= 0) return false;
        try {
            if (bc::self().abilities()[s].use(best)) {
                pos = best;
                cast_done = true;
                return true;
            }
        } catch (...) { }
    }
    return false;
}
#endif

bool Bot::cast_on_camp(int ci) {
#if A2_TEL && X1_TEL
    PROF_CHECK("cc_in");
    struct X1Out { ~X1Out() { PROF_CHECK("cc_out"); } } x1_out;
#endif
    const auto& c = w.camps[ci];
    if (tune::kSpellHold & 1) {
        // An enemy is (or was just) near: keep the spells for it.
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= tune::kSpellHoldRange) return false;
        for (const auto& sg : w.sightings)
            if (round - sg.round <= tune::kSpellHoldAge && cheb(sg.pos, pos) <= tune::kSpellHoldRange) return false;
    }
#if V55_HEART_CAMP
    if (cast_camp_strike(ci)) return true;
#endif
    int best = -1;
    float best_value = 0;
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s)) continue;
        const auto& sp = spells[s];
        if (sp.excludes_walk && walked) continue;
        if (cheb(pos, c.pos) > static_cast<int>(sp.range)) continue;
        // Stuns win champion fights; on a camp they only add a little damage.
        if ((tune::kSpellHold & 2) && (sp.kind == bc::ability_kind::cc || (type == bc::champion_type::ryth && s == 0)))
            continue;
        float value = 0;
        if ((sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc) && sp.camps)
            value = sp.modifier * focus;
        else if (sp.kind == bc::ability_kind::aoe_damage && sp.camps) {
            int hits = 0;
            for (int other : w.groups[w.group_of_camp_tile(c.pos)].camps)
                if (!w.camps[other].dead && cheb(w.camps[other].pos, c.pos) <= static_cast<int>(sp.radius)) ++hits;
            value = sp.modifier * focus * static_cast<float>(hits);
        }
        if (value > best_value) {
            best_value = value;
            best = s;
        }
    }
    if (best < 0) return false;
    try {
        const auto ab = bc::self().abilities()[best];
        const bool ok = spells[best].kind == bc::ability_kind::aoe_damage ? ab.use(c.pos) : ab.use(c.camp);
        if (ok) cast_done = true;
#ifdef APEX_SPELLSTAT
        if (ok) ++spellstat_camp;
#endif
        return ok;
    } catch (const std::exception& e) {
        LOG("camp cast error %s\n", e.what());
        return false;
    }
}

static bool enemy_stunned(const EnemyRec& e);
bool Bot::cast_on_enemy(const EnemyRec& e) {
#if A2_BURST_HOLD
    if (a2_hold_burst) return false;
#endif
    int best = -1;
    float best_value = 0;
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s)) continue;
        const auto& sp = spells[s];
        if (sp.excludes_walk && walked) continue;
        // NOVA_AOE_AIM: a ground area spell reaches range + radius (aimed at a tile short of the target).
        const int reach_s = (NOVA_AOE_AIM && sp.kind == bc::ability_kind::aoe_damage && sp.ground)
            ? static_cast<int>(sp.range + sp.radius) : static_cast<int>(sp.range);
        if (!sp.enemies || cheb(pos, e.pos) > reach_s) continue;
        float value = 0;
        if (sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::aoe_damage) value = sp.modifier * focus;
        if (sp.kind == bc::ability_kind::cc) {
            value = sp.modifier * focus + 120.0f; // stuns stop escapes
            if (keep_channel && e.tributing()) continue; // the stun would end its channel and free it
            if (e.tributing()) value += 400.0f;  // and cancel a tribute channel
        }
        if (value > best_value) {
            best_value = value;
            best = s;
        }
    }
    // Engine 3.0 striking dash (Heart of Ruin: 1.75 x Focus and a stun around the landing tile): land within 2 tiles so
    // the target is inside the landing radius, preferring tiles that also hit other enemies and wake no camps.
    vec2 dash_aim{-1, -1};
    int dash_slot = -1;
    for (int s = 0; s < 2; ++s) {
        const auto& sp = spells[s];
        if (!spell_ready(s) || sp.kind != bc::ability_kind::dash || sp.modifier <= 0.0f) continue;
        const int rad = std::max(1, static_cast<int>(sp.radius));
        if (cheb(pos, e.pos) > static_cast<int>(sp.range) + rad) continue;
        const float value = sp.modifier * focus + 120.0f;
        if (value <= best_value) continue;
        int best_hits = -1000;
        for (int dy = -rad; dy <= rad; ++dy)
            for (int dx = -rad; dx <= rad; ++dx) {
                const vec2 t{e.pos.x + dx, e.pos.y + dy};
                if (!in_bounds(t, w.width, w.height) || t == e.pos || cheb(pos, t) > static_cast<int>(sp.range) || t == pos ||
                    bit(w.static_blocked, t) || bit(w.unit_tiles, t))
                    continue;
                int hits = 0;
                for (const auto& o : w.enemies)
                    if (o.id != e.id && cheb(o.pos, t) <= rad) hits += 2;
                for (const auto& c : w.camps)
                    if (!c.dead && cheb(c.pos, t) <= rad) hits -= 3;
                if (hits > best_hits) best_hits = hits, dash_aim = t;
            }
        if (best_hits > -1000) {
            dash_slot = s;
            best_value = value;
        }
    }
    if (dash_slot >= 0) {
        try {
            if (bc::self().abilities()[dash_slot].use(dash_aim)) {
#if A2_MICLOG
                std::printf("CD %d %d %d %d %d %d\n", round, slot, static_cast<int>(type), static_cast<int>(e.type), cheb(pos, e.pos), cheb(dash_aim, e.pos));
#endif
                pos = dash_aim;
                cast_done = true;
                return true;
            }
        } catch (const std::exception& ex) {
            LOG("strike dash error %s\n", ex.what());
        }
    }
    if (best < 0) return false;
    try {
        const auto ab = bc::self().abilities()[best];
        vec2 aim = e.pos;
        if (NOVA_AOE_AIM && spells[best].kind == bc::ability_kind::aoe_damage && spells[best].ground) {
            // NOVA_AOE_AIM (from the review of OpenAI Five's offset targets): among the tiles within range whose area
            // still covers the target, take the one that also covers the most other enemies, without waking camps.
            const int rad = static_cast<int>(spells[best].radius);
            const int rng = static_cast<int>(spells[best].range);
            int best_hits = -1000;
            for (int dy = -rad; dy <= rad; ++dy)
                for (int dx = -rad; dx <= rad; ++dx) {
                    const vec2 t{e.pos.x + dx, e.pos.y + dy};
                    if (!in_bounds(t, w.width, w.height) || cheb(pos, t) > rng) continue;
                    int hits = 0;
                    for (const auto& o : w.enemies)
                        if (o.id != e.id && cheb(o.pos, t) <= rad) hits += 2;
                    for (const auto& c : w.camps)
                        if (!c.dead && cheb(c.pos, t) <= rad) hits -= 3;
                    if (dx == 0 && dy == 0) hits += 1; // ties: centre on the target
                    if (hits > best_hits) {
                        best_hits = hits;
                        aim = t;
                    }
                }
            if (best_hits == -1000) return false;
        }
        const bool ok = spells[best].kind == bc::ability_kind::aoe_damage ? ab.use(aim) : ab.use(e.unit);
        if (ok) cast_done = true;
#if A2_MICLOG
        std::printf("CE %d %d %d %d %d %d %d %d %d\n", round, slot, static_cast<int>(type), best, static_cast<int>(spells[best].kind),
            static_cast<int>(e.type), enemy_stunned(e) ? 1 : 0, ok ? 1 : 0, cheb(pos, e.pos));
#endif
#ifdef APEX_SPELLSTAT
        if (ok) ++spellstat_enemy;
#endif
        return ok;
    } catch (const std::exception& ex) {
        LOG("enemy cast error %s\n", ex.what());
        return false;
    }
}

// Shields and heals that do not depend on a target choice.
void Bot::support_casts() {
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s)) continue;
        const auto& sp = spells[s];
        try {
            // With APEX_SHIELD_PVP the shield is kept for champion fights (an enemy within 5).
            bool enemy_close = false;
            for (const auto& e : w.enemies) enemy_close |= cheb(e.pos, pos) <= 5;
            bool want_shield = tune::kShieldPvp ? enemy_close && hp < max_hp * 0.95f
                                                : hp < max_hp * 0.85f && (!w.enemies.empty() || target_group >= 0);
#if A2_SHIELDLATE
            // A2_SHIELDLATE: one cast per turn, and this runs before the fight logic. Heart of Ruin with its striking dash
            // ready and an enemy within its reach (3) keeps the turn's cast for the dash (damage and a stun) unless hurt;
            // the shield waits for the next turn (or for the end of this one if the dash was not used).
            if (want_shield && !shield_late_pass && type == bc::champion_type::heart_of_ruin && hp >= max_hp * 0.4f) {
                bool dash_ready = false;
                for (int s2 = 0; s2 < 2; ++s2)
                    dash_ready |= spell_ready(s2) && spells[s2].kind == bc::ability_kind::dash && spells[s2].modifier > 0.0f;
                bool near3 = false;
                for (const auto& e : w.enemies) near3 |= cheb(e.pos, pos) <= 3;
#if V55_HEART_CAMP
                if (dash_ready && !near3 && hp >= max_hp * 0.6f && target_group >= 0 &&
                    target_group < static_cast<int>(w.groups.size()) && w.groups[target_group].state == GroupState::alive)
                    for (int ci : w.groups[target_group].camps)
                        if (!w.camps[ci].dead && bit(w.visible, w.camps[ci].pos) && cheb(w.camps[ci].pos, pos) <= 3) near3 = true;
#endif
                if (dash_ready && near3) want_shield = false;
            }
#endif
            if (sp.kind == bc::ability_kind::shield && want_shield) {
                if (bc::self().abilities()[s].use()) cast_done = true;
#if A2_MICLOG
                {
                    int nd = 99;
                    for (const auto& e : w.enemies) nd = std::min(nd, cheb(e.pos, pos));
                    std::printf("SH %d %d %d %.2f %d %d\n", round, slot, static_cast<int>(type), hp / std::max(1.0f, max_hp), nd, cast_done ? 1 : 0);
                }
#endif
            } else if (sp.kind == bc::ability_kind::heal) {
                const AllyRec* best = nullptr;
                float best_missing = sp.modifier * focus * 0.6f;
                for (const auto& a : w.allies) {
                    if (cheb(a.pos, pos) > static_cast<int>(sp.range)) continue;
                    const float missing = a.max_hp - a.hp;
                    if (missing > best_missing) {
                        best_missing = missing;
                        best = &a;
                    }
                }
                if (best && bc::self().abilities()[s].use(best->unit)) cast_done = true;
            }
        } catch (const std::exception& e) {
            LOG("support cast error %s\n", e.what());
        }
    }
}

// ---------------------------------------------------------------- behaviours

namespace {
// Rough damage per turn: basic attacks plus an averaged spell (about 2x focus every 8 turns).
float enemy_dps(const EnemyRec& e) { return e.strength + e.focus * 0.25f; }
float ally_dps(const AllyRec& a) { return std::max(a.strength * 1.15f, 30.0f) + 12.0f; }
} // namespace

// Lock any altar within reach that has no lock: our team still tributes there, while enemies must
// spend three basic attacks on it first (their tribute attempts turn into those attacks).
void Bot::prelock_altars() {
#if V58_LOCKS
    locks_objective();
#endif
    // Lab knob 42: k > 0 prelocks (without APEX_PRELOCK) once the enemy has banked max(0, 600 - 300k).
    const bool prelock = tune::kPrelock || LABK(42) > 0.0f;
    const int prelock_score = tune::kPrelock ? tune::kPrelockScore : std::max(0, static_cast<int>(600.0f - 300.0f * LABK(42)));
    if (!prelock || enemy_score < prelock_score) return;
    auto& me = bc::self();
    try {
        auto& lock = me.consumables()[bc::consumable_type::altar_lock];
        if (lock.count() == 0) return;
        for (vec2 a : w.altars) {
            if (cheb(a, pos) > 2 || bc::vision::has_altar_lock(a)) continue;
            if (lock.use(a)) return;
        }
    } catch (const std::exception& ex) {
        LOG("prelock error %s\n", ex.what());
    }
}

// An enemy channelling a tribute at an altar we can reach: our lock cancels the channel.
bool Bot::try_lock_altar() {
    auto& me = bc::self();
    try {
        auto& lock = me.consumables()[bc::consumable_type::altar_lock];
        if (lock.count() == 0) return false;
        for (const auto& e : w.enemies) {
            if (!e.tributing() || e.gems < 10) continue;
            for (vec2 a : w.altars) {
                if (cheb(a, e.pos) > bc::constants::submit_gems_range || cheb(a, pos) > 2) continue;
                if (bc::vision::has_altar_lock(a)) continue;
                if (lock.use(a)) {
                    LOG("R%d LOCK altar (%d,%d) vs carrier gems=%d\n", round, a.x, a.y, e.gems);
                    return true;
                }
            }
        }
    } catch (const std::exception& ex) {
        LOG("lock error %s\n", ex.what());
    }
    return false;
}

// Bush ambush: a bush tile in a cluster that no visible enemy stands in is invisible to all of them,
// and attacking from it does not reveal us (bots/probe_bush). When such a tile here, or one step
// away, reaches an enemy, fight from it: hit from here, or step in (melee then still hits).
bool Bot::bush_ambush() {
    if (!tune::kBushAmbush || w.enemies.empty()) return false;
    // NOVA_AMBUSH_SAFE: cover does not stop wards, area spells or enemies stepping into the bush; a hurt
    // champion takes the usual fight-or-flee decision instead (Cassi died ambushing from 130 health).
    if (NOVA_AMBUSH_SAFE > 0.0f && hp < max_hp * NOVA_AMBUSH_SAFE) return false;
    auto& me = bc::self();
    auto hidden = [&](vec2 q) {
        const int cq = w.bush_cluster(q);
        if (cq < 0 || w.warded(cq)) return false;
        for (const auto& e : w.enemies)
            if (w.bush_cluster(e.pos) == cq) return false;
        return true;
    };
    // The enemy to hit from tile q: carried gems first, then lowest health; none on their spawn.
    auto victim_from = [&](vec2 q, float& key) -> const EnemyRec* {
        const EnemyRec* best = nullptr;
        key = 1e30f;
        for (const auto& e : w.enemies) {
            if (cheb(e.pos, q) > range || bit(w.enemy_spawn, e.pos)) continue;
            const float k = e.hp - 20.0f * static_cast<float>(e.gems);
            if (k < key) {
                key = k;
                best = &e;
            }
        }
        return best;
    };
    float key = 0.0f;
    const EnemyRec* victim = hidden(pos) ? victim_from(pos, key) : nullptr;
    vec2 step = pos;
    if (!victim && me.can_move()) {
        float best_key = 1e30f;
        for (vec2 dir : kDirs) {
            const vec2 q = pos + dir;
            if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q) || bit(w.hot_zone, q) ||
                !hidden(q))
                continue;
            const EnemyRec* v = victim_from(q, key);
            if (v && key < best_key) {
                best_key = key;
                step = q;
                victim = v;
            }
        }
    }
    if (!victim && tune::kBushAmbush >= 2 && hidden(pos)) {
        // From cover, spells reach further than a basic attack (4 tiles): cast at the weakest enemy in
        // spell reach. Casting does not reveal us either.
        const EnemyRec* best = nullptr;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= 4 && !bit(w.enemy_spawn, e.pos) && (!best || e.hp < best->hp)) best = &e;
        if (best && cast_on_enemy(*best)) {
            mode = "ambush-cast";
            return true;
        }
    }
    if (!victim) return false;
    if (step != pos) {
        try {
            if (!me.move_absolute(step)) return false; // an unseen unit holds the tile
        } catch (...) {
            return false;
        }
        pos = step;
        walked = true;
        if (!melee) {
            mode = "ambush-step"; // ranged: the step used the attack; we hit from cover next turn
            return true;
        }
    }
    mode = "ambush";
    cast_on_enemy(*victim);
    if (attack_unit(victim->unit, victim->pos)) use_reset_and_attack(victim->unit, victim->pos);
    return true;
}

// Turn order (APEX_PRIORITY): a champion in contact with enemies asks to act early next round, so
// it strikes, finishes a kill or steps out of reach before enemies placed later in the round act.
void Bot::update_priority() {
    if (!tune::kPriority) return;
    int nearest = 99;
    for (const auto& e : w.enemies) nearest = std::min(nearest, cheb(e.pos, pos));
    int want = 0;
    const int mode = tune::kPriority;
    if (nearest <= 8) {
        want = 100 + (8 - nearest) * 10;
        // 2, 5: the weaker we are, the earlier we act (escape before the chaser moves).
        want += (mode == 2 || mode == 5) ? static_cast<int>(60.0f * (1.0f - hp / max_hp)) : (hp < max_hp * 0.5f ? 5 : 0);
        // 3, 5: a kill is available in reach: act first and take it (and the bag).
        if (mode == 3 || mode == 5)
            for (const auto& e : w.enemies)
                if (cheb(e.pos, pos) <= range + 1 && e.hp <= strength * 2.0f + focus * 2.0f) want += 200;
    } else if (mode == 4 || mode == 5) {
        // 4, 5: an enemy was seen close by in the last two rounds: contact is likely next round.
        for (const auto& s : w.sightings)
            if (round - s.round <= 2 && cheb(s.pos, pos) <= 10) want = std::max(want, 50);
    }
    if (want == priority_set) return;
    try {
        bc::self().set_priority(want);
        priority_set = want;
    } catch (const std::exception& e) {
        LOG("priority error %s\n", e.what());
    }
}

// Ward reveal (APEX_WARD_REVEAL): a ward inside a bush cluster shows us everyone in it. Ward the bush
// that must hold an invisible attacker (health lost that no visible enemy or camp explains), or the
// bush an enemy seen close by last round vanished into. Returns true when a ward was placed.
// NOVA_WARD_AHEAD: keep our ward in the bush cluster beside us that no ally ward covers (top teams ward bushes ahead
// of time; we warded only after a surprise hit).
bool Bot::ward_ahead() {
    if (!w.enemies.empty()) return false;
    if (ward_pos.x >= 0 && cheb(ward_pos, pos) <= NOVA_WARD_AHEAD + static_cast<int>(std::lround(2.0f * LABK(39)))) return false; // our ward still covers this area
    auto& me = bc::self();
    try {
        if (me.ward_cooldown() > 0) return false;
    } catch (...) {
        return false;
    }
#if A2_GOV_WARD
    // First use of a bush cluster labels all of it (~70k for 100-149 tiles with the fast labeller). Warding ahead can
    // wait for a turn with room: without room for a worst-case labelling plus the turn tail, skip when any cluster this
    // would label is still unlabelled.
    if (!rb::fits(70000, rb::kTailReserve)) {
        bool unlabeled = false;
        for (int dy = -2; dy <= 2 && !unlabeled; ++dy)
            for (int dx = -2; dx <= 2 && !unlabeled; ++dx) {
                const vec2 q{pos.x + dx, pos.y + dy};
                unlabeled = in_bounds(q, w.width, w.height) && bit(w.bushes, q) && !bit(w.bush_labeled, q);
            }
        if (!unlabeled)
            for (vec2 p : bc::vision::ward_tiles(team::ally).positions())
                if (bit(w.bushes, p) && !bit(w.bush_labeled, p)) {
                    unlabeled = true;
                    break;
                }
        if (unlabeled) {
            ++rb::skipped[rb::kWardAhead];
            return false;
        }
    }
    ++rb::ran[rb::kWardAhead];
#endif
    const int mine = w.bush_cluster(pos);
    // Clusters already under an allied ward.
    std::array<int, 16> covered{};
    int n_cov = 0;
    try {
        const bc::bitboard wt = bc::vision::ward_tiles(team::ally);
        if (!wt.is_empty())
            for (vec2 p : wt.positions()) {
                const int c = w.bush_cluster(p);
                if (c >= 0 && n_cov < 16) covered[n_cov++] = c;
            }
    } catch (...) {
    }
    vec2 aim = pos;
    if (target_group >= 0 && target_group < static_cast<int>(w.groups.size()) && !w.groups[target_group].camps.empty())
        aim = w.camps[w.groups[target_group].camps[0]].pos;
    vec2 best{-1, -1};
    int best_d = 1 << 20;
    for (int dy = -2; dy <= 2; ++dy)
        for (int dx = -2; dx <= 2; ++dx) {
            const vec2 q{pos.x + dx, pos.y + dy};
            if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q)) continue;
            const int c = w.bush_cluster(q);
            if (c < 0 || c == mine) continue;
            bool cov = false;
            for (int k = 0; k < n_cov; ++k) cov |= covered[k] == c;
            if (cov) continue;
            const int d = cheb(q, aim) * 4 + cheb(q, pos);
            if (d < best_d) {
                best_d = d;
                best = q;
            }
        }
    if (best.x < 0) return false;
    try {
        if (me.place_ward(best)) {
            ward_pos = best;
            return true;
        }
    } catch (const std::exception& e) {
        LOG("ward ahead error %s\n", e.what());
    }
    return false;
}

#if A2_FOG
// Fog belief (ladder scrims: 75% of our deaths are single pick-offs mid-map, 44% outnumbered, a third from >70% health):
// enemies out of sight are where they were last seen, plus one tile per round since. Counts the sightings (ours and
// teammates' via shared memory) up to A2_FOG_AGE rounds old that could reach `at`, one per 3x3 cell so an enemy seen on
// several rounds counts once.
int Bot::fog_threat(vec2 at) const {
    std::array<std::int32_t, 16> cells{};
    int n = 0;
    for (const auto& s : w.sightings) {
        const int age = round - s.round;
        if (age < 0 || age > A2_FOG_AGE || cheb(s.pos, at) > A2_FOG_R + age) continue;
        const std::int32_t cell = (s.pos.x / 3) * 4096 + s.pos.y / 3;
        bool dup = false;
        for (int k = 0; k < n; ++k) dup |= cells[static_cast<std::size_t>(k)] == cell;
        if (!dup && n < 16) cells[static_cast<std::size_t>(n++)] = cell;
    }
    return n;
}

// An exposed champion (hurt or carrying) with more possible unseen enemies around than allies beside it walks to the
// nearest ally instead of farming alone.
bool Bot::fog_regroup() {
    if (!w.enemies.empty() || w.allies.empty()) return false;
    if (hp >= max_hp * A2_FOG_HP && gems < A2_FOG_GEMS) return false;
    int near = 0;
    const AllyRec* best = nullptr;
    for (const auto& a : w.allies) {
        const int d = cheb(a.pos, pos);
        if (d <= 5) ++near;
        if (d <= 20 && (!best || d < cheb(best->pos, pos))) best = &a;
    }
    if (!best || cheb(best->pos, pos) <= 2) return false;
    if (fog_threat(pos) < near + A2_FOG_MARGIN) return false;
    bc::bitboard goal;
    goal.clear();
    goal.draw_chebyshev(best->pos, 2.0f);
    mode = "fog-regroup";
    return walk_toward(goal);
}
#endif

#if A2_DPLAN
// Draft-turn team plan (draft.cpp team_plan_bytes): this slot's steps, read once from draft memory after the brain header.
void Bot::dplan_load() {
    dplan_loaded = true;
    try {
        const auto& mem = bc::draft_memory;
        if (mem.size() < 10 || static_cast<std::uint8_t>(mem[8]) != 'P') return;
        const int slots = static_cast<int>(static_cast<std::uint8_t>(mem[9]));
        std::size_t at = 10;
        for (int k = 0; k < slots && at < mem.size(); ++k) {
            const int n = static_cast<int>(static_cast<std::uint8_t>(mem[at++]));
            for (int s = 0; s < n && at + 1 < mem.size(); ++s, at += 2)
                if (k == slot)
                    dplan.emplace_back(static_cast<int>(static_cast<std::uint8_t>(mem[at])), 2 * static_cast<int>(static_cast<std::uint8_t>(mem[at + 1])));
        }
    } catch (...) {
        dplan.clear();
    }
#ifdef A2_DP_DEBUG
    std::printf("DPLAN slot %d steps %zu first %d@%d\n", slot, dplan.size(), dplan.empty() ? -1 : dplan[0].first,
        dplan.empty() ? -1 : dplan[0].second);
#endif
}

// The plan's current group for this champion (-1 when done, late or past A2_DP_UNTIL). A step ends once its group has
// been captured (respawning) after the step's start, or A2_DP_LATE rounds after it.
int Bot::dplan_group() {
    if (!dplan_loaded) dplan_load();
    if (round > A2_DP_UNTIL) return -1;
    while (dplan_i < dplan.size()) {
        const auto [gi, start] = dplan[dplan_i];
        const bool bad = gi < 0 || gi >= static_cast<int>(w.groups.size());
        if (bad || round > start + A2_DP_LATE ||
            (round > start && w.groups[static_cast<std::size_t>(gi)].state == GroupState::respawning && dplan_seen_alive)) {
            ++dplan_i;
            dplan_seen_alive = false;
            continue;
        }
        if (w.groups[static_cast<std::size_t>(gi)].state != GroupState::respawning) dplan_seen_alive = true;
        return gi;
    }
    return -1;
}
#endif

bool Bot::ward_reveal() {
    if (!tune::kWardReveal) return false;
    bool hit = prev_hp > 0.0f && hp < prev_hp - 1.0f;
    if (hit) {
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= std::max(e.range, 4) + 1) hit = false;
        if (bit(w.hot_zone, pos)) hit = false;
        for (const auto& c : w.camps)
            if (!c.dead && c.strength > 0 && cheb(c.pos, pos) <= c.range) hit = false;
    }
    vec2 lost{-1, -1};
    for (const auto& s : w.sightings) {
        if (round - s.round != 1 || cheb(s.pos, pos) > 4) continue;
        bool still = false;
        for (const auto& e : w.enemies) still |= cheb(e.pos, s.pos) <= 1;
        if (!still) lost = s.pos;
    }
    if (!hit && lost.x < 0 && tune::kWardReveal >= 2) {
        // Pre-emptive: an enemy seen within 8 tiles in the last 3 rounds and none visible now: a bush
        // within ward range could hold it. Aim the ward at the bush nearest that sighting.
        if (w.enemies.empty())
            for (const auto& s : w.sightings)
                if (round - s.round <= 3 && cheb(s.pos, pos) <= 8) lost = s.pos;
    }
    if (!hit && lost.x < 0) return NOVA_WARD_AHEAD > 0 && ward_ahead();
#if A2_TEL
    struct A2Cost {
        std::uint64_t f0 = bc::fuel_remaining();
        std::uint32_t r0 = bc::round_number();
        ~A2Cost() { a2tel::bump(6u * 4096 + static_cast<std::uint32_t>(std::min<std::uint64_t>(a2tel::spent(f0, r0) / 2000, 99))); }
    } a2_cost;
#endif
    const int mine = w.bush_cluster(pos);
    struct Cand {
        vec2 p;
        int d;
    };
    Cand cands[25];
    int n = 0;
    for (int dy = -2; dy <= 2; ++dy)
        for (int dx = -2; dx <= 2; ++dx) {
            const vec2 q{pos.x + dx, pos.y + dy};
            if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q)) continue;
            const int c = w.bush_cluster(q);
            if (c < 0 || c == mine) continue;
            const int d = lost.x >= 0 ? cheb(q, lost) : cheb(q, pos);
            int i = n++;
            for (; i > 0 && cands[i - 1].d > d; --i) cands[i] = cands[i - 1];
            cands[i] = {q, d};
        }
    if (n == 0) return false;
    auto& me = bc::self();
    try {
        if (me.ward_cooldown() > 0) return false;
        for (int i = 0; i < n && i < 3; ++i)
            if (me.place_ward(cands[i].p)) {
                ward_pos = cands[i].p;
                return true;
            }
    } catch (const std::exception& e) {
        LOG("ward reveal error %s\n", e.what());
    }
    return false;
}

bool Bot::hidden_here() {
    const int c = w.bush_cluster(pos);
    if (c < 0 || w.warded(c)) return false;
#if X3_COVER_SAFE
    for (vec2 p : bc::vision::ward_tiles(team::enemy).positions()) {
        const int ward_cluster = w.bush_cluster(p);
        if (ward_cluster < 0 || ward_cluster == c) return false;
    }
#endif
    for (const auto& e : w.enemies)
        if (w.bush_cluster(e.pos) == c) return false;
    return true;
}

// Counter-ambush: we lost health since our last turn, yet no visible enemy reaches us and no awake
// camp does either, so someone hides in a bush within spell reach. Healthy: step into an adjacent
// bush of another cluster (sharing its cluster shows us whoever is inside). Hurt: step to the free
// neighbour farthest from foreign bush tiles. Returns true when we moved.
bool Bot::counter_ambush() {
    if (!tune::kBushDef || prev_hp <= 0.0f || hp >= prev_hp - 1.0f) return false;
    for (const auto& e : w.enemies)
        if (cheb(e.pos, pos) <= std::max(e.range, 4) + 1) return false; // a visible enemy explains it
    if (bit(w.hot_zone, pos)) return false;                               // an awake camp explains it
    for (std::size_t ci = 0; ci < w.camps.size(); ++ci) {
        const auto& c = w.camps[ci];
        if (!c.dead && c.strength > 0 && cheb(c.pos, pos) <= c.range) return false;
    }
    auto& me = bc::self();
    if (!me.can_move()) return false;
#if A2_TEL
    struct A2Cost {
        std::uint64_t f0 = bc::fuel_remaining();
        std::uint32_t r0 = bc::round_number();
        ~A2Cost() { a2tel::bump(5u * 4096 + static_cast<std::uint32_t>(std::min<std::uint64_t>(a2tel::spent(f0, r0) / 2000, 99))); }
    } a2_cost;
#endif
    const int mine = w.bush_cluster(pos);
    auto foreign = [&](vec2 q) {
        const int c = w.bush_cluster(q);
        return c >= 0 && c != mine;
    };
#if A2_FAST_AMBUSH
    // Every tile near_foreign can examine (within 4 of a q within 1 of us) lies within 5 of us: list the foreign
    // bush tiles there once (121 lookups) instead of scanning a 9x9 window for each of up to nine q (729).
    vec2 fl[121];
    int nf = 0;
    for (int dy = -5; dy <= 5; ++dy)
        for (int dx = -5; dx <= 5; ++dx) {
            const vec2 r{pos.x + dx, pos.y + dy};
            if (in_bounds(r, w.width, w.height) && foreign(r)) fl[nf++] = r;
        }
    auto near_foreign = [&](vec2 q) {
        int best = 99;
        for (int i = 0; i < nf; ++i) {
            const int d = cheb(fl[i], q);
            if (d <= 4 && d < best) best = d;
        }
#if A2_CHECK
        { // the original 9x9 scan, compared (kind 17: 0 equal, 1 different)
            int ref = 99;
            for (int dy = -4; dy <= 4; ++dy)
                for (int dx = -4; dx <= 4; ++dx) {
                    const vec2 r{q.x + dx, q.y + dy};
                    if (in_bounds(r, w.width, w.height) && foreign(r)) ref = std::min(ref, std::max(std::abs(dx), std::abs(dy)));
                }
            a2tel::bump(17u * 4096 + (ref != best ? 1u : 0u));
        }
#endif
        return best;
    };
#else
    auto near_foreign = [&](vec2 q) {
        int best = 99;
        for (int dy = -4; dy <= 4; ++dy)
            for (int dx = -4; dx <= 4; ++dx) {
                const vec2 r{q.x + dx, q.y + dy};
                if (in_bounds(r, w.width, w.height) && foreign(r)) best = std::min(best, std::max(std::abs(dx), std::abs(dy)));
            }
        return best;
    };
#endif
    const int here = near_foreign(pos);
    if (here > 4) return false; // no bush could hold the attacker
    if (hp >= max_hp * 0.5f) {
        for (vec2 dir : kDirs) {
            const vec2 q = pos + dir;
            if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q) || !foreign(q)) continue;
            try {
                if (me.move_absolute(q)) {
                    pos = q;
                    walked = true;
                    mode = "counter-ambush";
                    return true;
                }
            } catch (...) {
            }
        }
    }
    vec2 best = pos;
    int best_d = here;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q) || foreign(q)) continue;
        const int d = near_foreign(q);
        if (d > best_d) {
            best_d = d;
            best = q;
        }
    }
    if (best == pos) return false;
    try {
        if (me.move_absolute(best)) {
            pos = best;
            walked = true;
            mode = "evade-ambush";
            return true;
        }
    } catch (...) {
    }
    return false;
}

// Burst-kill search: for each visible enemy, try our options this turn (stay, or one step for
// melee; then basic attack plus either an attack reset or one damage spell, since only one
// ability cast fits in a turn). If the best combination kills, do it, even when about to flee.
bool Bot::try_burst_kill() {
    auto& me = bc::self();
    if (!me.can_attack()) return false;
    const EnemyRec* victim = nullptr;
    vec2 step{-1, -1};
    int spell_slot = -1;
    bool use_reset = false;
    float best_margin = 0.0f;
    for (const auto& e : w.enemies) {
        const int d = cheb(e.pos, pos);
        vec2 to{-1, -1};
        if (d > range) {
            // Only melee champions can step and still attack in the same turn.
            if (!melee || d != 2 || !me.can_move()) continue;
            for (vec2 dir : kDirs) {
                const vec2 q = pos + dir;
                if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
                if (cheb(q, e.pos) <= 1) {
                    to = q;
                    break;
                }
            }
            if (to.x < 0) continue;
        }
        const bool walks = to.x >= 0;
        const int dist_after = walks ? cheb(to, e.pos) : d;
        float best_extra = 0.0f;
        int slot = -1;
        bool reset = false;
        for (int s2 = 0; s2 < 2; ++s2) {
            if (!spell_ready(s2)) continue;
            const auto& sp = spells[s2];
            if (sp.kind == bc::ability_kind::attack_reset) {
                if (strength > best_extra) {
                    best_extra = strength;
                    slot = s2;
                    reset = true;
                }
            } else if ((sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc ||
                           sp.kind == bc::ability_kind::aoe_damage) &&
                sp.enemies && dist_after <= static_cast<int>(sp.range) && !(walks && sp.excludes_walk)) {
                const float dmg = sp.modifier * focus;
                if (dmg > best_extra) {
                    best_extra = dmg;
                    slot = s2;
                    reset = false;
                }
            }
        }
        const float burst = strength + best_extra;
        const float margin = burst - e.hp * 1.05f;
        if (margin < 0.0f) continue;
        // Prefer the kill worth most: carried gems first.
        const float score = margin + static_cast<float>(e.gems) * 20.0f;
        if (!victim || score > best_margin) {
            victim = &e;
            step = to;
            spell_slot = slot;
            use_reset = reset;
            best_margin = score;
        }
    }
    if (!victim) return false;
    if (step.x >= 0) {
        try {
            if (!me.move_absolute(step)) return false;
            pos = step;
            walked = true;
        } catch (...) {
            return false;
        }
    }
    mode = "burst-kill";
    if (spell_slot >= 0 && !use_reset) {
        try {
            const auto ab = me.abilities()[spell_slot];
            const bool ok = spells[spell_slot].kind == bc::ability_kind::aoe_damage ? ab.use(victim->pos) : ab.use(victim->unit);
            if (ok) cast_done = true;
        } catch (const std::exception& ex) {
            LOG("burst cast error %s\n", ex.what());
        }
        attack_unit(victim->unit, victim->pos);
    } else {
        if (attack_unit(victim->unit, victim->pos) && use_reset) use_reset_and_attack(victim->unit, victim->pos);
    }
    return true;
}

// Positioning search for melee fights: among our tile and the free neighbours that still reach
// the target, move to the one the other enemies threaten least next turn (an enemy threatens a
// tile it can reach with one step plus its range), then attack.
// Distance to the nearest enemy that fights in melee (casters kite these).
// Reach of our ready spells that can hit a champion (0 when none is ready or casting is no longer allowed).
int Bot::enemy_spell_reach() const {
    int r = 0;
    for (int s = 0; s < 2; ++s) {
        const auto& sp = spells[s];
        if (!spell_ready(s) || !sp.enemies || (sp.excludes_walk && walked)) continue;
        if (sp.kind != bc::ability_kind::damage && sp.kind != bc::ability_kind::cc && sp.kind != bc::ability_kind::aoe_damage)
            continue;
        r = std::max(r, static_cast<int>(sp.range));
    }
    return r;
}

int Bot::nearest_enemy_melee() const {
    int md = 99;
    for (const auto& e : w.enemies)
        if (e.range <= 1 && !e.tributing() && !e.recalling()) md = std::min(md, cheb(e.pos, pos));
    return md;
}

// APEX_KITE: a ranged champion steps to the neighbour that keeps enemy melee farthest away (capped at
// the kite distance), preferring tiles still in range of the target and closer to spawn. Shooting
// excludes moving for ranged champions, so a caster either holds a safe tile and fires or repositions.
bool Bot::kite_step(const EnemyRec& target) {
    auto& me = bc::self();
    if (!me.can_move()) return false;
    auto score = [&](vec2 q) {
        int md = 99;
        for (const auto& e : w.enemies)
            if (e.range <= 1 && !e.tributing() && !e.recalling()) md = std::min(md, cheb(e.pos, q));
        return 100 * std::min(md, tune::kKite) + (cheb(q, target.pos) <= range ? 20 : 0) -
            static_cast<int>(std::min<int>(fdist(w.spawn_field, q), 60));
    };
    const int here = score(pos);
    vec2 best = pos;
    int best_s = here;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
        const int s = score(q);
        if (s > best_s) best_s = s, best = q;
    }
    if (best == pos) return false;
    try {
        if (me.move_absolute(best)) {
            pos = best;
            walked = true;
            return true;
        }
    } catch (...) {
    }
    return false;
}

bool Bot::position_and_attack(const EnemyRec& target) {
    auto& me = bc::self();
    if (!melee || !me.can_move()) return false;
    auto exposure = [&](vec2 q) {
        float threat = 0.0f;
        for (const auto& e : w.enemies)
            if (e.id != target.id && cheb(q, e.pos) <= e.range + 1) threat += e.strength + e.focus * 0.25f;
        for (int ci : w.awake_camps_near(q)) threat += w.camps[ci].strength;
        if (SPACING) {
            bool area = false;
            for (const auto& e : w.enemies)
                area |= e.type == bc::champion_type::varg || e.type == bc::champion_type::heart_of_ruin || e.type == bc::champion_type::ryth ||
                    e.type == bc::champion_type::stellar || e.type == bc::champion_type::prism;
            if (area)
                for (const auto& a : w.allies) threat += cheb(a.pos, q) <= 1 ? SPACING_W : 0.0f;
        }
        return threat;
    };
    vec2 best = pos;
    float best_threat = cheb(pos, target.pos) <= range ? exposure(pos) : 1e9f;
    for (vec2 dir : kDirs) {
        const vec2 q = pos + dir;
        if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
        if (cheb(q, target.pos) > range) continue;
        const float t = exposure(q);
        if (t + 1.0f < best_threat) { // move only for a real improvement
            best_threat = t;
            best = q;
        }
    }
    if (best != pos) {
        try {
            if (me.move_absolute(best)) {
                pos = best;
                walked = true;
            }
        } catch (...) {
        }
    }
    return cheb(pos, target.pos) <= range;
}

// Dash to the tile within reach that is farthest from every visible enemy (ties toward spawn).
bool Bot::dash_away() {
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s) || spells[s].kind != bc::ability_kind::dash) continue;
        struct Cand {
            vec2 p;
            int score;
        };
        Cand cands[24];
        int n = 0;
        auto safety = [&](vec2 q) {
            int d = 99;
            for (const auto& e : w.enemies) d = std::min(d, cheb(e.pos, q) - e.range);
            int sc = d * 100 - static_cast<int>(fdist(w.spawn_field, q));
            if (tune::kBushHide && hidden_from_threats(q)) sc += tune::kBushHide;
            return sc;
        };
        const int here = safety(pos);
        const int reach = std::max(1, static_cast<int>(spells[s].range));
        for (int dx = -reach; dx <= reach; ++dx)
            for (int dy = -reach; dy <= reach; ++dy) {
                const vec2 q{pos.x + dx, pos.y + dy};
                if ((dx == 0 && dy == 0) || !in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) ||
                    bit(w.unit_tiles, q) || n >= 24)
                    continue;
                const int sc = safety(q);
                if (sc <= here) continue;
                int i = n++;
                for (; i > 0 && cands[i - 1].score < sc; --i) cands[i] = cands[i - 1];
                cands[i] = {q, sc};
            }
        for (int i = 0; i < n && i < 4; ++i) {
            try {
                if (bc::self().abilities()[s].use(cands[i].p)) {
                    pos = cands[i].p;
                    cast_done = true;
                    return true;
                }
            } catch (const std::exception& e) {
                LOG("dash-away error %s\n", e.what());
            }
        }
        return false;
    }
    return false;
}

namespace {
// Champions whose slot 1 is a dash.
bool has_dash(bc::champion_type t) {
    return t == bc::champion_type::vendetta || t == bc::champion_type::ren || t == bc::champion_type::vesper_vale ||
        t == bc::champion_type::issac;
}
} // namespace

// Escape search (APEX_ESCAPE_SEARCH): plan the next tune::kEscDepth turns of a flight. Each nearby
// enemy chases one tile per turn along its own shortest path (two more, once its dash is ready), so
// after its k-th turn it may stand anywhere within k of where it is now: a melee enemy then hits a
// tile at walking distance at most k + 1 from it, a ranged one at most k - 1 + its range (a tributing
// or recalling enemy stays put). Each turn we may step to any free neighbour or stay; on the first,
// also dash and then step. A plan costs the damage it takes, a death penalty when that damage kills
// us, the exposure left at its end (enemies that still reach us next turn) and the walk home.
// Fuel (measured, probe12 and APEX_ESC_LOG): a capped field per chaser (~2.5k on 50x50, ~5k on
// 100x100) plus ~450 per tile in reach for the facts and ~130 per tile and turn for the search. With a
// dash ready the plan looks one turn less, so it never covers more than 81 tiles (~45k in all).
bool Bot::plan_escape() {
    PROF(escape);
    esc_plan = {};
    // Keep enough back that the turn never suspends (a suspended turn hands the chaser free hits).
    if (bc::fuel_remaining() < tune::kEscFuel || !bc::self().can_move()) {
#ifdef APEX_ESCDBG
        if (bc::fuel_remaining() < tune::kEscFuel) std::printf("ESCSKIP R%d fuel %llu\n", round, static_cast<unsigned long long>(bc::fuel_remaining()));
#endif
        return false;
    }
#ifdef APEX_ESCDBG
    std::printf("ESCRUN R%d fuel %llu\n", round, static_cast<unsigned long long>(bc::fuel_remaining()));
#endif
#ifdef APEX_ESC_LOG
    std::uint64_t fm[8] = {bc::fuel_remaining()};
#define ESC_AT(i) fm[i] = bc::fuel_remaining()
#else
#define ESC_AT(i) ((void)0)
#endif
    int dash_slot = -1;
    for (int s = 0; s < 2; ++s)
        if (spell_ready(s) && spells[s].kind == bc::ability_kind::dash) dash_slot = s;
    const int reach = dash_slot >= 0 ? 2 : 0; // extra radius a dash adds
    const int depth = std::clamp(tune::kEscDepth - (dash_slot >= 0 ? 1 : 0), 1, 4);
    const int R = depth + reach;
    // Window around us: radius up to 6 (4 turns + a dash), plus a border of one for neighbour reads.
    constexpr int kMaxR = 7, kW = 2 * kMaxR + 1, kCells = kW * kW;
    constexpr std::int32_t kNone = 0x3fffffff;

    struct Chaser {
        const EnemyRec* e;
        int dist, base, grow, dash_from, dps;
    };
    Chaser ch[3];
    int nch = 0;
    for (const auto& e : w.enemies) {
        const int d0 = cheb(e.pos, pos);
        if (d0 > depth + 2 + std::max(e.range, 1) + 4) continue; // cannot reach anything the plan can
        const Chaser c{&e, d0, 0, 1, 99, static_cast<int>(enemy_dps(e))};
        int i = nch < 3 ? nch++ : 3;
        if (i == 3 && d0 >= ch[2].dist) continue;
        if (i == 3) i = 2;
        for (; i > 0 && ch[i - 1].dist > d0; --i) ch[i] = ch[i - 1];
        ch[i] = c;
    }
    if (nch == 0) return false;
    ESC_AT(1);

    if (!esc_boards) {
        esc_boards = std::make_unique<EscapeBoards>();
        const bc::bitboard walls = bc::map::walls();
        const bc::bitboard altars = bc::map::altars();
        esc_boards->chase_blocked = walls | bc::map::holes() | altars | w.ally_spawn;
        esc_boards->dash_stop = walls | altars | w.enemy_spawn;
        esc_boards->root.clear();
    }
    auto& B = *esc_boards;
    ESC_AT(2);

    // Hit thresholds per chaser and turn (1..depth + 1; the last is "next turn" after the plan).
    int thr[3][6];
    for (int i = 0; i < nch; ++i) {
        auto& c = ch[i];
        const EnemyRec& e = *c.e;
        const bool still = e.tributing() || e.recalling();
        c.grow = still ? 0 : 1;
        c.base = e.range <= 1 ? 1 : (still ? e.range : e.range - 1);
        if (!still && has_dash(e.type)) {
            std::int32_t cd = 0;
            if (d::sdk_champion_cooldown(e.id, 1, &cd) != 0) cd = 0; // unknown: assume ready
            c.dash_from = std::max(1, static_cast<int>(cd) + 1);
        }
        for (int k = 1; k <= depth + 1; ++k) thr[i][k] = c.base + c.grow * k + (k >= c.dash_from ? 2 : 0);
        set_bit(B.root, e.pos);
        B.field[static_cast<std::size_t>(i)].compute(B.chase_blocked, B.root, B.visited,
            static_cast<std::uint16_t>(thr[i][depth + 1] + 6));
        clear_bit(B.root, e.pos);
    }
    ESC_AT(3);

    // One pass over the tiles in reach: walkability, the damage taken there at the end of each turn,
    // and the cost of ending the plan there (exposure next turn plus the walk home; 0 on our spawn,
    // which heals and which enemies cannot enter). Engine buffers are read directly.
    static constexpr int kExposure[6] = {20, 9, 5, 3, 1, 0}; // tenths of a chaser's hit, by margin 0..5
    const auto& L = bc::detail::layout();
    const std::uint16_t* hit_ptr[3] = {B.field[0].ptr(), B.field[1].ptr(), B.field[2].ptr()};
    const std::uint16_t* spawn_ptr = w.spawn_field.ptr();
    const std::uint64_t* blocked_ptr = w.static_blocked.ptr();
    const std::uint64_t* units_ptr = w.unit_tiles.ptr();
    const std::uint64_t* hot_ptr = w.hot_zone.ptr();
    std::uint8_t ok[kCells]; // 0 = blocked, 1 = walkable, 2 = walkable and free this turn
    std::int16_t dmg[4][kCells];
    std::int16_t leaf[kCells];
    std::int32_t a[kCells], b[kCells]; // plan keys of the previous and the current turn (see below)
    auto at = [](int dx, int dy) { return (dy + kMaxR) * kW + dx + kMaxR; };
    for (int dy = -R - 1; dy <= R + 1; ++dy)
        for (int dx = -R - 1; dx <= R + 1; ++dx) {
            const int c = at(dx, dy);
            a[c] = b[c] = kNone;
            ok[c] = 0;
        }
    for (int dy = -R; dy <= R; ++dy) {
        const int y = pos.y + dy;
        if (y < 0 || y >= w.height) continue;
        const std::uint32_t chunk_row = static_cast<std::uint32_t>(y) >> 3, in_row = static_cast<std::uint32_t>(y & 7) << 3;
        for (int dx = -R; dx <= R; ++dx) {
            const int x = pos.x + dx;
            if (x < 0 || x >= w.width) continue;
            const std::uint32_t word = chunk_row * L.chunk_stride + (static_cast<std::uint32_t>(x) >> 3);
            const std::uint32_t shift = in_row | static_cast<std::uint32_t>(x & 7);
            if ((blocked_ptr[word] >> shift) & 1u) continue;
            const int c = at(dx, dy);
            const bool free_now = (dx == 0 && dy == 0) || (!((units_ptr[word] >> shift) & 1u) && vec2{x, y} != esc_failed);
            ok[c] = free_now ? 2 : 1;
            const std::size_t fi = (chunk_row * L.chunked_width + (static_cast<std::uint32_t>(x) >> 3)) * 64 + shift;
            const int home = std::min<int>(spawn_ptr[fi], 60);
            if (home == 0) {
                for (int k = 0; k < depth; ++k) dmg[k][c] = 0;
                leaf[c] = 0;
                continue;
            }
            int per_turn[5] = {(hot_ptr[word] >> shift) & 1u ? 40 : 0, 0, 0, 0, 0}; // added from turn k on
            int expo = 0;
            for (int i = 0; i < nch; ++i) {
                const int h = std::min<int>(hit_ptr[i][fi], 250);
                int k = 1;
                while (k <= depth && h > thr[i][k]) ++k;
                if (k <= depth) per_turn[k - 1] += ch[i].dps;
                expo += ch[i].dps * kExposure[std::clamp(h - thr[i][depth + 1], 0, 5)];
            }
            int run = 0;
            for (int k = 0; k < depth; ++k) dmg[k][c] = static_cast<std::int16_t>(run += per_turn[k]);
            leaf[c] = static_cast<std::int16_t>(expo / 10 + tune::kEscHome * home);
        }
    }

    ESC_AT(4);
    // Plans as packed keys: (cost << 8) | first tile, so a min over keys keeps the cheapest plan and
    // remembers where it starts. Turn 1: a step or staying; or a dash, then a step (costs dash_cost).
    std::uint8_t land_of[kCells]; // per first tile: the dash landing, or 255 for a plain step
    for (int dy = -1; dy <= 1; ++dy)
        for (int dx = -1; dx <= 1; ++dx) {
            const int c = at(dx, dy);
            if (ok[c] != 2) continue;
            a[c] = (static_cast<std::int32_t>(dmg[0][c]) << 8) | c;
            land_of[c] = 255;
        }
    const int dash_cost = static_cast<int>(tune::kEscDashCost * max_hp);
    if (dash_slot >= 0) {
        const int dr = std::clamp(static_cast<int>(spells[dash_slot].range), 1, 2);
        for (int ly = -dr; ly <= dr; ++ly)
            for (int lx = -dr; lx <= dr; ++lx) {
                const int l = at(lx, ly);
                if ((lx == 0 && ly == 0) || ok[l] != 2) continue;
                if (bit(B.dash_stop, vec2{pos.x + lx, pos.y + ly})) continue;
                if (std::max(std::abs(lx), std::abs(ly)) == 2) {
                    // A two-tile dash needs a middle tile next to both ends that it can cross.
                    bool path = false;
                    for (int my = -1; my <= 1 && !path; ++my)
                        for (int mx = -1; mx <= 1 && !path; ++mx) {
                            if ((mx == 0 && my == 0) || std::abs(lx - mx) > 1 || std::abs(ly - my) > 1) continue;
                            const vec2 m{pos.x + mx, pos.y + my};
                            path = in_bounds(m, w.width, w.height) && !bit(B.dash_stop, m) && !bit(w.unit_tiles, m);
                        }
                    if (!path) continue;
                }
                for (int sy = -1; sy <= 1; ++sy)
                    for (int sx = -1; sx <= 1; ++sx) {
                        const int c = l + sy * kW + sx;
                        if (ok[c] != 2) continue;
                        const std::int32_t key = (static_cast<std::int32_t>(dmg[0][c] + dash_cost) << 8) | c;
                        if (key < a[c]) {
                            a[c] = key;
                            land_of[c] = static_cast<std::uint8_t>(l);
                        }
                    }
            }
    }
    ESC_AT(5);
    // Turns 2..depth: each tile takes the cheapest plan among its neighbours and itself (other units
    // are ignored after the first turn: they move too). Tiles a plan cannot reach stay at kNone.
    std::int32_t* prev = a;
    std::int32_t* cur = b;
    for (int k = 2; k <= depth; ++k) {
        const int rk = std::min(R, k + reach);
        for (int dy = -rk; dy <= rk; ++dy)
            for (int dx = -rk; dx <= rk; ++dx) {
                const int c = at(dx, dy);
                if (!ok[c]) continue;
                const std::int32_t* p = prev + c;
                const std::int32_t m = std::min(std::min(std::min(p[-kW - 1], p[-kW]), std::min(p[-kW + 1], p[-1])),
                    std::min(std::min(p[0], p[1]), std::min(std::min(p[kW - 1], p[kW]), p[kW + 1])));
                cur[c] = m >= kNone ? kNone : m + (static_cast<std::int32_t>(dmg[k - 1][c]) << 8);
            }
        std::swap(prev, cur);
    }

    ESC_AT(6);
    // The cheapest end: damage taken, a death penalty, and the end-tile cost.
    const int death = static_cast<int>(3.0f * max_hp) + 15 * gems;
    int best = 0x7fffffff, best_first = -1;
    const int rf = std::min(R, depth + reach);
    for (int dy = -rf; dy <= rf; ++dy)
        for (int dx = -rf; dx <= rf; ++dx) {
            const int c = at(dx, dy);
            const std::int32_t key = prev[c];
            if (key >= kNone || !ok[c]) continue;
            const int cost = key >> 8, f = key & 255;
            const int taken = cost - (land_of[f] != 255 ? dash_cost : 0);
            const int v = cost + leaf[c] + (static_cast<float>(taken) >= hp ? death : 0);
            if (v < best) {
                best = v;
                best_first = f;
            }
        }
    ESC_AT(7);
    if (best_first < 0) return false;
    auto cell_pos = [&](int c) { return vec2{pos.x + c % kW - kMaxR, pos.y + c / kW - kMaxR}; };
    esc_plan.valid = true;
    esc_plan.step = cell_pos(best_first);
    if (land_of[best_first] != 255) {
        esc_plan.dash_slot = dash_slot;
        esc_plan.land = cell_pos(land_of[best_first]);
    }
#ifdef APEX_ESC_LOG
    std::printf("ESCF R%d sel%llu boards%llu fields%llu facts%llu turn1%llu dp%llu score%llu R%d\n", round,
        static_cast<unsigned long long>(fm[0] - fm[1]), static_cast<unsigned long long>(fm[1] - fm[2]),
        static_cast<unsigned long long>(fm[2] - fm[3]), static_cast<unsigned long long>(fm[3] - fm[4]),
        static_cast<unsigned long long>(fm[4] - fm[5]), static_cast<unsigned long long>(fm[5] - fm[6]),
        static_cast<unsigned long long>(fm[6] - fm[7]), R);
    std::printf("ESC R%d %s p(%d,%d) hp%.0f chasers%d best%d dash%d land(%d,%d) step(%d,%d)\n", round, bc::to_string(type).c_str(),
        pos.x, pos.y, hp, nch, best, esc_plan.dash_slot, esc_plan.land.x, esc_plan.land.y, esc_plan.step.x, esc_plan.step.y);
#endif
    return true;
}

int Bot::run_escape(bool dash_only) {
    if (esc_round != round) {
        esc_round = round;
        esc_failed = {-1, -1};
        plan_escape();
    }
    auto& me = bc::self();
    for (int attempt = 0; attempt < 2; ++attempt) {
        if (!esc_plan.valid || (dash_only && esc_plan.dash_slot < 0)) return 0;
        if (esc_plan.dash_slot >= 0) {
            bool dashed = false;
            try {
                dashed = me.abilities()[esc_plan.dash_slot].use(esc_plan.land);
            } catch (const std::exception& e) {
                LOG("escape dash error %s\n", e.what());
            }
            if (dashed) {
                pos = esc_plan.land;
                cast_done = true;
                esc_plan.dash_slot = -1; // done; a replan from here plans steps only
                if (esc_plan.step != pos && me.can_move()) {
                    try {
                        if (me.move_absolute(esc_plan.step)) {
                            pos = esc_plan.step;
                            walked = true;
                        }
                    } catch (...) {
                    }
                }
                return 1;
            }
            esc_failed = esc_plan.land;
        } else {
            if (esc_plan.step == pos) return 2;
            if (!me.can_move()) return 0;
            try {
                if (me.move_absolute(esc_plan.step)) {
                    pos = esc_plan.step;
                    walked = true;
                    return 1;
                }
            } catch (...) {
            }
            esc_failed = esc_plan.step;
        }
        // The engine refused a tile (an unseen unit): plan once more around it.
        if (attempt == 0 && !plan_escape()) return 0;
    }
    return 0;
}

// We are losing the fight. Escape if something can open a gap (a dash, a stun on a lone chaser
// that still lets us walk, or a spawn we reach before dying); otherwise fight back, since moving
// away from an enemy that keeps pace only gives it free hits.
// Engine buff data: is this enemy stunned right now (NOVA_STUN_FOCUS)?
static bool enemy_stunned(const EnemyRec& e) {
    d::buff_data buffs[6];
    std::uint32_t nb = 0;
    if (d::sdk_champion_buff_data(e.id, buffs, 6, &nb) != 0) return false;
    for (std::uint32_t i = 0; i < nb && i < 6; ++i)
        if (buffs[i].type == 1 && buffs[i].data.stun.duration > 0) return true;
    return false;
}

bool Bot::escape_or_stand(const EnemyRec* target, const EnemyRec* nearest, float ttd) {
#if A2_TEL
    a2tel::CallCost a2_cost{8};
#endif
    auto& me = bc::self();
    int catching = 0; // enemies that can hit us next turn even if we step away
    const EnemyRec* chaser = nullptr;
    for (const auto& e : w.enemies)
        if (cheb(e.pos, pos) <= e.range) {
            ++catching;
            if (!chaser || cheb(e.pos, pos) < cheb(chaser->pos, pos)) chaser = &e;
        }
    if (catching == 0) return false; // stepping away keeps us out of reach: the usual flee
    const int spawn_steps = fdist(w.spawn_field, pos);
    // 1. Dash out of reach, then keep stepping away (dashes are walking-compatible). The escape
    //    search dashes only when its plan does (the dash and the step are both in the plan).
    if (tune::kEscapeSearch) {
        if (run_escape(true) == 1) {
            mode = "flee-dash";
            heading_home = hp < max_hp * 0.5f;
            return true;
        }
    } else if ((tune::kStand & 1) && dash_away()) {
        mode = "flee-dash";
        heading_home = hp < max_hp * 0.5f;
        retreat_from(nearest->pos);
        return true;
    }
    // 2. Stun the only enemy on us and step away.
    if ((tune::kStand & 2) && catching == 1 && chaser) {
        for (int s = 0; s < 2; ++s) {
            const auto& sp = spells[s];
            if (!spell_ready(s) || sp.kind != bc::ability_kind::cc || !sp.enemies || sp.excludes_walk) continue;
            if (cheb(pos, chaser->pos) > static_cast<int>(sp.range)) continue;
            try {
                if (me.abilities()[s].use(chaser->unit)) {
                    cast_done = true;
                    mode = "flee-stun";
                    heading_home = hp < max_hp * 0.5f;
                    retreat_from(chaser->pos);
                    return true;
                }
            } catch (const std::exception& e) {
                LOG("stun error %s\n", e.what());
            }
        }
    }
    // 3. Home is close enough to reach alive (enemies cannot enter our spawn), or standing is off:
    //    the usual flee.
    if (!(tune::kStand & 4) || spawn_steps <= 2 || static_cast<float>(spawn_steps) < ttd * 0.8f) return false;
    // 4. No way out: make the chaser pay. Hit whatever is in reach, lowest health first.
    mode = "stand";
    const EnemyRec* victim = nullptr;
    for (const auto& e : w.enemies)
        if (cheb(e.pos, pos) <= range && (!victim || e.hp < victim->hp)) victim = &e;
    if (!victim) victim = target ? target : nearest;
    cast_on_enemy(*victim);
    if (cheb(victim->pos, pos) <= range) {
        if (attack_unit(victim->unit, victim->pos)) use_reset_and_attack(victim->unit, victim->pos);
    } else {
        bc::bitboard goal;
        goal.clear();
        goal.draw_chebyshev(victim->pos, static_cast<float>(range));
        walk_toward(goal);
        if (cheb(victim->pos, pos) <= range) attack_unit(victim->unit, victim->pos);
    }
    return true;
}

// Losing, with a melee enemy adjacent (APEX_STAND2): walking away cannot shake it, so either reach
// our spawn while hitting it, or stand and spend everything on the best target in reach.
bool Bot::melee_caught() {
    const EnemyRec* chaser = nullptr;
    float chase_dps = 0.0f; // damage we keep taking per turn while walking away
    for (const auto& e : w.enemies) {
        const int d = cheb(e.pos, pos);
        if (e.range <= 1 && d <= 1) {
            chase_dps += enemy_dps(e);
            if (!chaser || e.hp < chaser->hp) chaser = &e;
        } else if (e.range > 1 && d <= e.range) {
            chase_dps += enemy_dps(e) * 0.5f; // ranged: shoots while we are in reach, then must walk
        }
    }
    if (!chaser) return false;
    for (int s = 0; s < 2; ++s)
        if (spell_ready(s) && spells[s].kind == bc::ability_kind::dash) return false; // a dash breaks contact
    auto& me = bc::self();
    const int spawn_steps = fdist(w.spawn_field, pos);
    const bool reach_home = spawn_steps != kUnreach && static_cast<float>(spawn_steps) * chase_dps < hp * 0.9f;
    if (reach_home && (tune::kStand2 & 1)) {
        mode = "flee-home";
        if (melee) attack_unit(chaser->unit, chaser->pos); // melee can hit and still walk
        bc::bitboard blocked = w.static_blocked | w.unit_tiles;
        blocked.set(pos, false);
        if (!me.can_move() || !follow_field(w.spawn_field, blocked, false)) retreat_from(chaser->pos);
        heading_home = true;
        return true;
    }
    if (reach_home || !(tune::kStand2 & 2)) return false;
    mode = "stand2";
    // Finish whatever we can kill this turn; otherwise the weakest enemy in reach.
    const float burst = strength * 2.0f + focus * 2.0f;
    const EnemyRec* victim = nullptr;
    for (const auto& e : w.enemies) {
        if (cheb(e.pos, pos) > range) continue;
        const bool kill = e.hp <= burst;
        const bool vkill = victim && victim->hp <= burst;
        if (!victim || (kill && !vkill) || (kill == vkill && e.hp < victim->hp)) victim = &e;
    }
    if (!victim) victim = chaser;
    cast_on_enemy(*victim);
    if (attack_unit(victim->unit, victim->pos)) use_reset_and_attack(victim->unit, victim->pos);
    return true;
}

bool Bot::handle_enemies() {
#if A2_BURST_HOLD
    a2_hold_burst = false;
#endif
    if (w.enemies.empty()) return false;
#if V58_CAMP_CONTACT
    if (camp_contact()) return true;
#endif
#if V58_CAPTURE_STAND
    if (capture_stand()) return true;
#endif
#if V58_DENY_CAP
    if (deny_capture()) return true;
#endif
    FlagScope combat{combat_move};
    PROF(enemies);
    PROF_CHECK("e_in");
    if (!(tune::kTribDeny & 2)) try_lock_altar(); // (& 2: deny_tribute picks the moment instead)
    PROF_CHECK("e_altar");
    if (tune::kBurst && try_burst_kill()) return true;
    PROF_CHECK("e_lock");
    if (bush_ambush()) return true;
    PROF_CHECK("e_bush");

    // Damage the enemy can put on us next turns, and how long we last under it.
    float threat_on_me = 0;
    const EnemyRec* nearest = nullptr;
    int nearest_d = 1000;
    for (const auto& e : w.enemies) {
        const int dist = cheb(e.pos, pos);
        // An enemy parked on its own spawn (shopping, healing, idling) only matters when it can reach us
        // next turn; otherwise fleeing from it freezes us (rushbait-v2: adjacent spawns, 0 gems vs an idle team).
        if (NOVA_SPAWN_IGNORE && bit(w.enemy_spawn, e.pos) && dist > e.range + NOVA_SPAWN_IGNORE) continue;
        if (dist < nearest_d) {
            nearest_d = dist;
            nearest = &e;
        }
        if ((tune::kTribDeny & 1) && e.tributing()) continue; // it cannot act until its channel ends
        if (dist <= std::max(e.range + 2, 5)) threat_on_me += enemy_dps(e);
    }
    if (!nearest || nearest_d > 8) return false;
    const float ttd = threat_on_me > 0 ? hp / threat_on_me : 1e9f;
    // Gem carriers demand a bigger margin: dying hands the bag to the killer.
    const float risk = gems >= 60 ? 2.0f : gems >= 25 ? 1.4f : 1.0f;
    const float ci_risk = (type == bc::champion_type::cassi || type == bc::champion_type::issac) ? tune::kCiRisk : 1.0f;

    // Pick the enemy we kill fastest relative to what it is worth.
    const EnemyRec* target = nullptr;
    float target_ttk = 1e9f, best_key = 1e30f;
    const float mine = my_dps(nullptr);
    for (const auto& e : w.enemies) {
        const int dist = cheb(e.pos, pos);
        if (dist > range + 4) continue;
        if (tune::kHuntFix && bit(w.enemy_spawn, e.pos)) continue; // heals fully there; chasing is futile
        float dmg = dist <= range + 2 ? mine : mine * 0.5f;
        for (const auto& a : w.allies)
            if (cheb(a.pos, e.pos) <= a.range + 2) dmg += ally_dps(a);
        float ttk = e.hp / std::max(dmg, 1.0f);
        float worth = 1.0f + static_cast<float>(e.gems) / 30.0f;
        if (tgtNew && (!blendRace || (brain::state.ready && brain::state.race))) {
            // Distance discount: an enemy past standard reach pays one extra walk step per gap
            // (beyond the half-dps assumption the base formula already makes for range+3..4).
            if (dist > range + 2) ttk += static_cast<float>(dist - range - 2) * 1.0f;
            // Fire-focus: a target with big sustained dps is worth killing first Ã¢â‚¬â€ we deny
            // the damage it keeps dealing while the tank soaks.
            worth += tgtThreat * enemy_dps(e);
            // Finishing: wounded champions die cheap in practice (allies converge on low hp).
            if (e.hp < e.max_hp * tgtWoundedHp) worth += tgtWounded;
        }
        // NOVA_FIGHT2 bit 2, focus fire: every champion values the same wounded target more, so allies
        // converge on it (top bots score 2.06 champions per kill, we 1.64).
        if (NOVA_FIGHT2 & 2) worth *= 1.0f + NOVA_F2_FOCUS * (1.0f - e.hp / std::max(1.0f, e.max_hp));
        if (NOVA_STUN_FOCUS > 0.0f && enemy_stunned(e)) worth *= 1.0f + NOVA_STUN_FOCUS; // follow up a stun
#if defined(A3_FOCUS)
        if (A3_FOCUS > 0.0f) {
            // A3 focus fire: all allies rank the same way (wounded first, then the target most of us can reach), so
            // they converge on one champion instead of spreading damage (top teams 0.32 focus vs our 0.25).
            int reach = 0;
            for (const auto& a : w.allies) reach += cheb(a.pos, e.pos) <= a.range + 2;
            worth *= (1.0f + A3_FOCUS * (1.0f - e.hp / std::max(1.0f, e.max_hp))) * (1.0f + 0.5f * A3_FOCUS * static_cast<float>(reach));
        }
#endif
#if X1_SECURE
        // X1_SECURE (MAPF coordinator, Hagelback & Johansson 2009: assign attacks so targets die, no overkill or
        // underkill): a target the allies in reach can finish this round is worth its 100 kill gold and its bag
        // now; every body ranks the same way, so the team converges on the kill.
        if (ttk <= 1.0f) worth *= X1_SECURE_MULT;
#endif
        if (e.tributing()) worth += 2.0f; // its whole bag is on the table and it cannot run
        if (e.recalling()) worth += 0.5f;
        if (tune::kCiFocus && (e.type == bc::champion_type::cassi || e.type == bc::champion_type::issac)) {
            // Cassi and Issac die together: one kill removes two bodies and pays both bags.
            int partner_gems = 15; // unseen partner: assume a typical bag
            for (const auto& o : w.enemies)
                if (o.id != e.id && (o.type == bc::champion_type::cassi || o.type == bc::champion_type::issac)) partner_gems = o.gems;
            worth += 1.0f + static_cast<float>(partner_gems) / 30.0f;
        }
#if A2_LAB
        {
            // Lab knobs 16-21 (black-box search, knob_es.js): targeting weights - carried gems, the target's damage
            // output, wounds, stuns, the extra walk to reach it, and the Cassi & Issac double kill.
            const float* kk = lab::knobs;
            worth += static_cast<float>(e.gems) / 30.0f * (std::exp(0.5f * kk[16]) - 1.0f);
            worth *= std::exp(0.3f * kk[17] * enemy_dps(e) / 100.0f);
            worth *= 1.0f + 0.5f * kk[18] * (1.0f - e.hp / std::max(1.0f, e.max_hp));
            if (enemy_stunned(e)) worth *= std::exp(0.4f * kk[19]);
            ttk += 0.5f * kk[20] * static_cast<float>(std::max(0, dist - range));
            if (e.type == bc::champion_type::cassi || e.type == bc::champion_type::issac) worth *= std::exp(0.3f * kk[21]);
            worth = std::max(worth, 0.05f);
        }
#endif
        const float key = ttk / worth;
        if (key < best_key) {
            best_key = key;
            target = &e;
            target_ttk = ttk;
        }
    }

    float aggression = tune::kAggression * ep_aggr;
    if (NOVA_RUSH_UNTIL > 0 && round < NOVA_RUSH_UNTIL && rush_active()) aggression *= NOVA_RUSH_AGGR;
    // Phase (APEX_PHASE_AGGR): the position evaluator values a kill at ~8 gems early and ~25 late, and
    // champion contact at -13 early and -2 late; so fights are worth less early and more late. Aggression
    // runs from APEX_PHASE_EARLY at round 0 to APEX_PHASE_LATE at round APEX_PHASE_ROUND.
    if (tune::kPhaseAggr) {
        const float t = std::min(1.0f, static_cast<float>(round) / static_cast<float>(tune::kPhaseRound));
        aggression *= tune::kPhaseEarly + (tune::kPhaseLate - tune::kPhaseEarly) * t;
    }
    if (tune::kNoDashAggr > 0.0f && spells[0].kind != bc::ability_kind::dash && spells[1].kind != bc::ability_kind::dash)
        aggression = tune::kNoDashAggr;
    if (tune::kLowHpAggr > 0.0f) aggression = 1.0f + (aggression - 1.0f) * std::min(1.0f, hp / (max_hp * tune::kLowHpAggr));
    const float self_ttd = melee ? 1.0f : tune::kCasterSelfTtd;
    bool winning = target && target_ttk * risk * ci_risk < std::min(ttd, 8.0f) * aggression;
    bool in_danger = threat_on_me > 0 && (ttd < tune::kDangerTtd * risk * ci_risk * self_ttd * ep_danger || hp < max_hp * tune::kDangerHp);
    const int outnumbered_k = round < NOVA_EARLY_SAFE_UNTIL ? NOVA_EARLY_SAFE_K : tune::kOutnumbered;
    if (outnumbered_k > 0) {
        // Most ladder deaths were a lone champion caught by two or more enemies: leave before they
        // close in, at any health, unless the fight is already a sure kill.
        int foes = 0, friends = 1;
        for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 8;
#if A2_BELIEF
        foes += a2_hidden_near(8, 0);
#endif
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 5 && a.hp >= a.max_hp * 0.4f;
        const bool sure_kill = target && target_ttk <= 1.0f;
        if (foes >= friends + outnumbered_k && !sure_kill) {
            in_danger = true;
            winning = false;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
    if (NOVA_BURST_K > 0.0f) {
        // Burst-aware danger: what the visible enemies can land on us next turn (ready nukes within spell
        // reach, basic attacks within walking reach). Caster teams kill from 15-20% health in one turn.
        float burst = 0.0f;
        for (const auto& e : w.enemies) {
            const int dist = cheb(e.pos, pos);
            if (dist > 5) continue;
            if (dist <= e.range + 1) burst += e.strength;
            if (dist <= 5) {
                const auto kit = spell_kit(e.type, e.focus);
                bool ready = false;
                for (std::uint32_t s2 = 0; s2 < 2; ++s2) {
                    std::int32_t cd = 1;
                    if (d::sdk_champion_cooldown(e.id, s2, &cd) == 0 && cd <= 1) ready = true;
                }
                if (ready) burst += kit.nuke;
            }
        }
#if A2_BELIEF
        burst += a2_hidden_burst();
#endif
        const bool sure_kill = target && target_ttk <= 1.0f;
        float my_hp = hp;
        if (type == bc::champion_type::cassi || type == bc::champion_type::issac)
            for (const auto& a : w.allies)
                if (a.type == (type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi))
                    my_hp = std::min(my_hp, a.hp); // one fate: the weaker body is our health
        if (burst > 0.0f && my_hp < NOVA_BURST_K * burst && !sure_kill) {
            in_danger = true;
            winning = false;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
#if A2_BURST2
    {
        // Two-turn burst with stun chains. On the ladder we die 2.3x as often as our opponents and 52% of those deaths
        // start above 80% health six turns earlier: a stun holds us while the team piles on. Count two turns of hits
        // from every enemy that can reach us in that time, ready spells (cooldown <= 2), and a third round of hits when a
        // stun is ready within reach. Leave unless we have the local numbers or this turn is a sure kill.
        float burst2 = 0.0f, round_dmg = 0.0f;
        bool stun_ready = false;
        int foes = 0;
        for (const auto& e : w.enemies) {
            if (e.hp <= 0) continue;
            const int dist = cheb(e.pos, pos);
            if (dist > e.range + 3) continue;
            ++foes;
            const auto kit = spell_kit(e.type, e.focus);
            bool ready = false;
            for (std::uint32_t s2 = 0; s2 < 2; ++s2) {
                std::int32_t cd = 3;
                if (d::sdk_champion_cooldown(e.id, s2, &cd) == 0 && cd <= 2) ready = true;
            }
            round_dmg += e.strength;
            burst2 += 2.0f * e.strength + (ready ? kit.nuke : 0.0f);
            if (ready && kit.stun && dist <= 5) stun_ready = true;
        }
        if (stun_ready) burst2 += round_dmg;
        int friends = 1;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 3 && a.hp >= a.max_hp * 0.5f;
        float my_hp2 = hp;
        if (type == bc::champion_type::cassi || type == bc::champion_type::issac)
            for (const auto& a : w.allies)
                if (a.type == (type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi))
                    my_hp2 = std::min(my_hp2, a.hp);
        const bool sure_kill2 = target && target_ttk <= 1.0f;
        if (foes > 0 && my_hp2 < A2_BURST2_K * burst2 && friends <= foes && !sure_kill2) {
            in_danger = true;
            winning = false;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
#endif
    if (tune::kCiOutnumbered >= 0 && (type == bc::champion_type::cassi || type == bc::champion_type::issac)) {
        // C&I outnumbered (APEX_CI_OUTNUMBERED = k): one pick, two lives on one fate. Cassi died from full health to
        // three enemies' burst in two turns, so the pair leaves when enemies within 8 reach the healthy allies
        // within 5 (us included) plus k, unless this turn is a sure kill.
        int foes = 0, friends = 1;
        for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 8;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 5 && a.hp >= a.max_hp * 0.4f;
        const bool sure_kill = target && target_ttk <= 1.0f;
        if (foes >= friends + tune::kCiOutnumbered && foes >= 2 && !sure_kill) {
            in_danger = true;
            winning = false;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
    if (tune::kSideHp > 0.0f && winning && target_ttk > 0.5f * ttd) {
        float ours = hp, theirs = 0.0f;
        for (const auto& a : w.allies)
            if (cheb(a.pos, pos) <= 6) ours += a.hp;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= 6) theirs += e.hp;
        if (ours < tune::kSideHp * theirs) winning = false;
    }
    // NOVA_COMMIT_RETREAT = f (0 = off): a hurt champion already on its way home (below f of max health) keeps
    // retreating while enemies are in view instead of re-entering the fight every turn (59% of our deaths to
    // champions came while fleeing; ladder: our champions spend 3x the top teams' time hurt near enemies).
    if (NOVA_COMMIT_RETREAT > 0.0f && heading_home && hp < max_hp * NOVA_COMMIT_RETREAT && nearest_d <= 8) {
        const bool sure_kill = target && target_ttk <= 1.0f;
        if (!sure_kill) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
    // Team commander (APEX_TFC): a lower-slot ally within 8 that has issued a fight order leads; otherwise we
    // search the team plans ourselves and, with a clear verdict, issue the order in our claim slot.
    bool tfc_applied = false;
    if ((tune::kTfc || tune::packOn) && nearest_d <= tune::kTsRange && w.groups.size() < 112) {
        if (enemy_handles.empty())
            for (const auto& e : bc::champions(team::enemy)) enemy_handles.push_back(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(e)));
        int order = 0;
        std::uint32_t order_target = 0;
        for (int s2 = 0; s2 < std::min(team_size, kClaimSlots) && s2 < slot; ++s2) {
            const int c = claim_of(s2);
            if (c < 112 || c > 118) continue;
            const AllyRec* lead = nullptr;
            for (const auto& al : w.allies)
                if (al.id == ally_handle[static_cast<std::size_t>(s2)]) lead = &al;
            if (!lead || cheb(lead->pos, pos) > 8) continue;
            order = c == 118 ? 2 : 1;
            if (order == 1 && static_cast<std::size_t>(c - 112) < enemy_handles.size()) order_target = enemy_handles[static_cast<std::size_t>(c - 112)];
            break;
        }
        bool commander = false;
        if (!order) {
            order = team_decide(order_target);
            commander = order != 0;
        }
        if (order == 1) {
            const EnemyRec* ft = nullptr;
            for (const auto& e : w.enemies)
                if (e.id == order_target) ft = &e;
            if (ft && (commander || hp >= max_hp * tune::kTfcFollowHp)) {
                target = ft;
                winning = true;
                in_danger = false;
                tfc_applied = true;
            }
            if (commander) {
                int k = 0;
                while (k < static_cast<int>(enemy_handles.size()) && enemy_handles[static_cast<std::size_t>(k)] != order_target) ++k;
                if (k < 6) write_order(112 + k);
            }
        } else if (order == 2) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
            tfc_applied = true;
            if (commander) write_order(118);
        }
    }
#if A2_POLICY >= 2 && A2_LAB
    if (!tfc_applied && target && nearest_d <= tune::kTsRange) {
        // Policy v2 (lab.h; PPO with a league in agent2/lab/ppo2_lab.js): per-unit view of the 4 nearest enemies and 3
        // nearest allies; one pass decides the verdict (fight / run / keep the bot's) and the target (an enemy slot or
        // keep the bot's choice). ~3k multiply-adds.
        float f[lab::kPolIn] = {};
        float my_hp = hp;
        const bool ci = type == bc::champion_type::cassi || type == bc::champion_type::issac;
        if (ci)
            for (const auto& a : w.allies)
                if (a.type == (type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi)) my_hp = std::min(my_hp, a.hp);
        int ready = 0;
        for (int s = 0; s < 2; ++s) ready += spell_ready(s);
        const float us_score = static_cast<float>(bc::global_submitted_gems(team::ally)), them_score = static_cast<float>(bc::global_submitted_gems(team::enemy));
        f[0] = my_hp / std::max(1.0f, max_hp), f[1] = hp / std::max(1.0f, max_hp), f[2] = strength / 100.0f, f[3] = focus / 100.0f;
        f[4] = static_cast<float>(ready), f[5] = range > 1, f[6] = gems / 50.0f, f[7] = in_danger, f[8] = winning;
        f[9] = std::min(target_ttk, 10.0f) / 10.0f, f[10] = round / 2000.0f, f[11] = (us_score - them_score) / 500.0f;
        // Enemy slots: the 4 nearest living enemies within 8, nearest first.
        const EnemyRec* slot[4] = {nullptr, nullptr, nullptr, nullptr};
        for (int k = 0; k < 4; ++k) {
            int bd = 99;
            for (const auto& e : w.enemies) {
                if (e.hp <= 0) continue;
                bool used = false;
                for (int j = 0; j < k; ++j) used |= slot[j] == &e;
                const int d = cheb(e.pos, pos);
                if (!used && d <= 8 && d < bd) bd = d, slot[k] = &e;
            }
        }
        int nvalid = 0;
        for (int k = 0; k < 4; ++k) {
            const EnemyRec* e = slot[k];
            if (!e) continue;
            ++nvalid;
            float* g = f + 12 + 10 * k;
            const int d = cheb(e->pos, pos);
            const auto kit = spell_kit(e->type, e->focus);
            bool rdy = false;
            for (std::uint32_t s2 = 0; s2 < 2 && !rdy; ++s2) {
                std::int32_t cd = 3;
                rdy = d::sdk_champion_cooldown(e->id, s2, &cd) == 0 && cd <= 1;
            }
            g[0] = 1.0f, g[1] = d / 8.0f, g[2] = e->hp / std::max(1.0f, e->max_hp), g[3] = e->hp / 1000.0f, g[4] = e->strength / 100.0f;
            g[5] = e->range > 1, g[6] = rdy, g[7] = rdy && kit.stun, g[8] = d <= range, g[9] = e->gems / 50.0f;
        }
        // Ally slots: the 3 nearest allies within 8.
        const AllyRec* aslot[3] = {nullptr, nullptr, nullptr};
        for (int k = 0; k < 3; ++k) {
            int bd = 99;
            for (const auto& a : w.allies) {
                bool used = false;
                for (int j = 0; j < k; ++j) used |= aslot[j] == &a;
                const int d = cheb(a.pos, pos);
                if (!used && d <= 8 && d < bd) bd = d, aslot[k] = &a;
            }
            if (aslot[k]) {
                float* g = f + 52 + 4 * k;
                g[0] = 1.0f, g[1] = cheb(aslot[k]->pos, pos) / 8.0f, g[2] = aslot[k]->hp / std::max(1.0f, aslot[k]->max_hp), g[3] = aslot[k]->range > 1;
            }
        }
        // Network: trunk, then the two heads.
        const float* W = lab::pol_w;
        constexpr int NI = lab::kPolIn, NH = lab::kPolHid, KV = lab::kPolOut, KT = lab::kPolT;
        const float* B1 = W + NI * NH;
        const float* WV = B1 + NH;
        const float* BV = WV + NH * KV;
        const float* WT = BV + KV;
        const float* BT = WT + NH * KT;
        float zv[KV], zt[KT];
        for (int c = 0; c < KV; ++c) zv[c] = BV[c];
        for (int c = 0; c < KT; ++c) zt[c] = BT[c];
        for (int j = 0; j < NH; ++j) {
            float v = B1[j];
            for (int i = 0; i < NI; ++i) v += f[i] * W[i * NH + j];
            const float h = std::tanh(v);
            for (int c = 0; c < KV; ++c) zv[c] += h * WV[j * KV + c];
            for (int c = 0; c < KT; ++c) zt[c] += h * WT[j * KT + c];
        }
        for (int k = 0; k < 4; ++k)
            if (!slot[k]) zt[k] = -1e9f; // empty slots cannot be chosen
        auto softmax_pick = [&](float* z, int K, float* pr) {
            float mz = z[0], sum = 0.0f;
            for (int c = 1; c < K; ++c) mz = std::max(mz, z[c]);
            for (int c = 0; c < K; ++c) sum += pr[c] = std::exp(z[c] - mz);
            int act = 0;
            for (int c = 0; c < K; ++c) {
                pr[c] /= sum;
                if (pr[c] > pr[act]) act = c;
            }
            if (lab::pol_cfg[0] == 1) {
                std::uint32_t& r = reinterpret_cast<std::uint32_t&>(lab::pol_cfg[1]);
                r = r * 1664525u + 1013904223u;
                float u = static_cast<float>(r >> 8) / 16777216.0f;
                act = K - 1;
                for (int c = 0; c < K; ++c)
                    if ((u -= pr[c]) < 0.0f) {
                        act = c;
                        break;
                    }
            }
            return act;
        };
        float pv[KV], pt[KT];
        const int av = softmax_pick(zv, KV, pv), at = softmax_pick(zt, KT, pt);
        if (lab::pol_cfg[2] < lab::kPolLogMax) {
            float* e = lab::pol_log + lab::pol_cfg[2]++ * lab::kPolEntry;
            for (int i = 0; i < NI; ++i) e[i] = f[i];
            e[NI] = static_cast<float>(av), e[NI + 1] = static_cast<float>(at);
            e[NI + 2] = std::log(std::max(1e-6f, pv[av])) + std::log(std::max(1e-6f, pt[at]));
            e[NI + 3] = static_cast<float>(round), e[NI + 4] = static_cast<float>(nvalid);
        }
        if (at < 4 && slot[at]) {
            target = slot[at];
            target_ttk = target->hp / std::max(1.0f, mine);
        }
        if (av == 0) {
            winning = true;
            in_danger = false;
            tfc_applied = true; // the policy's verdict replaces the search verdict below
        } else if (av == 1) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
            tfc_applied = true;
        } // av 2: keep the bot's own verdict (formula and search below)
    }
#endif
#if A2_POLICY == 1 && A2_LAB
    if (!tfc_applied && target && nearest_d <= tune::kTsRange) {
        // Neural fight/run policy (lab.h; trained with PPO in agent2/lab/ppo_lab.js): small enough to cost ~1k fuel.
        float f[lab::kPolIn] = {};
        float my_hp = hp;
        const bool ci = type == bc::champion_type::cassi || type == bc::champion_type::issac;
        if (ci)
            for (const auto& a : w.allies)
                if (a.type == (type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi)) my_hp = std::min(my_hp, a.hp);
        int e4 = 0, e8 = 0, a4 = 0, stun = 0;
        float ehp = 0, estr = 0, burst = 0;
        for (const auto& e : w.enemies) {
            if (e.hp <= 0) continue;
            const int d = cheb(e.pos, pos);
            e4 += d <= 4, e8 += d <= 8;
            if (d <= 6) ehp += e.hp, estr += e.strength;
            if (d <= e.range + 1) burst += e.strength;
            const auto kit = spell_kit(e.type, e.focus);
            std::int32_t cd = 3;
            for (std::uint32_t s2 = 0; s2 < 2; ++s2)
                if (d::sdk_champion_cooldown(e.id, s2, &cd) == 0 && cd <= 1 && d <= 5) {
                    burst += kit.nuke;
                    stun |= kit.stun;
                    break;
                }
        }
        for (const auto& a : w.allies) a4 += cheb(a.pos, pos) <= 4 && a.hp >= a.max_hp * 0.4f;
        int ready = 0;
        for (int s = 0; s < 2; ++s) ready += spell_ready(s);
        const float us_score = static_cast<float>(bc::global_submitted_gems(team::ally)), them_score = static_cast<float>(bc::global_submitted_gems(team::enemy));
        f[0] = my_hp / std::max(1.0f, max_hp), f[1] = strength / 100.0f, f[2] = focus / 100.0f, f[3] = static_cast<float>(ready);
        f[4] = range > 1, f[5] = gems / 50.0f, f[6] = static_cast<float>(e4), f[7] = static_cast<float>(e8), f[8] = static_cast<float>(a4);
        f[9] = ehp / 1000.0f, f[10] = estr / 100.0f, f[11] = nearest_d / 8.0f, f[12] = target->hp / std::max(1.0f, target->max_hp);
        f[13] = std::min(target_ttk, 10.0f) / 10.0f, f[14] = std::min(burst / std::max(1.0f, my_hp), 3.0f), f[15] = in_danger, f[16] = winning;
        f[17] = static_cast<float>(stun), f[18] = round / 2000.0f, f[19] = (us_score - them_score) / 500.0f, f[20] = ci;
        f[21] = static_cast<float>(alive_us - alive_them) / 5.0f, f[22] = hp / std::max(1.0f, max_hp), f[23] = 1.0f;
        const float* W = lab::pol_w;
        constexpr int K = lab::kPolOut;
        float z[K];
        for (int c = 0; c < K; ++c) z[c] = W[lab::kPolW - K + c];
        const float* W2 = W + lab::kPolIn * lab::kPolHid + lab::kPolHid;
        for (int j = 0; j < lab::kPolHid; ++j) {
            float v = W[lab::kPolIn * lab::kPolHid + j];
            for (int i = 0; i < lab::kPolIn; ++i) v += f[i] * W[i * lab::kPolHid + j];
            const float h = std::tanh(v);
            for (int c = 0; c < K; ++c) z[c] += h * W2[j * K + c];
        }
        float mz = z[0], pr[K], sum = 0.0f;
        for (int c = 1; c < K; ++c) mz = std::max(mz, z[c]);
        for (int c = 0; c < K; ++c) sum += pr[c] = std::exp(z[c] - mz);
        int act = 0;
        for (int c = 0; c < K; ++c) {
            pr[c] /= sum;
            if (pr[c] > pr[act]) act = c;
        }
        if (lab::pol_cfg[0] == 1) {
            std::uint32_t& r = reinterpret_cast<std::uint32_t&>(lab::pol_cfg[1]);
            r = r * 1664525u + 1013904223u;
            float u = static_cast<float>(r >> 8) / 16777216.0f;
            act = K - 1;
            for (int c = 0; c < K; ++c)
                if ((u -= pr[c]) < 0.0f) {
                    act = c;
                    break;
                }
        }
        if (lab::pol_cfg[2] < lab::kPolLogMax) {
            float* e = lab::pol_log + lab::pol_cfg[2]++ * lab::kPolEntry;
            for (int i = 0; i < lab::kPolIn; ++i) e[i] = f[i];
            e[lab::kPolIn] = static_cast<float>(act);
            e[lab::kPolIn + 1] = std::log(std::max(1e-6f, pr[act]));
            e[lab::kPolIn + 2] = static_cast<float>(round);
        }
        if (act == 0) {
            winning = true;
            in_danger = false;
            tfc_applied = true; // the policy's verdict replaces the search verdict below
        } else if (act == 1) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
            tfc_applied = true;
        } // act 2: keep the bot's own verdict (formula and search below)
    }
#endif
    if (!tfc_applied && tune::kTsDecide && !(A2_TSX && tune::kTSearch) && target && nearest_d <= tune::kTsRange) {
        // Fight or run by search (tactical_decide): both plans played forward with the full kits and judged with
        // the learned exchange rates; a clear verdict overrides the formula, c1 still carries it out.
        const int verdict = tactical_decide();
        PROF_CHECK("e_td");
#if A2_TD_AUTH
        // A fight verdict may clear the formula's danger only for risks the model represents: every enemy that could
        // hit us next turn is in it, no Cassi/Issac pair is split, and no awake camp reaches us (camps are not
        // modelled). Otherwise the formula keeps its flags and the flee/stand logic (which stands and fights when the
        // escape is blocked) decides. Run verdicts are always taken.
        const bool unmodelled = a2ts::snap.omit_reach || a2ts::snap.link_partial || (!tune::kTsCamps && bit(w.hot_zone, pos))
#if A2_BELIEF
            || a2_hidden_near(5, 1) > 0
#endif
            ;
#if A2_TEL
        if (verdict > 0) a2tel::bump(12u * 4096 + (in_danger ? 2u : 0u) + (unmodelled ? 1u : 0u));
#endif
        if (verdict > 0 && in_danger && unmodelled) {
            // keep the formula's danger
        } else if (verdict > 0) {
#else
        if (verdict > 0) {
#endif
            winning = true;
            in_danger = false;
        } else if (verdict < 0) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
    if (tune::kFightSim && target && nearest_d <= 7 && bc::fuel_remaining() > 30000) {
        // Play the skirmish forward both ways and keep the better plan.
        std::vector<SimUnit> units;
        SimUnit m;
        m.team = 0;
        m.pos = pos;
        m.hp = hp;
        m.max_hp = max_hp;
        m.str = strength;
        m.range = range;
        m.death_cost = deathBase + deathBag * static_cast<float>(gems);
        for (int s = 0; s < 2; ++s) {
            const auto& sp = spells[s];
            if (!sp.present || !sp.enemies) continue;
            if (sp.kind != bc::ability_kind::damage && sp.kind != bc::ability_kind::cc &&
                sp.kind != bc::ability_kind::aoe_damage)
                continue;
            const float dmg = sp.modifier * focus;
            if (dmg > m.nuke) {
                m.nuke = dmg;
                m.stun = sp.kind == bc::ability_kind::cc;
                m.cd = cooldown[s];
            }
        }
        units.push_back(m);
        for (const auto& a : w.allies) {
            if (cheb(a.pos, pos) > 8 || units.size() >= 15) continue;
            SimUnit u;
            u.team = 0;
            u.pos = a.pos;
            u.hp = a.hp;
            u.max_hp = std::max(a.max_hp, 1.0f);
            u.str = a.strength;
            u.range = a.range;
            const auto kit = spell_kit(a.type, a.focus);
            u.nuke = kit.nuke;
            u.stun = kit.stun;
            u.spell_cd = kit.two_spells ? 4 : 8;
            u.death_cost = deathBase;
            units.push_back(u);
        }
        for (const auto& e : w.enemies) {
            if (cheb(e.pos, pos) > 9 || units.size() >= 16) continue;
            SimUnit u;
            u.team = 1;
            u.pos = e.pos;
            u.hp = e.hp;
            u.max_hp = std::max(e.max_hp, 1.0f);
            u.str = e.strength;
            u.range = e.range;
            const auto kit = spell_kit(e.type, e.focus);
            u.nuke = kit.nuke;
            u.stun = kit.stun;
            u.spell_cd = kit.two_spells ? 4 : 8;
            u.death_cost = deathBase + deathBag * static_cast<float>(e.gems);
            units.push_back(u);
        }
        const auto engage = simulate_fight(units, false, tune::kSimTurns);
        const auto retreat = simulate_fight(units, true, tune::kSimTurns);
        const float margin = gems >= 25 ? 40.0f : 0.0f; // carriers need a clearer edge
        winning = engage.score > retreat.score + margin;
        in_danger = !winning && threat_on_me > 0 && nearest_d <= 5;
    }
    // NOVA_COMMIT_LATE = f (0 = off): the same retreat commitment as NOVA_COMMIT_RETREAT, applied after the
    // tactical search and the fight simulation so their verdicts cannot send a hurt, homebound champion back in.
    if (NOVA_COMMIT_LATE > 0.0f && heading_home && hp < max_hp * NOVA_COMMIT_LATE && nearest_d <= 8 &&
        !(target && target_ttk <= 1.0f)) {
        winning = false;
        in_danger = true;
        if (threat_on_me <= 0) threat_on_me = 1.0f;
    }
#if A2_DISENGAGE
    // A2_DISENGAGE (engine duel lab, agent2/lab/duel_lab.js): in a lone duel, trading blows while clearly behind on
    // health is the commonest real miss; stepping out scored better. One enemy within 6, no ally within 5, our health
    // fraction below the enemy's by A2_DIS_MARGIN, and no kill this turn: leave instead of casting and attacking.
    if (nearest && nearest_d <= 3 && !(target && target_ttk <= 1.0f)) {
        int foes = 0, friends = 0;
        for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 6;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 5;
        const float mine_f = hp / std::max(1.0f, max_hp), theirs_f = nearest->hp / std::max(1.0f, nearest->max_hp);
        if (foes == 1 && friends == 0 && mine_f < theirs_f - A2_DIS_MARGIN) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
#endif
    // NOVA_FIGHT2 bit 1, strength gate (v29 fight rewrite; 4 decoded top-vs-top games: an enemy within 4
    // tiles in only 3% of rounds, casters 5-8 tiles from enemy melee, 78% of contact while locally ahead).
    // Local strength = summed health x summed damage (spell burst spread over a short fight) within
    // NOVA_F2_RADIUS. Clearly stronger: fight the target. Clearly weaker: leave before contact, at any health.
    if ((NOVA_FIGHT2 & 1) && nearest) {
        auto eff = [](float base, bc::champion_type t, float foc) { return base + spell_kit(t, foc).nuke / 4.0f; };
        float us_hp = hp, us_dps = eff(my_dps(nullptr), type, focus);
        for (const auto& a : w.allies) {
            if (a.id == my_id || cheb(a.pos, pos) > NOVA_F2_RADIUS) continue;
            us_hp += a.hp;
            us_dps += eff(ally_dps(a), a.type, a.focus);
        }
        float th_hp = 0, th_dps = 0;
        int foes = 0;
        for (const auto& e : w.enemies) {
            const int de = cheb(e.pos, pos);
            if (de > NOVA_F2_RADIUS + 1) continue;
            if (bit(w.enemy_spawn, e.pos) && de > e.range + 2) continue;
            th_hp += e.hp;
            th_dps += eff(enemy_dps(e), e.type, e.focus);
            ++foes;
        }
        if (foes > 0) {
            const float ratio = (us_hp * us_dps) / std::max(1.0f, th_hp * th_dps);
            if (ratio >= NOVA_F2_ENGAGE && target && hp >= max_hp * 0.3f) {
                winning = true;
                in_danger = false;
            } else if (ratio <= NOVA_F2_AVOID && nearest_d <= NOVA_F2_REACH) {
                winning = false;
                in_danger = true;
                if (threat_on_me <= 0) threat_on_me = 1.0f;
            }
        }
    }
#ifdef APEX_FIGHTLOG
    // Fight dataset (analysis only): one line per contact turn; deaths are logged in play_turn.
    if (nearest_d <= 4) {
        int ne = 0, na = 0;
        float ehp = 0, edps = 0, ahp = 0, adps = 0;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= 6) ++ne, ehp += e.hp, edps += enemy_dps(e);
        for (const auto& a : w.allies)
            if (cheb(a.pos, pos) <= 6) ++na, ahp += a.hp, adps += ally_dps(a);
        bool dash = false;
        for (int s2 = 0; s2 < 2; ++s2) dash |= spell_ready(s2) && spells[s2].kind == bc::ability_kind::dash;
        std::printf("FT R%d %s hp%.0f/%.0f s%.0f f%.0f g%d T %s hp%.0f/%.0f s%.0f d%d E%d ehp%.0f edps%.0f A%d ahp%.0f adps%.0f ttk%.2f ttd%.2f win%d dang%d dash%d sp%d\n",
            round, bc::to_string(type).c_str(), hp, max_hp, strength, focus, gems,
            target ? bc::to_string(target->type).c_str() : "-", target ? target->hp : 0.0f, target ? target->max_hp : 0.0f,
            target ? target->strength : 0.0f, target ? cheb(target->pos, pos) : 99, ne, ehp, edps, na, ahp, adps,
            target_ttk > 1e8f ? 99.0f : target_ttk, ttd > 1e8f ? 99.0f : ttd, winning ? 1 : 0, in_danger ? 1 : 0, dash ? 1 : 0,
            static_cast<int>(fdist(w.spawn_field, pos)));
    }
#endif
#if A2_BURST_HOLD
    if ((type == bc::champion_type::tavi || type == bc::champion_type::willow || type == bc::champion_type::ren ||
            type == bc::champion_type::vendetta) && nearest && nearest_d <= 3 && !(target && target_ttk <= 1.0f)) {
        int foes = 0, friends = 0;
        for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 5;
        for (const auto& a : w.allies) friends += a.id != my_id && cheb(a.pos, pos) <= 4;
        if (foes == 1 && friends == 0 && hp / std::max(1.0f, max_hp) < nearest->hp / std::max(1.0f, nearest->max_hp)) a2_hold_burst = true;
    }
    // A2_BURST_HOLD 2: the engine's better move there was a single step, so take a spacing step (kite_step) instead.
    if (A2_BURST_HOLD >= 2 && a2_hold_burst && kite_step(*nearest)) {
        mode = "hold-kite";
        return true;
    }
#endif
#if A2_ASSESS
    if (nearest && nearest_d <= 4 && !(target && target_ttk <= 1.0f)) {
        // Learned fight-or-run assessment (assess_model.h, trained on engine counterfactuals): the predicted 3-round
        // value of fighting minus running, in gems. A confident prediction overrides the verdict.
        float f[assess_model::kIn] = {};
        const int ti = static_cast<int>(type);
        if (ti >= 0 && ti < 12) f[ti] = 1.0f;
        f[12] = hp / std::max(1.0f, max_hp);
        f[13] = static_cast<float>(gems) / 100.0f;
        f[14] = strength / 100.0f;
        f[15] = spells[0].present && cooldown[0] == 0 ? 1.0f : 0.0f;
        f[16] = spells[1].present && cooldown[1] == 0 ? 1.0f : 0.0f;
        f[17] = static_cast<float>(round) / 1000.0f;
        const int radii[3] = {3, 5, 8};
        const EnemyRec* nb = nullptr;
        int nbd = 99, reach_me = 0, in_mine = 0;
        float ours = hp, theirs = 0.0f, weakest = 1.0f;
        for (const auto& e : w.enemies) {
            const int d = cheb(e.pos, pos);
            for (int k = 0; k < 3; ++k)
                if (d <= radii[k]) f[18 + 5 * k] += 1.0f, f[19 + 5 * k] += e.hp / 1000.0f, f[20 + 5 * k] += e.strength / 100.0f;
            if (d < nbd) nbd = d, nb = &e;
            reach_me += d <= std::max(1, e.range) + 1;
            if (d <= range) ++in_mine, weakest = std::min(weakest, e.hp / std::max(1.0f, e.max_hp));
            if (d <= 4) theirs += e.hp;
        }
        for (const auto& a : w.allies) {
            if (a.id == my_id) continue;
            const int d = cheb(a.pos, pos);
            for (int k = 0; k < 3; ++k)
                if (d <= radii[k]) f[21 + 5 * k] += 1.0f, f[22 + 5 * k] += a.hp / 1000.0f;
            if (d <= 4) ours += a.hp;
        }
        if (nb) {
            f[33] = static_cast<float>(nbd) / 8.0f;
            f[34] = nb->hp / std::max(1.0f, nb->max_hp);
            f[35] = nb->range > 1 ? 1.0f : 0.0f;
        }
        f[36] = static_cast<float>(reach_me);
        f[37] = static_cast<float>(in_mine);
        f[38] = std::clamp(std::log((ours + 1.0f) / (theirs + 1.0f)), -3.0f, 3.0f);
        f[39] = weakest;
        for (const auto& c : w.camps)
            if (!c.dead && c.hp > 0 && c.strength > 0 && cheb(c.pos, pos) <= 4) f[40] += 1.0f, f[41] += c.strength / 100.0f;
        float out = assess_model::kB2;
        for (int j = 0; j < assess_model::kHidden; ++j) {
            float v = assess_model::kB1[j];
            for (int i = 0; i < assess_model::kIn; ++i) v += (f[i] - assess_model::kMu[i]) / assess_model::kSd[i] * assess_model::kW1[i][j];
            out += std::tanh(v) * assess_model::kW2[j];
        }
        if (out > A2_ASSESS_MARGIN) {
            winning = true;
            in_danger = false;
        } else if (out < -A2_ASSESS_MARGIN) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
#endif
#if (A2_TEAMFIGHT & 1) || A2_LAB
    // Team fight by local numbers (A2_TEAMFIGHT bit 1; MOBA influence maps). Mirror games are won by whoever wins the
    // middle fights: the winner dies ~6 times less. Each side's strength at the contact point is health x damage
    // (spell burst spread over a short fight), each champion weighted by how soon it can be in range there (1 turn
    // full, 3 turns 0.6, 5 turns 0.3), plus expected hidden enemies from beliefs. A clear edge engages, a clear deficit
    // disengages; in between the fight search's verdict stands. Applied last, so it only changes decisive cases.
    // Lab knob 41 (engage only, without the A2_TEAMFIGHT build switch): k > 0 engages at a ratio of 3 / (1 + k).
    const float tf_engage = (A2_TEAMFIGHT & 1) ? A2_TF_ENGAGE : LABK(41) > 0.0f ? 3.0f / (1.0f + LABK(41)) : 1e30f;
    const float tf_avoid = (A2_TEAMFIGHT & 1) ? A2_TF_AVOID : 0.0f;
    if (nearest && (tf_engage < 1e29f || tf_avoid > 0.0f)) {
        const vec2 at = target ? target->pos : nearest->pos;
        auto eff = [](float base, bc::champion_type t, float foc) { return base + spell_kit(t, foc).nuke / 4.0f; };
        auto weight = [](int t) { return t <= 1 ? 1.0f : t <= 3 ? 0.6f : t <= 5 ? 0.3f : 0.0f; };
        const float wme = std::max(0.6f, weight(std::max(0, cheb(pos, at) - range)));
        float us_h = wme * hp, us_d = wme * eff(my_dps(nullptr), type, focus);
        for (const auto& a : w.allies) {
            if (a.id == my_id) continue;
            const float wa = weight(std::max(0, cheb(a.pos, at) - a.range));
            us_h += wa * a.hp;
            us_d += wa * eff(ally_dps(a), a.type, a.focus);
        }
        float th_h = 0, th_d = 0, seen = 0, avg_h = 0, avg_d = 0;
        for (const auto& e : w.enemies) {
            if (e.hp <= 0) continue;
            const float we = weight(std::max(0, cheb(e.pos, at) - e.range));
            const float d = eff(enemy_dps(e), e.type, e.focus);
            th_h += we * e.hp;
            th_d += we * d;
            avg_h += e.hp, avg_d += d, seen += 1.0f;
        }
        if (tune::kBelief && seen > 0.0f) {
            // Enemies we cannot see that could be here within ~5 turns, at the visible enemies' average strength.
            int near5 = 0;
            for (const auto& e : w.enemies) near5 += cheb(e.pos, at) <= 5;
            const float hidden = w.expected_enemies(at, 5) - static_cast<float>(near5);
            if (hidden > 0.3f) {
                th_h += 0.5f * hidden * avg_h / seen;
                th_d += 0.5f * hidden * avg_d / seen;
            }
        }
        if (th_h > 0.0f) {
            const float ratio = (us_h * us_d) / std::max(1.0f, th_h * th_d);
            if (ratio >= tf_engage && target && hp >= max_hp * 0.3f) {
                winning = true;
                in_danger = false;
            } else if (ratio <= tf_avoid && nearest_d <= nearest->range + 3) {
                winning = false;
                in_danger = true;
                if (threat_on_me <= 0) threat_on_me = 1.0f;
            }
        }
    }
#endif
#if A2_LAB
    {
        // Engine lab (lab.h kinds 4 / 5): from the first turn an enemy is within 4, force the fight / run verdict for
        // len rounds (kind -4 / -5: record only). The bot's own verdict is recorded in rec_after (1 fight, -1 run, 0 none).
        const auto me_id = static_cast<std::int32_t>(my_id);
        const int lk = lab::ctl.kind < 0 ? -lab::ctl.kind : lab::ctl.kind;
        if (lab::ctl.champ == me_id && (lk == 4 || lk == 5) && round >= lab::ctl.round && lab::ctl.rec_round == -2 && nearest && nearest_d <= 4) {
            lab::ctl.rec_round = round;
            lab::ctl.rec_after = winning ? 1 : (in_danger ? -1 : 0);
            lab::ctl.rec_gems = gems;
            lab::ctl.rec_hp = static_cast<std::int32_t>(100.0f * hp / std::max(1.0f, max_hp));
        }
        if (lab::active(me_id, round, 4)) {
            winning = true;
            in_danger = false;
        } else if (lab::active(me_id, round, 5)) {
            winning = false;
            in_danger = true;
            if (threat_on_me <= 0) threat_on_me = 1.0f;
        }
    }
#endif
#if A3_NUMBERS || A3_BACKOFF
    {
        // A3: local numbers decide commitment. Friends: us plus healthy allies within 6; foes: live enemies within 7
        // (one parked on its own spawn out of reach does not count).
        int friends = 1, foes = 0;
        for (const auto& a : w.allies) friends += cheb(a.pos, pos) <= 6 && a.hp >= 0.4f * a.max_hp;
        for (const auto& e : w.enemies) {
            if (e.hp <= 0) continue;
            const int d = cheb(e.pos, pos);
            if (d > 7 || (bit(w.enemy_spawn, e.pos) && d > e.range + 2)) continue;
            ++foes;
        }
        const bool sure_kill = target && target_ttk <= 1.0f;
        // Engage only with a numbers edge: never commit while they outnumber us here.
        if (A3_NUMBERS && foes > friends && !sure_kill && winning) {
            winning = false;
            if (nearest_d <= 6) {
                in_danger = true;
                if (threat_on_me <= 0) threat_on_me = 1.0f;
            }
        }
        // Back off less in contact: with more of us than them, health left and a target we kill before it kills us,
        // keep fighting instead of turning our backs (top teams back off 0.26 of contact turns, we 0.39).
        const bool edge = friends >= foes + 1 ||
            (A3_BACK_EQ > 0.0f && friends >= foes && target && target->hp < A3_BACK_EQ * std::max(1.0f, target->max_hp));
        if (A3_BACKOFF && team_size >= A3_BACK_MIN_SIZE && target && in_danger && !winning && edge && hp >= A3_BACK_HP * max_hp && gems < 60 &&
            target_ttk * risk * ci_risk <= std::max(ttd, 1.0f) * A3_BACK_K) {
            winning = true;
            in_danger = false;
        }
    }
#endif
    if (tune::kTribDeny & 2) {
        if (in_danger && !winning) try_lock_altar(); // leaving: cancel whatever tribute we can reach
        else if (deny_tribute()) return true;
    }
    PROF_CHECK("e_mid");
    if (in_danger && !winning) last_flee_round = round;
#if X1_FLEEDROP
    // X1_FLEEDROP (audit F01: the camp target survived the flee, so the next calm turn walked back to it). Drop it and
    // keep it out of the scoring for X1_FLEEDROP rounds.
    if (in_danger && !winning && target_group >= 0) flee_group = target_group, target_group = -1;
#endif
    if (in_danger && !winning && tune::kBushRecall && hp < max_hp * 0.5f && hidden_here() && !bit(w.hot_zone, pos) &&
        fdist(w.spawn_field, pos) > tune::kShopWalkDist) {
        // Losing, hurt and hidden: recall from cover (nobody can hit us here to cancel it).
        try {
            bc::self().recall();
            mode = "bush-recall";
            heading_home = true;
            return true;
        } catch (const std::exception& e) {
            LOG("bush recall error %s\n", e.what());
        }
    }
    // Tactical search (APEX_TSEARCH): play the candidate actions forward and take the best line, in the
    // turns where we would fight or flee anyway (otherwise farming goes on).
    const bool c1_acts = (in_danger && !winning) ||
        (target && (winning || (cheb(target->pos, pos) <= range && ttd > 6.0f * risk)));
    if (tune::kTSearch && c1_acts && nearest_d <= tune::kTsRange && tactical_search()) {
        mode = "tsearch";
        heading_home = in_danger && !winning && hp < max_hp * 0.5f;
        return true;
    }
    if (in_danger && !winning && tune::kStand2 && melee_caught()) return true;
    // Caster micro (APEX_CMICRO): ranged champions pick stay-and-shoot or a step by damage dealt against damage risked.
    if (tune::kCMicro && (!melee || NOVA_CMICRO_MELEE) && nearest && nearest_d <= tune::kCMicroRange &&
        (type != bc::champion_type::cassi || tune::kCMicroCassi == 1 || (tune::kCMicroCassi == 2 && [&] {
            // Auto (2): Cassi uses the micro in caster lineups only; beside a melee lineup she fights with Issac.
            if (team_casters < 0) {
                team_casters = 0;
                for (const auto& c : bc::champions(team::ally)) {
                    d::champion_info info{};
                    if (d::sdk_champion(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(c)), &info) != 0) continue;
                    const auto ct = static_cast<bc::champion_type>(info.type);
                    team_casters += ct == bc::champion_type::stellar || ct == bc::champion_type::tavi ||
                        ct == bc::champion_type::prism || ct == bc::champion_type::willow;
                }
            }
            return team_casters > 0;
        }())) &&
        !(in_danger && !winning && hp < max_hp * tune::kCMicroFleeHp) && caster_micro(target, winning || !in_danger)) {
        mode = "cmicro";
        heading_home = in_danger && !winning && hp < max_hp * 0.5f;
        return true;
    }
    PROF_CHECK("e_prestand");
#if NOVA_FLEE_HIT
    // NOVA_FLEE_HIT (ported from v36fight): a melee champion that is about to leave first hits the weakest enemy next to
    // it (melee can attack and then move). The flee code below only hits the chosen target, often a wounded enemy a few
    // tiles away, so the one beating on us got no return hit (top-team melee hit back 70-74% of outnumbered turns, ours
    // 38-63%). Only the basic attack is used; dash, spells, resets and the move stay available, and the turn goes on.
    if (in_danger && !winning && melee && bc::self().can_attack()) {
        const EnemyRec* adj = nullptr;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= range && (!adj || e.hp < adj->hp)) adj = &e;
        if (adj && (!target || cheb(target->pos, pos) > range) && attack_unit(adj->unit, adj->pos)) {
#if A2_TEL
            a2tel::fleehit_round = round;
#endif
        }
    }
#endif
    if (in_danger && !winning && tune::kStand && escape_or_stand(target, nearest, ttd)) return true;
    PROF_CHECK("e_stand");
    if (in_danger && !winning) {
        if (tune::kStaleBag > 0 && gems >= tune::kStaleBag) {
            // The enemy holds this altar (the collision/corners bank stalls: carriers approach, flee and return
            // for 250+ rounds). Send the next banking trip to another altar.
            for (std::size_t i = 0; i < w.altars.size() && i < altar_watch.size(); ++i)
                if (cheb(w.altars[i], nearest->pos) <= 6 || cheb(w.altars[i], pos) <= 6) altar_watch[i] = round + tune::kStaleWatch;
        }
        mode = "flee";
        if (tune::kRangedFlee && !melee && nearest && cheb(nearest->pos, pos) <= 4) {
            // Ranged flight (APEX_RANGED_FLEE, from apex_v21): a ranged basic attack ends our movement. Stun the
            // nearest chaser when the stun still lets us walk, step away, and shoot only when no step is possible.
            for (int s2 = 0; s2 < 2; ++s2) {
                const auto& sp = spells[s2];
                if (!spell_ready(s2) || sp.kind != bc::ability_kind::cc || !sp.enemies || sp.excludes_walk) continue;
                if (cheb(nearest->pos, pos) > static_cast<int>(sp.range)) continue;
                try {
                    if (bc::self().abilities()[s2].use(nearest->unit)) cast_done = true;
                } catch (const std::exception& ex) {
                    LOG("flee stun error %s\n", ex.what());
                }
                break;
            }
            if ((tune::kKiteCast & 4) && !cast_done && !melee) {
                int foes = 0;
                for (const auto& e : w.enemies) foes += cheb(e.pos, pos) <= 5;
                if (foes == 1 && nearest->range <= 1) {
                    for (int s2 = 0; s2 < 2; ++s2) {
                        const auto& sp = spells[s2];
                        if (!spell_ready(s2) || sp.kind != bc::ability_kind::cc || !sp.enemies || !sp.excludes_walk) continue;
                        if (cheb(nearest->pos, pos) > static_cast<int>(sp.range)) continue;
                        try {
                            if (bc::self().abilities()[s2].use(nearest->unit)) {
                                cast_done = true;
                                mode = "flee-stun";
                                return true;
                            }
                        } catch (const std::exception& ex) {
                            LOG("flee stun error %s\n", ex.what());
                        }
                    }
                }
            }
            const int planned_r = tune::kEscapeSearch ? run_escape(false) : 0;
            const bool moved_r = planned_r == 1 || (planned_r == 0 && ((((NOVA_FIGHT2 & 4) || (A2_TEAMFIGHT & 2)) && regroup_from(nearest->pos)) || retreat_from(nearest->pos)));
            if (!moved_r && target && cheb(target->pos, pos) <= range) {
                cast_on_enemy(*target);
                attack_unit(target->unit, target->pos);
            }
            heading_home = hp < max_hp * 0.5f;
            return true;
        }
        const bool kite_run = tune::kKite > 0 && !melee && nearest_enemy_melee() < tune::kKite;
        if (!kite_run && target && cheb(target->pos, pos) <= range && (!melee || cheb(target->pos, pos) <= 1)) {
            if (!melee) {
                cast_on_enemy(*target);
                attack_unit(target->unit, target->pos);
                return true; // ranged: shooting used the move
            }
            attack_unit(target->unit, target->pos);
        }
        const int planned = tune::kEscapeSearch ? run_escape(false) : 0;
        const bool moved = planned == 1 || (planned == 0 && ((((NOVA_FIGHT2 & 4) || (A2_TEAMFIGHT & 2)) && regroup_from(nearest->pos)) || retreat_from(nearest->pos)));
        if (!moved && target) attack_unit(target->unit, target->pos);
        heading_home = hp < max_hp * 0.5f;
        return true;
    }
    PROF_CHECK("e_noflee");
    if (!target) return false;

    const int dist = cheb(target->pos, pos);
    // Fight if we win the race, or trade when the enemy is already in our range and we are healthy.
    const bool engage = winning || (dist <= range && ttd > 6.0f * risk);
    if (!engage) return false;
    if ((tune::kKiteCast & 1) && !melee && dist <= enemy_spell_reach() && cast_on_enemy(*target)) {
        // Spell first; a kite step can wait for the cooldown turns.
        mode = "kite-cast";
        if (dist <= range) attack_unit(target->unit, target->pos);
        else if (!walked && tune::kKite > 0 && nearest_enemy_melee() < tune::kKite) kite_step(*target);
        return true;
    }
    if (tune::kKite > 0 && !melee && nearest_enemy_melee() < tune::kKite && kite_step(*target)) {
        mode = "kite";
        return true;
    }
    PROF_CHECK("e_prefight");
    mode = "fight-champ";
    if (tune::kPosition && dist <= range + 1 && position_and_attack(*target)) {
        cast_on_enemy(*target);
        if (attack_unit(target->unit, target->pos)) use_reset_and_attack(target->unit, target->pos);
        return true;
    }
    if (dist <= range) {
        cast_on_enemy(*target);
        if (attack_unit(target->unit, target->pos)) use_reset_and_attack(target->unit, target->pos);
        return true;
    }
#if A2_GAPDASH
    // Gap-closing dash (A2_GAPDASH): a melee champion 3 tiles from its target only walks to 2 and lands no hit, and a
    // target that keeps walking away is never caught. A ready dash lands next to it now and the hit follows (one cast
    // per turn, so no reset this turn). Bit 1: Heart of Ruin's striking dash (damage and a stun around the landing);
    // bit 2: a plain dash (Vendetta), landing on the free tile next to the target that the fewest other enemies reach.
    if (melee && dist == 3 && bc::self().can_attack()) {
        bool dashed = false;
        for (int s = 0; s < 2 && !dashed; ++s) {
            if (!spell_ready(s) || spells[s].kind != bc::ability_kind::dash) continue;
            const bool strike = spells[s].modifier > 0.0f;
            if (strike) {
                if (A2_GAPDASH & 1) dashed = cast_on_enemy(*target);
                break;
            }
            if (!(A2_GAPDASH & 2)) break;
            const int reach = std::max(1, static_cast<int>(spells[s].range));
            struct Cand {
                vec2 p;
                int score;
            };
            Cand cands[9];
            int n = 0;
            for (int dy = -1; dy <= 1; ++dy)
                for (int dx = -1; dx <= 1; ++dx) {
                    const vec2 q{target->pos.x + dx, target->pos.y + dy};
                    if ((dx == 0 && dy == 0) || !in_bounds(q, w.width, w.height) || cheb(pos, q) > reach || bit(w.static_blocked, q) ||
                        bit(w.unit_tiles, q))
                        continue;
                    int sc = 0;
                    for (const auto& e : w.enemies)
                        if (e.id != target->id && cheb(q, e.pos) <= e.range + 1) sc += 10;
                    sc += cheb(pos, q);
                    int i = n++;
                    for (; i > 0 && cands[i - 1].score > sc; --i) cands[i] = cands[i - 1];
                    cands[i] = {q, sc};
                }
            for (int i = 0; i < n && i < 3 && !dashed; ++i) {
                try {
                    if (bc::self().abilities()[s].use(cands[i].p)) {
                        pos = cands[i].p;
                        cast_done = true;
                        dashed = true;
                    }
                } catch (const std::exception& ex) {
                    LOG("gap dash error %s\n", ex.what());
                }
            }
        }
        if (dashed) {
            mode = "gap-dash";
            if (cheb(target->pos, pos) <= range) attack_unit(target->unit, target->pos);
            return true;
        }
    }
#endif
    if ((tune::kKiteCast & 2) && dist <= enemy_spell_reach() && cast_on_enemy(*target)) {
        mode = "fight-cast";
        return true; // the spell reached from here; walking in first would have forbidden it
    }
    if (dist <= range + tune::kChaseRange) {
        bc::bitboard goal;
        goal.clear();
        goal.draw_chebyshev(target->pos, static_cast<float>(range));
        walk_toward(goal);
        if (cheb(target->pos, pos) <= range) {
            cast_on_enemy(*target);
            if (attack_unit(target->unit, target->pos)) use_reset_and_attack(target->unit, target->pos);
        }
        return true;
    }
    return false;
}

// ---------------------------------------------------------------- opening rush

int Bot::rush_leader_slot() const {
    for (int s = 0; s < std::min(team_size, static_cast<int>(ally_handle.size())); ++s) {
        std::int32_t alive = 1;
        if (d::sdk_champion_is_alive(ally_handle[static_cast<std::size_t>(s)], &alive) == 0 && alive) return s;
    }
    return slot;
}

bool Bot::rush_active() const {
    if (round >= NOVA_RUSH_UNTIL) return false;
    if (gems >= NOVA_RUSH_GEMS) return false;
    // Only while we have at least as many living champions as they do.
    int us = 0, them = 0;
    for (const auto& c : bc::champions(team::ally)) {
        std::int32_t a = 1;
        d::sdk_champion_is_alive(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(c)), &a);
        us += a != 0;
    }
    for (const auto& c : bc::champions(team::enemy)) {
        std::int32_t a = 1;
        d::sdk_champion_is_alive(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(c)), &a);
        them += a != 0;
    }
    return us >= them + NOVA_RUSH_MARGIN;
}

bool Bot::rush() {
    if (!rush_active()) return false;
    if (hp < max_hp * 0.45f) return false;
    FlagScope combat{combat_move};
    if (rush_visited.size() != w.groups.size()) rush_visited.assign(w.groups.size(), 0);
    const int leader = rush_leader_slot();
    if (leader == slot) {
        // Next enemy-side camp: nearest to the enemy spawn among those not yet checked.
        const vec2 home = ts_home[1].x >= 0 ? ts_home[1] : w.enemy_spawn.positions().front();
        auto visited_here = [&](int gi) {
            const auto& g = w.groups[static_cast<std::size_t>(gi)];
            for (int ci : g.camps)
                if (cheb(w.camps[static_cast<std::size_t>(ci)].pos, pos) <= 2) return true;
            return false;
        };
        if (rush_target >= 0 && visited_here(rush_target)) rush_visited[static_cast<std::size_t>(rush_target)] = 1;
        if (rush_target < 0 || rush_visited[static_cast<std::size_t>(rush_target)]) {
            rush_target = -1;
            int best_d = 1 << 30;
            for (std::size_t gi = 0; gi < w.groups.size(); ++gi) {
                const auto& g = w.groups[gi];
                if (rush_visited[gi] || g.camps.empty() || (g.gems == 0 && g.gold < 60)) continue;
                const vec2 cp = w.camps[static_cast<std::size_t>(g.camps[0])].pos;
                const int de = cheb(cp, home), dm = cheb(cp, pos);
                if (de > NOVA_RUSH_RADIUS) continue;
                const int key = de * 2 + dm;
                if (key < best_d) best_d = key, rush_target = static_cast<int>(gi);
            }
        }
        if (rush_target < 0) return false;
        write_claim(rush_target);
        // Wait for the pack: do not run more than 3 tiles ahead of the nearest follower we can see.
        int behind = 0;
        for (const auto& a : w.allies) behind = std::max(behind, cheb(a.pos, pos));
        mode = "rush-lead";
        if (behind > 3 && behind <= 8) return true;
        bc::bitboard goal;
        goal.clear();
        for (int ci : w.groups[static_cast<std::size_t>(rush_target)].camps)
            goal.draw_chebyshev(w.camps[static_cast<std::size_t>(ci)].pos, 2.0f);
        walk_toward(goal);
        return true;
    }
    // Follower: stay within 2 tiles of the leader, or head for the leader's claim when it is out of sight.
    for (const auto& a : w.allies) {
        if (a.id != ally_handle[static_cast<std::size_t>(leader)]) continue;
        mode = "rush-follow";
        if (cheb(a.pos, pos) <= 2) return true;
        bc::bitboard goal;
        goal.clear();
        goal.draw_chebyshev(a.pos, 1.0f);
        walk_toward(goal);
        return true;
    }
    const int lc = claim_of(leader);
    if (lc >= 0 && lc < static_cast<int>(w.groups.size())) {
        mode = "rush-join";
        bc::bitboard goal;
        goal.clear();
        for (int ci : w.groups[static_cast<std::size_t>(lc)].camps) goal.draw_chebyshev(w.camps[static_cast<std::size_t>(ci)].pos, 2.0f);
        walk_toward(goal);
        return true;
    }
    return false;
}

// Move toward the freshest nearby enemy sighting when healthy and not carrying much.
bool Bot::hunt() {
    FlagScope combat{combat_move};
    // Tribute snipe (APEX_SNIPE): an enemy channelling a tribute stands still until the channel ends (ceil(bag / 10)
    // turns at most from now); reach it in time and its bag is ours.
    if (tune::kSnipe > 0 && hp >= max_hp * 0.6f && gems < 60) {
        const EnemyRec* best = nullptr;
        int best_d = 1000;
        for (const auto& e : w.enemies) {
            if (!e.tributing() || e.gems < 20) continue;
            const int walk = std::max(0, cheb(e.pos, pos) - range);
            if (walk > tune::kSnipe || walk > (e.gems + 9) / 10) continue;
            int guards = 0;
            for (const auto& o : w.enemies) guards += o.id != e.id && cheb(o.pos, e.pos) <= 4;
            if (guards > 1) continue;
            if (walk < best_d) best_d = walk, best = &e;
        }
        if (best) {
            mode = "snipe";
            if (cheb(best->pos, pos) <= range) {
                cast_on_enemy(*best);
                if (attack_unit(best->unit, best->pos)) use_reset_and_attack(best->unit, best->pos);
                return true;
            }
            bc::bitboard goal;
            goal.clear();
            goal.draw_chebyshev(best->pos, static_cast<float>(range));
            walk_toward(goal);
            if (cheb(best->pos, pos) <= range) {
                cast_on_enemy(*best);
                attack_unit(best->unit, best->pos);
            }
            return true;
        }
    }
    // Answer a teammate's distress call: the enemy chasing them is out of position.
    if (tune::kDistress && round - distress.round <= 3 && hp >= max_hp * 0.5f && gems < 40) {
        const int d = cheb(distress.pos, pos);
        if (d > 0 && d <= tune::kDistressRange) {
            mode = "rescue";
            bc::bitboard goal;
            goal.clear();
            goal.draw_chebyshev(distress.pos, static_cast<float>(range));
            walk_toward(goal);
            return true;
        }
    }
    if (!tune::kHunt || gems >= tune::kHuntGems || hp < max_hp * tune::kHuntHp) return false;
    // Hunting toward enemies we then flee from loops forever (and enemies on their spawn heal).
    if (tune::kHuntFix && round - last_flee_round < 10) return false;
    const Sighting* best = nullptr;
    int best_d = tune::kHuntRange + 1;
#if X1_HUNT_SOLO
    {   // X1_HUNT_SOLO (Hagelbaeck's fog-of-war bot beat its full-vision twin because long detection made units attack
        // alone): with no ally within 5, hunt only sightings within X1_HUNT_SOLO tiles.
        bool ally = false;
        for (const auto& a : w.allies) ally |= cheb(a.pos, pos) <= 5;
        if (!ally) best_d = std::min(best_d, X1_HUNT_SOLO + 1);
    }
#endif
    for (const auto& s : w.sightings) {
        if (round - s.round > 3) continue;
        if (tune::kHuntFix && bit(w.enemy_spawn_zone, s.pos)) continue;
        const int d0 = cheb(s.pos, pos);
        if (d0 < best_d) {
            best_d = d0;
            best = &s;
        }
    }
    if (!best) return false;
    mode = "hunt";
    bc::bitboard goal;
    goal.clear();
    goal.draw_chebyshev(best->pos, static_cast<float>(range));
    walk_toward(goal);
    return true;
}

bool Bot::go_home_if_needed() {
    auto& me = bc::self();
    const bool on_spawn = bit(w.ally_spawn, pos);
    if (on_spawn) {
        heading_home = false;
        // NOVA_SPAWN_HOT: an awake camp that reaches our spawn hits us every round before the heal, so
        // "heal to full" never ends (two champions held spawn 1,100 turns, one with a 120-gem bag).
        if (NOVA_SPAWN_HOT && bit(w.hot_zone, pos) && hp >= max_hp * 0.85f) return false;
        return hp < max_hp; // stay put this turn so the spawn heals us
    }
    if (type == bc::champion_type::tavi && hp >= max_hp * tune::kRetreatHp) return false; // Tavi shops anywhere
    // NOVA_CI_RETREAT: a Cassi or Issac death kills both bodies (57% of the body-rounds we lost to
    // champion kills), so they head home at a higher health fraction.
    const bool ci_body = type == bc::champion_type::cassi || type == bc::champion_type::issac;
    bool low = hp < max_hp * tune::kRetreatHp * (ci_body ? NOVA_CI_RETREAT : 1.0f);
    if (NOVA_CI_LINK) {
        // One fate: Cassi and Issac share deaths and healing, so retreat on the weaker body's health.
        const auto other =
            type == bc::champion_type::cassi ? bc::champion_type::issac : bc::champion_type::cassi;
        if ((type == bc::champion_type::cassi || type == bc::champion_type::issac))
            for (const auto& a : w.allies)
                if (a.type == other) low = low || std::min(hp, a.hp) < max_hp * tune::kRetreatHp;
    }
    if (!low && tune::kThreatRetreat > 0.0f && hp < max_hp * tune::kThreatRetreat) {
        bool threat = !w.enemies.empty();
        for (const auto& sg : w.sightings) threat |= round - sg.round <= 6 && cheb(sg.pos, pos) <= 10;
        low = threat;
    }
    // Gold-only trips stop once the build plan is complete (the report's boss-battle carriers made 200-300 of them with
    // 300-700 gems in the bag and nothing left to buy). Health retreats and threat retreats are unchanged.
    bool rich = gold >= tune::kShopGold && !shop_done;
#if V58_DIRECTOR && V58_CARRY_SHOP
    if (economy_enabled() && slot == economy_carry() && ec_treasure_shards < 5) {
        const int remaining = 30 * (5 - ec_treasure_shards);
        rich = gold >= remaining && fdist(w.spawn_field, pos) <= 12;
        // Complete the clear before starting a gold-only shopping trip; captures already have a guard below.
        if (target_group >= 0 && w.groups[target_group].state == GroupState::alive &&
            w.groups[target_group].hp_left(w.camps) < w.groups[target_group].max_hp - 1.0f) rich = false;
    }
#endif
    if (!heading_home && !low && !rich) return false;
#if V58_FINISH_RESET
    if (rich && !low && !heading_home && hp >= 0.65f * max_hp && w.enemies.empty() &&
        target_group >= 0 && target_group < static_cast<int>(w.groups.size())) {
        const auto& pending = w.groups[target_group];
        if (reset_defer_group != target_group) reset_defer_group = target_group, reset_defer_until = -1;
        bool close_finish = false;
        if (pending.state == GroupState::alive) {
            bool in_range = false;
            for (int ci : pending.camps) if (!w.camps[ci].dead && cheb(w.camps[ci].pos, pos) <= range) in_range = true;
            close_finish = in_range && pending.hp_left(w.camps) <= 2.0f * my_dps(&pending) &&
                hp - 3.0f * incoming_from_group(pending, pos) >= 0.45f * max_hp;
        } else if (pending.state == GroupState::reward) {
            for (vec2 tile : pending.tiles.positions()) if (cheb(tile, pos) <= 2) { close_finish = true; break; }
        }
        if (close_finish) {
            if (reset_defer_until < 0) reset_defer_until = round + 10;
            if (round < reset_defer_until) return false; // one bounded deferral per target, never a rolling deadline
        }
    }
#endif
    // Do not abandon a capture we are standing on.
    if (!low && target_group >= 0 && w.groups[target_group].state == GroupState::reward &&
        bit(w.groups[target_group].tiles, pos))
        return false;
    heading_home = true;
    // Camp damage would cancel a recall: leave every awake camp's reach first.
    if (bit(w.hot_zone, pos)) {
        mode = "home-escape";
        walk_toward(~w.hot_zone & ~w.static_blocked);
        return true;
    }
    if (tune::kAwakeZone && hp < prev_hp - 0.5f && w.enemies.empty()) {
        // Hit since our last turn with no enemy in sight: some camp still reaches us, so a recall
        // here would be cancelled again. Step out of every live camp's reach first.
        bc::bitboard reach;
        reach.clear();
        for (std::size_t ci = 0; ci < w.camps.size(); ++ci) {
            const auto& c = w.camps[ci];
            if (c.dead || c.strength <= 0 || cheb(c.pos, pos) > c.range + 1) continue;
            const int gi = w.camp_group[ci];
            if (gi < 0 || w.groups[static_cast<std::size_t>(gi)].state != GroupState::alive) continue;
            reach.draw_chebyshev(c.pos, static_cast<float>(c.range));
        }
        if (bit(reach, pos)) {
            mode = "home-escape";
            walk_toward(~reach & ~w.static_blocked);
            return true;
        }
    }
    const int dist = fdist(w.spawn_field, pos);
    bool enemy_close = false;
    for (const auto& e : w.enemies) enemy_close |= cheb(e.pos, pos) <= 6;
    for (const auto& s : w.sightings) enemy_close |= round - s.round <= 2 && cheb(s.pos, pos) <= 5;
    // From cover no enemy can hit us, so their presence cannot cancel the recall.
    if (enemy_close && tune::kBushRecall && hidden_here() && !bit(w.hot_zone, pos)) enemy_close = false;
    if (dist > tune::kShopWalkDist && !enemy_close) {
        try {
            me.recall();
            return true;
        } catch (const std::exception& e) {
            LOG("recall error %s\n", e.what());
        }
    }
    bc::bitboard blocked = w.static_blocked | w.unit_tiles | w.hot_zone;
    blocked.set(pos, false);
    if (!follow_field(w.spawn_field, blocked, true)) {
        blocked = w.static_blocked | w.unit_tiles;
        blocked.set(pos, false);
        if (!follow_field(w.spawn_field, blocked, true) && tune::kUnstick && !walk_toward(w.ally_spawn)) break_out();
    }
    return true;
}

bool Bot::tribute_if_needed() {
    if (gems <= 0) return false;
#if A2_ALTARFIX
    if (w.no_bank || round < tribute_off_until) return false;
#endif
#if A2_LAB
    if (lab::active(static_cast<std::int32_t>(my_id), round, 3)) return false; // engine lab: hold the bag
    if (lab::active(static_cast<std::int32_t>(my_id), round, 2)) lab::ctl.rec_after = (lab::ctl.rec_after < 0 ? 0 : lab::ctl.rec_after) + 1;
#endif
    auto& me = bc::self();
    // Route around recently seen enemies when carrying a real bag.
    bc::distance_field safe_field;
    bool use_safe = false;
    w.ensure_altar_field();
    int dist = fdist(w.altar_field, pos);
    bc::bitboard watched;
    watched.clear();
    bool any_watch = false, any_free = false;
    if (tune::kStaleBag > 0 && gems >= tune::kStaleBag) {
        for (std::size_t i = 0; i < w.altars.size() && i < altar_watch.size(); ++i) {
            if (altar_watch[i] > round) {
                watched.draw_chebyshev(w.altars[i], 2.0f);
                any_watch = true;
            } else {
                any_free = true;
            }
        }
        any_watch = any_watch && any_free;
    }
    if (gems >= 15) {
        bc::bitboard threat = w.threat_zone(round, V58_SURVIVE ? 15 : 10, 4.0f);
        threat.set(pos, false);
        if (!threat.is_empty() || any_watch) {
            bc::bitboard blocked = w.static_blocked | threat;
            blocked.set(pos, false);
            bc::bitboard ring = w.altar_ring & ~blocked;
            if (any_watch) ring = ring & ~watched;
            if (!ring.is_empty()) {
                bc::bitboard visited;
                safe_field.compute_to(blocked, ring, single(pos), visited);
                if (fdist(safe_field, pos) != kUnreach) {
                    use_safe = true;
                    dist = fdist(safe_field, pos);
                }
            }
        }
    }
    if (dist == kUnreach) return false;
    const bool wins = ally_score + gems >= static_cast<int>(bc::constants::winning_gems) ||
#if X1_TEAMWIN && X3_ARBITRATION
        (x3_arbiter_enabled() && ally_score+std::max(gems,team_carry)>=static_cast<int>(bc::constants::winning_gems)) ||
#endif
        // Endgame: our bag plus what teammates probably carry finishes the race, so bank it now
        // rather than lose the race with gems in our bags.
        (tune::kEndgameMargin > 0 && gems >= 10 && dist <= 25 &&
            ally_score + gems + tune::kEndgameMargin >= static_cast<int>(bc::constants::winning_gems));
    const bool late = round + dist + gems / 10 + 15 >= static_cast<int>(bc::constants::max_rounds);
    bool threatened = false;
    for (const auto& e : w.enemies) threatened |= cheb(e.pos, pos) <= 6;
    // Endgame banking (APEX_END_BANK, from apex_v19): once either score passes the threshold, unbanked gems may be
    // worth nothing (the race ends at 1,000), so any bag of 10+ goes to an altar within 20 steps.
    const bool end_bank = tune::kEndBank > 0 && gems >= 10 && dist <= 20 &&
        std::max(ally_score, enemy_score) >= tune::kEndBank + static_cast<int>(std::lround(150.0f * LABK(37)));
    // Bank rhythm (APEX_BANK_RATIO): a short trip for the bag we carry is worth taking now.
    const bool rhythm = tune::kBankRatio > 0.0f && gems >= 20 && static_cast<float>(dist) * tune::kBankRatio <= static_cast<float>(gems);
    // NOVA_BANK_FIX: sparse maps bank small bags through the opening (see common.h); big-strip
    // maps keep the carry discipline. Only fires once the draft recorded a known biggest group,
    // while no capture is in progress under our feet, the trip is short, and the road is clear
    // (v2 reshape: the first version lost farm tempo on ambush maps because carriers left
    // captures and strip cycles mid-way).
    bool capturing = false;
    for (const auto& gr : w.groups)
        if (gr.state == GroupState::reward && bit(gr.tiles, pos)) {
            capturing = true;
            break;
        }
    const bool clearish = w.enemies.empty() || use_safe;
    // NOVA_RACE_BANK / NOVA_MONO_BANK (default off): on dense race maps and shared-monolith maps the
    // opening bank also fires when a big strip exists there Ã¢â‚¬â€ bags convert to score, not to carry.
    const bool raceMono = brain::state.ready && ((raceBank && brain::state.race) || (monoBank && brain::state.mono));
    const bool edge = bankFix && gems >= tune::kEdgeBankBag && round <= tune::kEdgeBankUntil && !capturing &&
        clearish && dist <= tune::kEdgeBankDist && brain::state.ready && brain::state.max_group > 0 &&
        (brain::state.max_group < tune::kBigMapGems || raceMono);
    const bool go = force_tribute || wins || late || end_bank || rhythm || edge ||
#if V58_SURVIVE
        survive_bank_due() ||
#endif
        gems >= tune::kTributeCarry ||
        dist <= tune::kTributeNearDist + static_cast<int>(std::lround(2.0f * LABK(36))) || (threatened && gems >= 20 && dist <= 8);
#if A2_ALTARFIX & 2
    if (!go) {
        tribute_stuck = 0;
        tribute_last_dist = -1;
        return false;
    }
#endif
    if (!go) return false;
#if A2_ALTARFIX & 2
    // Stuck carrier: 20 turns on the way without a new closest distance (camps or units hold every way in; jittering
    // back and forth does not count as progress) stops banking for 80 rounds; the bag goes back to farming.
    if (dist > 0 && dist != kUnreach) {
        if (tribute_last_dist < 0 || dist < tribute_last_dist) {
            tribute_last_dist = dist;
            tribute_stuck = 0;
        } else {
            ++tribute_stuck;
        }
        if (tribute_stuck >= 20) {
            tribute_stuck = 0;
            tribute_last_dist = -1;
            tribute_off_until = round + 80;
            return false;
        }
    } else {
        tribute_stuck = 0;
        tribute_last_dist = -1;
    }
#endif
    if (dist == 0) {
        for (vec2 a : w.altars) {
            if (cheb(a, pos) > bc::constants::submit_gems_range) continue;
            if (bc::vision::has_altar_lock(a)) {
                const auto lock = bc::vision::altar_lock_at(a);
                if (lock.is_enemy()) {
                    if (me.can_attack()) {
                        try {
                            me.attack(lock);
                        } catch (...) {
                        }
                    }
                    return true;
                }
            }
            try {
                me.submit_gems(a);
                return true;
            } catch (const std::exception& e) {
                LOG("submit error %s\n", e.what());
            }
        }
        return false;
    }
    bc::bitboard blocked = w.static_blocked | w.unit_tiles;
    blocked.set(pos, false);
    // The static field ignores units: when camps or champions fill every downhill tile, plan around them.
#if A2_ALTARFIX & 4
    const bc::distance_field& walk_field = !use_safe && fdist(w.altar_walk, pos) != kUnreach ? w.altar_walk : (use_safe ? safe_field : w.altar_field);
#else
    const bc::distance_field& walk_field = use_safe ? safe_field : w.altar_field;
#endif
    if (!follow_field(walk_field, blocked, true) && tune::kUnstick && !walk_toward(w.altar_ring))
        break_out();
    return true;
}

// Camps attack the nearest champion within range 3; equal distance goes to the lower unit id.
bool Bot::camp_targets_me(int ci, vec2 at) const {
    const vec2 cp = w.camps[ci].pos;
    const int mine = cheb(cp, at);
    if (mine > w.camps[ci].range) return false;
    for (const auto& a : w.allies) {
        const int da = cheb(cp, a.pos);
        if (da < mine || (da == mine && a.id < my_id)) return false;
    }
    for (const auto& e : w.enemies) {
        const int de = cheb(cp, e.pos);
        if (de < mine || (de == mine && e.id < my_id)) return false;
    }
    return true;
}

float Bot::incoming_from_group(const GroupRec& g, vec2 at) const {
    float dmg = 0;
    for (int ci : g.camps)
        if (!w.camps[ci].dead && w.camps[ci].strength > 0 && camp_targets_me(ci, at)) dmg += w.camps[ci].strength;
    return dmg;
}

// Damage taken per unit of team damage-per-turn while killing the dangerous camps weakest-first
// (soak = coefficient / team_dps). Cached per group per turn: this sat in the hottest loop.
float Bot::soak_coefficient(int gi, float hp_left) {
    // Depends only on the group's camps (health and state), so it is cached across turns and
    // recomputed when the group's remaining health or state changes.
    if (soak_cache.size() != w.groups.size()) {
        soak_cache.assign(w.groups.size(), -1.0f);
        soak_key_hp.assign(w.groups.size(), -1.0f);
        soak_key_state.assign(w.groups.size(), -1);
    }
    const auto& g = w.groups[static_cast<std::size_t>(gi)];
    const int state = static_cast<int>(g.state);
    float& slot_value = soak_cache[static_cast<std::size_t>(gi)];
    if (slot_value < 0 || soak_key_hp[static_cast<std::size_t>(gi)] != hp_left || soak_key_state[static_cast<std::size_t>(gi)] != state) {
        slot_value = group_soak(g, 1.0f);
        soak_key_hp[static_cast<std::size_t>(gi)] = hp_left;
        soak_key_state[static_cast<std::size_t>(gi)] = state;
    }
    return slot_value;
}

// Damage the tanks absorb while the team kills the dangerous camps, weakest first.
float Bot::group_soak(const GroupRec& g, float team_dps) const {
    std::array<std::pair<float, float>, X1_SOAK_N> live{}; // audit B02: 12 dropped members of big groups (02the-pack G0 has 48)
    int n = 0;
    float str_alive = 0;
    for (int ci : g.camps) {
        const auto& c = w.camps[ci];
        if (c.strength <= 0 || n >= X1_SOAK_N) continue;
        if (g.state == GroupState::alive && c.dead) continue;
        const float hp_c = g.state == GroupState::alive ? c.hp : c.max_hp;
        live[n++] = {hp_c, c.strength};
        str_alive += c.strength;
    }
    std::sort(live.begin(), live.begin() + n);
    float soak = 0;
    for (int i = 0; i < n; ++i) {
        soak += str_alive * live[i].first / team_dps;
        str_alive -= live[i].second;
    }
    return soak;
}

int Bot::champions_needed(const GroupRec& g, float hp_left) {
    if (g.harmless || hp_left <= 0) return 1;
    // Camps focus one champion, but tanks can rotate out (camps never chase or heal),
    // so the team's combined health pays for the fight.
    const float dps = my_dps(&g);
    const float coef = soak_coefficient(static_cast<int>(&g - w.groups.data()), hp_left) * camp_taken_mult;
    for (int n = 1; n <= 6; ++n) {
        const float pool = hp * tune::kNeedPool + static_cast<float>(n - 1) * max_hp * 0.7f;
        if (coef / (dps * static_cast<float>(n)) <= pool) return n;
    }
    return 7;
}

int Bot::allies_near_group(const GroupRec& g) const {
    int n = 0;
    for (const auto& a : w.allies) {
        if (a.hp < a.max_hp * 0.35f) continue;
        for (int ci : g.camps)
            if (cheb(a.pos, w.camps[ci].pos) <= 5) {
                ++n;
                break;
            }
    }
    return n;
}

bool Bot::fight_camps(GroupRec& g, int need) {
    auto pick_target = [&]() {
        int best = -1;
        float best_hp = 1e30f;
        for (int ci : g.camps) {
            const auto& c = w.camps[ci];
            if (c.dead || !bit(w.visible, c.pos) || cheb(c.pos, pos) > range) continue;
            // Kill the camps that hurt first, then the weakest.
            float key = c.hp - c.strength * 1000.0f;
            if (type == bc::champion_type::varg) {
                int neighbours = 0;
                for (int o : g.camps)
                    if (o != ci && !w.camps[o].dead && cheb(w.camps[o].pos, c.pos) <= 1) ++neighbours;
                key -= neighbours * 2000.0f;
            }
            if (key < best_hp) {
                best_hp = key;
                best = ci;
            }
        }
        return best;
    };
    // Tiles from which we can hit a live camp, and tiles inside any dangerous camp's reach.
    bc::bitboard attack_zone, danger_zone;
    attack_zone.clear();
    danger_zone.clear();
    for (int ci : g.camps) {
        if (w.camps[ci].dead) continue;
        attack_zone.draw_chebyshev(w.camps[ci].pos, static_cast<float>(range));
        if (w.camps[ci].strength > 0) danger_zone.draw_chebyshev(w.camps[ci].pos, static_cast<float>(w.camps[ci].range));
    }

    PROF_CHECK("c_zones");
    int present = 1 + allies_near_group(g);
#if V54_ONSITE
    if (onsite_ok) {
        // Claimants marked on site count even when a bush or wall hides them from us.
        const int gi = static_cast<int>(&g - &w.groups[0]);
        int on = 1;
        for (int s = 0; s < std::min(team_size, kClaimSlots); ++s)
            if (s != slot && claim_onsite(s) && claim_cache[static_cast<std::size_t>(s)] == gi) ++on;
        present = std::max(present, on);
    }
#endif
    const float incoming = incoming_from_group(g, pos);
    PROF_CHECK("s_inc");
    // Wait outside camp range until enough allies have gathered (unless the fight already started).
    if (need > present && incoming <= 0) {
#if V54_STAGE_ARRIVE
        if (staging_walk_since < 0) staging_walk_since = round; // staging_since starts on arrival (below)
#else
        if (staging_since < 0) staging_since = round;
#endif
        mode = "stage";
        const bool sieging = tune::kSiege && !in_role_pack && siege_dps(g) > 0.0f;
        PROF_CHECK("s_dps");
        if (sieging) {
            mode = "siege";
            bc::bitboard ring;
            ring.clear();
            for (int ci : g.camps)
                if (!w.camps[ci].dead) ring.draw_chebyshev(w.camps[ci].pos, static_cast<float>(w.camps[ci].range + 1));
            PROF_CHECK("sg_ring");
#if X1_FAST_SIEGE
            // X1_FAST_SIEGE (telemetry: the siege line-of-sight scan caused most fuel suspensions on 02the-pack and
            // 02gift-wrapping; a tiles x camps x steps loop exceeds a turn's fuel on big wolf groups). Camps and walls/
            // bushes never move, so each camp's set of tiles within 4 with a clear line is computed once (lazily, a
            // few camps per turn) as a bitboard; each turn is then ring & union(alive camps' sets): the same tiles as
            // NOVA_SIEGE_LOS's per-turn scan, then the same danger mask and fallback.
            if (NOVA_SIEGE_LOS) {
                static std::vector<bc::bitboard> los;
                static std::vector<std::uint8_t> los_ready;
                static std::vector<std::uint8_t> opq;
                static int opq_w = 0, opq_h = 0;
                if (opq.empty()) {
                    opq_w = bc::map::width(); opq_h = bc::map::height();
                    opq.assign(static_cast<std::size_t>(opq_w * opq_h), 0);
                    const bc::bitboard opaque = bc::map::walls() | w.bushes;
                    for (vec2 o : opaque.positions()) opq[static_cast<std::size_t>(o.y * opq_w + o.x)] = 1;
                }
                if (los.size() < w.camps.size()) { los.resize(w.camps.size()); los_ready.resize(w.camps.size(), 0); }
                PROF_CHECK("sg_init");
                auto opaque_at = [&](vec2 m) { return m.x < 0 || m.y < 0 || m.x >= opq_w || m.y >= opq_h || opq[static_cast<std::size_t>(m.y * opq_w + m.x)]; };
                bc::bitboard any;
                any.clear();
                bool complete = true;
                for (int ci : g.camps) {
                    const auto& c = w.camps[ci];
                    if (c.dead) continue;
                    if (!los_ready[static_cast<std::size_t>(ci)]) {
                        // X1_SIEGEFUEL: a camp's scan costs ~20k; start one only with room for it and the turn's walk after.
                        if (bc::fuel_remaining() < (X1_SIEGEFUEL ? static_cast<std::uint64_t>(X1_SIEGEFUEL) * 1000 : 30000)) { complete = false; continue; }
                        bc::bitboard v;
                        v.clear();
                        for (int dy = -4; dy <= 4; ++dy) for (int dx = -4; dx <= 4; ++dx) {
                            const vec2 q{c.pos.x + dx, c.pos.y + dy};
                            if (q.x < 0 || q.y < 0 || q.x >= opq_w || q.y >= opq_h) continue;
                            const int n = cheb(c.pos, q);
                            bool clear = true;
                            for (int k = 1; k < n && clear; ++k) {
                                const vec2 m{q.x + ((c.pos.x - q.x) * k * 2 + (c.pos.x >= q.x ? n : -n)) / (2 * n),
                                    q.y + ((c.pos.y - q.y) * k * 2 + (c.pos.y >= q.y ? n : -n)) / (2 * n)};
                                clear = !opaque_at(m);
                            }
#if X1_SIEGEFUEL
                            if (clear) set_bit(v, q);
#else
                            if (clear) v.set(q, true);
#endif
                        }
                        los[static_cast<std::size_t>(ci)] = v;
                        los_ready[static_cast<std::size_t>(ci)] = 1;
                    }
                    any |= los[static_cast<std::size_t>(ci)];
                }
                PROF_CHECK("sg_los");
                ring &= ~danger_zone & ~w.static_blocked;
                bc::bitboard seeing = ring & any;
                if (!seeing.is_empty() && (complete || !X1_SIEGE_STRICT)) ring = seeing; // a partial union keeps only tiles that see a live camp (audit B04)
            }
            if (false) {
#else
            ring &= ~danger_zone & ~w.static_blocked;
            if (NOVA_SIEGE_LOS) {
#endif
                // Spells need the camp in view: on contest the ring tile behind a wall row saw nothing and
                // champions "sieged" a monolith for 1,500 turns without one cast. Keep tiles with a clear
                // straight line (no wall, no foreign bush) to a live camp.
                bc::bitboard seeing;
                seeing.clear();
                const bc::bitboard opaque = bc::map::walls() | w.bushes;
                for (vec2 q : ring.positions()) {
                    for (int ci : g.camps) {
                        const auto& c = w.camps[ci];
                        if (c.dead || cheb(c.pos, q) > 4) continue;
                        bool clear = true;
                        const int n = cheb(c.pos, q);
                        for (int k = 1; k < n && clear; ++k) {
                            const vec2 m{q.x + ((c.pos.x - q.x) * k * 2 + (c.pos.x >= q.x ? n : -n)) / (2 * n),
                                q.y + ((c.pos.y - q.y) * k * 2 + (c.pos.y >= q.y ? n : -n)) / (2 * n)};
                            clear = !bit(opaque, m);
                        }
                        if (clear) {
                            seeing.set(q, true);
                            break;
                        }
                    }
                }
                if (!seeing.is_empty()) ring = seeing;
            }
            PROF_CHECK("sg_seeing");
            if (!bit(ring, pos)) walk_toward(ring);
            // Hit the camp that hurts most first (AoE picks its own best tile in cast_on_camp).
            int best = -1;
            for (int ci : g.camps) {
                const auto& c = w.camps[ci];
                if (c.dead || !bit(w.visible, c.pos) || cheb(c.pos, pos) > 4) continue;
                if (best < 0 || c.strength > w.camps[best].strength ||
                    (c.strength == w.camps[best].strength && c.hp < w.camps[best].hp))
                    best = ci;
            }
            if (best >= 0) cast_on_camp(best);
            return true;
        }
#if V54_STAGE_ARRIVE
        bc::bitboard stage;
        stage.clear();
        for (int ci : g.camps)
            if (!w.camps[ci].dead) stage.draw_chebyshev(w.camps[ci].pos, 5.0f);
        stage &= ~danger_zone;
        PROF_CHECK("s_stage");
        // The helpers' wait starts when we reach the staging ring. Counting the walk there made every job farther
        // than the timeout fail before anyone arrived (concentrated-wealth: all five champions gave up the centre
        // group at round 8, 40 tiles out, and it was then avoided for 60 rounds, 38 times by round 500).
        if (staging_since < 0 && bit(stage, pos)) staging_since = round;
        // Only a call teammates have answered (enough claimants) earns the walk and the longer wait; an unanswered
        // call still lapses tune::kStageTimeout turns after it was made, as before.
        const bool answered = claim_count(static_cast<int>(&g - &w.groups[0])) + 1 >= need;
        int stage_wait = tune::kStageTimeout;
#if V54_ONSITE
        if (bit(stage, pos)) mark_onsite(static_cast<int>(&g - &w.groups[0]));
        if (onsite_ok && answered) stage_wait = V54_STAGE_HELPED;
#endif
        const bool waited_out = staging_since >= 0 && round - staging_since > stage_wait;
        if (waited_out || round - staging_walk_since > (answered ? V54_STAGE_WALK : tune::kStageTimeout)) {
            avoid_until[target_group] = round + 60;
            staging_since = -1;
            staging_walk_since = -1;
            if (tune::kCallCooldown > 0) call_ban_until = round + tune::kCallCooldown;
            return false;
        }
#else
        if (round - staging_since > tune::kStageTimeout) {
            avoid_until[target_group] = round + 60;
            staging_since = -1;
            if (tune::kCallCooldown > 0) call_ban_until = round + tune::kCallCooldown;
            return false;
        }
        bc::bitboard stage;
        stage.clear();
        for (int ci : g.camps)
            if (!w.camps[ci].dead) stage.draw_chebyshev(w.camps[ci].pos, 5.0f);
        stage &= ~danger_zone;
#endif
        if (!bit(stage, pos)) walk_toward(stage);
        // Spells reach 4 tiles, one more than camps: chip damage for free while we wait.
        for (int ci : g.camps)
            if (!w.camps[ci].dead && bit(w.visible, w.camps[ci].pos) && cast_on_camp(ci)) break;
        return true;
    }
    PROF_CHECK("c_staged");
    staging_since = -1;
    staging_walk_since = -1;
#if V54_ONSITE
    if (need >= 2) mark_onsite(static_cast<int>(&g - &w.groups[0])); // helpers arriving now count us
#endif

    const float hp_left = g.hp_left(w.camps);
    const float team_dps = my_dps(&g) * static_cast<float>(present);
#if V58_DIRECTOR && V58_ROUTE && V58_PRECAP
    if (economy_precapture(g, hp_left)) {
        const int ready_target = pick_target();
        if (ready_target >= 0) use_reset_and_attack(w.camps[ready_target].camp, w.camps[ready_target].pos);
        return true;
    }
#endif
    // NOVA_CAMP_SAFE = K: every camp in reach may switch to us next round (the tank in front of us can
    // step away later this round: Cassi kept hitting elks at 160 health because Issac stood closer,
    // then Issac disengaged and both died). Leave their reach while K x that damage would kill us.
    // Counted: this group's camps and those of any other group already awake (damaged or part-killed):
    // splash and area spells wake diagonal neighbours, which are separate groups (four elks hit Ryth
    // while it fought a one-elk group).
    struct NearCamp {
        vec2 p;
        float s;
        int r;
    };
    std::array<NearCamp, 32> near_camps{};
    int n_near = 0;
    if (NOVA_CAMP_SAFE > 0.0f)
        for (const auto& g2 : w.groups) {
            if (g2.state != GroupState::alive || g2.harmless) continue;
            bool awake = &g2 == &g;
            for (int ci : g2.camps)
                if (!awake && (w.camps[ci].dead || w.camps[ci].hp < w.camps[ci].max_hp)) awake = true;
            if (!awake) continue;
            for (int ci : g2.camps) {
                const auto& c = w.camps[ci];
                if (c.dead || c.strength <= 0 || cheb(c.pos, pos) > c.range + 2 || n_near >= 32) continue;
                near_camps[n_near++] = {c.pos, c.strength, c.range};
            }
        }
    auto worst_at = [&](vec2 q) {
        float s = 0.0f;
        for (int i = 0; i < n_near; ++i)
            if (cheb(near_camps[i].p, q) <= near_camps[i].r) s += near_camps[i].s;
        return s * camp_taken_mult;
    };
    const bool doomed = NOVA_CAMP_SAFE > 0.0f && worst_at(pos) * NOVA_CAMP_SAFE >= hp;
    // Tank rotation: when the camps are focused on us and we are low, step to a tile they do not
    // target (an ally closer to them takes over); if none is adjacent, leave their reach.
    if ((incoming > 0 && hp < incoming * 3.0f + max_hp * 0.1f && hp_left > team_dps * 1.5f) || doomed) {
        mode = "disengage";
        const int t = pick_target();
        if (t >= 0 && melee) attack_unit(w.camps[t].camp, w.camps[t].pos);
        auto& me = bc::self();
        vec2 best = pos;
        int best_score = -1000000;
        for (vec2 dir : kDirs) {
            const vec2 q = pos + dir;
            if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
            if (incoming_from_group(g, q) > 0) continue;
            if (doomed && worst_at(q) * NOVA_CAMP_SAFE >= hp) continue;
            int sc = bit(attack_zone, q) ? 100 : 0;
            sc -= static_cast<int>(fdist(w.spawn_field, q));
            if (sc > best_score) {
                best_score = sc;
                best = q;
            }
        }
        bool moved = false;
        if (best != pos && me.can_move()) {
            try {
                moved = me.move_absolute(best);
                if (moved) {
                    pos = best;
                    walked = true;
                }
            } catch (...) {
            }
        }
        if (!moved) walk_toward(~danger_zone & ~w.static_blocked);
        if (hp < max_hp * 0.45f) heading_home = true;
        if (!melee && !walked) {
            const int t2 = pick_target();
            if (t2 >= 0) attack_unit(w.camps[t2].camp, w.camps[t2].pos);
        }
        return true;
    }

    PROF_CHECK("c_safe");
    int t = pick_target();
    mode = "fight";
    if (t < 0 && NOVA_BUSH_WARD && reveal_bush_camp(g)) t = pick_target();
    if (t < 0 && std::string_view(mode) == "bush-ward") return true;
    if (t < 0) {
#if V58_ACT & 1
        if (act_camp_before_walk(g)) return true;
#endif
        mode = "approach";
#if A2_APPROACHFIX
        {
            // Approach stall: 25 turns on one group without a new closest distance (straight-line targets across
            // holes before their field exists, or a way in that units keep blocked) drops the group for 100 rounds.
            const int gi = static_cast<int>(&g - &w.groups[0]);
            if (A2_APPROACHFIX < 2 && !w.value_cut_off()) goto approach_done; // 1: only where walking leaves value out of reach
            int d = 1 << 20;
            for (int ci : g.camps) d = std::min(d, cheb(w.camps[ci].pos, pos));
            if (gi != approach_group || d < approach_best) {
                approach_group = gi;
                approach_best = d;
                approach_stuck = 0;
            } else if (++approach_stuck >= 25) {
                approach_stuck = 0;
                approach_group = -1;
                if (static_cast<std::size_t>(gi) < avoid_until.size()) avoid_until[static_cast<std::size_t>(gi)] = round + 100;
                return false;
            }
        }
    approach_done:;
#endif
        // Ranged champions stand at full range so a melee ally (closer) draws the camps' fire.
        bc::bitboard goal = attack_zone;
        if (!melee) {
            bc::bitboard inner;
            inner.clear();
            for (int ci : g.camps)
                if (!w.camps[ci].dead) inner.draw_chebyshev(w.camps[ci].pos, static_cast<float>(range - 1));
            const bc::bitboard ring = attack_zone & ~inner & ~w.static_blocked & ~w.unit_tiles;
            if (!ring.is_empty()) goal = ring;
        }
        if (!walk_toward(goal) && !bit(goal, pos)) {
            if (walk_unreachable) {
                // No attack position is reachable over static terrain: drop the group (see to-capture).
                const auto gi = static_cast<std::size_t>(&g - &w.groups[0]);
                if (gi < avoid_until.size()) avoid_until[gi] = round + 300;
                return false;
            }
            PROF_CHECK("c_brk0"); if (break_out()) return true;
        }
        PROF_CHECK("c_walked"); if (!melee) {
#if V58_ACT & 12
            const int after_walk = X1_WALKTAIL && bc::fuel_remaining() < X1_WALKTAIL * 1000ull ? -1 : pick_target(); PROF_CHECK("c_pick1");
            if (after_walk >= 0) {
#if V58_ACT & 8
                const bool basic = attack_unit(w.camps[after_walk].camp, w.camps[after_walk].pos);
#else
                constexpr bool basic = false;
#endif
#if V58_ACT & 4
                if (!basic) use_reset_and_attack(w.camps[after_walk].camp, w.camps[after_walk].pos);
#else
                (void)basic;
#endif
            }
#endif
            return true; // a compatible reset can restore the attack spent walking
        }
        if (X1_WALKTAIL && bc::fuel_remaining() < X1_WALKTAIL * 1000ull) return true; t = pick_target(); PROF_CHECK("c_pick2");
        if (t < 0) return true;
    }
#if V55_CAST_RETARGET
    PROF_CHECK("c_approach");
    if (cast_on_camp(t)) {
        // A spell may have killed the chosen target (or several nearby targets). Preserve the basic attack.
        for (int retry = 0; retry < 4 && t >= 0; ++retry) {
            d::camp_state fresh{};
            const int code = d::sdk_camp(static_cast<std::uint32_t>(static_cast<bc::handle_camp_t>(w.camps[t].camp)), &fresh);
            if (code == 0 && fresh.health > 0.0f) {
                w.camps[t].hp = fresh.health;
                break;
            }
            w.camps[t].dead = true;
            t = pick_target();
        }
        if (t < 0) return true;
    }
#else
    cast_on_camp(t);
#endif
    PROF_CHECK("c_cast"); if (attack_unit(w.camps[t].camp, w.camps[t].pos)) {
        // Refresh the target in case the first hit killed it.
        d::camp_state cs{};
        const int code = d::sdk_camp(static_cast<std::uint32_t>(static_cast<bc::handle_camp_t>(w.camps[t].camp)), &cs);
        if (code != 0 || cs.health <= 0) {
            w.camps[t].dead = true;
            t = pick_target();
        }
        if (t >= 0) use_reset_and_attack(w.camps[t].camp, w.camps[t].pos);
    }
    return true;
}

// NOVA_UNBOX: live units, not terrain, block every route to where we are going (typically camps that
// respawned around us after a capture: champions sat boxed in with full bags for the rest of the
// game). With no enemy in view, hit the camp in reach that is cheapest to clear, harmless first.
bool Bot::break_out() {
    if (!NOVA_UNBOX || !walk_boxed || walked || !w.enemies.empty()) return false;
    int best = -1;
    float best_key = 1e30f;
    for (std::size_t ci = 0; ci < w.camps.size(); ++ci) {
        const auto& c = w.camps[ci];
        if (c.dead || !bit(w.visible, c.pos) || cheb(c.pos, pos) > range) continue;
        const int gi = w.camp_group[ci];
        if (gi < 0 || w.groups[static_cast<std::size_t>(gi)].state != GroupState::alive) continue;
        const float key = c.strength * 1000.0f + c.hp;
        if (key < best_key) {
            best_key = key;
            best = static_cast<int>(ci);
        }
    }
    if (best < 0) return false;
    mode = "break-out";
    cast_on_camp(best);
    attack_unit(w.camps[static_cast<std::size_t>(best)].camp, w.camps[static_cast<std::size_t>(best)].pos);
    return true;
}

// NOVA_BUSH_WARD: no live camp of the group is in view, yet one stands within our attack range (on a
// bush tile, or behind a corner): we would wait beside it forever. Step within ward range and put the
// ward on its tile. True when the ward went down (look again); mode "bush-ward" while walking or
// waiting for the ward to recharge.
bool Bot::reveal_bush_camp(const GroupRec& g) {
    // (Live camps in view but out of reach do not help: the approach goal also counts this camp's
    // attack zone, so we would stand here anyway.)
    int hidden = -1, hd = 1 << 20;
    for (int ci : g.camps) {
        const auto& c = w.camps[ci];
        if (c.dead || bit(w.visible, c.pos)) continue;
        const int d = cheb(c.pos, pos);
        if (d < hd) {
            hd = d;
            hidden = ci;
        }
    }
    if (hidden < 0 || hd > range) return false;
    const vec2 at = w.camps[hidden].pos;
    mode = "bush-ward";
    const int reach = std::min(range, 2); // ward range 2; melee must stand next to it to attack
    if (hd > reach) {
        bc::bitboard goal;
        goal.clear();
        goal.draw_chebyshev(at, static_cast<float>(reach));
        goal &= ~w.static_blocked;
        walk_toward(goal);
        hd = cheb(at, pos);
    }
    if (hd > 2) return false;
    auto& me = bc::self();
    try {
        if (me.ward_cooldown() > 0) return false;
        // False means a hidden obstruction (typically an ally's ward already on the tile): the engine
        // then reveals the tile to us for the rest of the round, which is all an attack needs.
        if (me.place_ward(at)) ward_pos = at;
        w.update(round);
        return bit(w.visible, at);
    } catch (const std::exception& e) {
        LOG("bush ward error %s\n", e.what());
    }
    return false;
}

// Spell damage per turn we can deal to this group from 4 tiles, outside every camp's reach (range 3).
float Bot::siege_dps(const GroupRec& g) const {
    int live = 0, reach = 0;
    for (int ci : g.camps)
        if (!w.camps[ci].dead) {
            ++live;
            reach = std::max(reach, w.camps[ci].range);
        }
    float dps = 0;
    for (const auto& sp : spells) {
        // Only spells that outrange every live camp siege for free.
        if (!sp.present || !sp.camps || sp.range < static_cast<float>(reach + 1)) continue;
        if (sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc)
            dps += sp.modifier * focus / 8.0f;
        else if (sp.kind == bc::ability_kind::aoe_damage)
            dps += sp.modifier * focus * static_cast<float>(std::min(live, 3)) / 8.0f;
    }
    return dps;
}

int Bot::claim_of(int s) const { return claim_cache[static_cast<std::size_t>(s)]; }

bool Bot::group_capture_covered(const GroupRec& g) const {
    if (g.state != GroupState::reward) return false;
#if V58_DIRECTOR && V58_ROUTE
    if (economy_enabled() && (static_cast<int>(&g - w.groups.data()) == ec_job || static_cast<int>(&g - w.groups.data()) == ec_capture)) {
        if (economy_carry() == slot) return false;
        if (economy_carry_on(g)) return true;
    }
#endif
    const float mine = tune::kShareGold ? my_items() : 0.0f;
    for (const auto& a : w.allies) {
        if (!bit(g.tiles, a.pos)) continue;
        // A clearly richer ally on the region does not cover it: we take over and it hands over.
        if (tune::kShareGold && items_of(a.type, a.max_hp, a.strength, a.focus) > mine + static_cast<float>(tune::kShareGold))
            continue;
        return true;
    }
    return false;
}

float Bot::my_items() const { return items_of(type, max_hp, strength, focus); }

// A clearly poorer ally will take this finished group's reward: it stands on the region, or (unless
// on_tile_only) it claims the group and stands within 2 tiles of it.
bool Bot::poorer_ally_takes(const GroupRec& g, int gi, bool on_tile_only) const {
#if V58_DIRECTOR && V58_ROUTE
    if (economy_enabled() && (gi == ec_job || gi == ec_capture)) {
        if (economy_carry() == slot) return false;
        // A handoff requires the carry already on the region: never leave an unoccupied reward waiting for it.
        return economy_carry_on(g);
    }
#endif
    const float mine = my_items();
#if UB_GOLD_FUNNEL
    // Gold funnel (top teams' Vesper earns 42% of her team's gold): Vesper gains 33% more from every gold gain, so
    // she keeps the rewards she is on, and allies hand theirs to her instead of to the poorest teammate.
    if (type == bc::champion_type::vesper_vale) return false;
#endif
    for (const auto& a : w.allies) {
        const bool funnel = UB_GOLD_FUNNEL && a.type == bc::champion_type::vesper_vale;
        if (!funnel && items_of(a.type, a.max_hp, a.strength, a.focus) + static_cast<float>(tune::kShareGold) >= mine) continue;
        if (bit(g.tiles, a.pos)) return true;
        if (on_tile_only) continue;
        int s = -1;
        for (int k = 0; k < std::min(team_size, kClaimSlots); ++k)
            if (ally_handle[static_cast<std::size_t>(k)] == a.id) s = k;
        if (s < 0 || claim_of(s) != gi) continue;
        for (int ci : g.camps)
            if (cheb(a.pos, w.camps[ci].pos) <= 2) return true;
    }
    return false;
}

// A3_ONE_OWNER: one owner per finished group. Rewards split among every ally on the region when the capture lands,
// so a second body standing there only spends its capture turns on a share of the same reward. Every ally on the region
// computes the same owner (poorest by items, then lowest id) from what it sees; the others leave for their next job.
bool Bot::a3_other_owner(const GroupRec& g) const {
    const float mine = my_items();
    float best_items = mine;
    std::uint32_t best_id = my_id;
    bool other = false;
    for (const auto& a : w.allies) {
        if (!bit(g.tiles, a.pos) || a.hp < 0.35f * a.max_hp) continue;
        const float it = items_of(a.type, a.max_hp, a.strength, a.focus);
        if (it < best_items - 0.01f || (std::fabs(it - best_items) <= 0.01f && a.id < best_id)) {
            best_items = it;
            best_id = a.id;
        }
        other = true;
    }
    return other && best_id != my_id;
}

// Territories (A2_ZONES, commander v1). Walking and waiting beside respawning camps take 45% of our champions' turns
// (fighting camps 21%), so each champion gets a compact share of the map to farm in a cycle. Every champion splits the
// camp groups the same way from static data, so no messages are needed: sectors fanning out from our spawn, starting
// behind it (away from the enemy spawn), cut so each sector's camps pay about the same per respawn cycle. A2_ZONES 1:
// one sector per champion slot; 2: one per pair of slots (safety in numbers). score_groups discounts other sectors.
void Bot::build_zones() {
    zone_of.assign(w.groups.size(), -1);
    const int members = A2_ZONES == 2 ? 2 : 1;
    const int sectors = std::max(1, (team_size + members - 1) / members);
    my_zone = std::min(slot / members, sectors - 1);
    float cx = 0, cy = 0, ex = 0, ey = 0;
    int n = 0, m = 0;
    for (vec2 p : w.spawn_tiles) cx += static_cast<float>(p.x), cy += static_cast<float>(p.y), ++n;
    for (vec2 p : w.enemy_spawn.positions()) ex += static_cast<float>(p.x), ey += static_cast<float>(p.y), ++m;
    if (n == 0 || m == 0) return;
    cx /= static_cast<float>(n), cy /= static_cast<float>(n), ex /= static_cast<float>(m), ey /= static_cast<float>(m);
    const float back = std::atan2(cy - ey, cx - ex);
    struct Entry {
        float angle, rate;
        int gi;
    };
    std::vector<Entry> entries;
    float total = 0;
    for (std::size_t gi = 0; gi < w.groups.size(); ++gi) {
        const auto& g = w.groups[gi];
        const float value = static_cast<float>(g.gems) + gold_weight() * static_cast<float>(g.gold);
        if (value <= 0.0f || g.camps.empty()) continue;
        float gx = 0, gy = 0;
        for (int ci : g.camps) gx += static_cast<float>(w.camps[ci].pos.x), gy += static_cast<float>(w.camps[ci].pos.y);
        gx /= static_cast<float>(g.camps.size()), gy /= static_cast<float>(g.camps.size());
        float a = std::atan2(gy - cy, gx - cx) - back;
        while (a < 0) a += 6.2831853f;
        while (a >= 6.2831853f) a -= 6.2831853f;
        const float rate = value / static_cast<float>(std::max(g.respawn, 40));
        entries.push_back({a, rate, static_cast<int>(gi)});
        total += rate;
    }
    std::sort(entries.begin(), entries.end(), [](const Entry& p, const Entry& q) { return p.angle < q.angle || (p.angle == q.angle && p.gi < q.gi); });
    // Each sector's share of the total is its number of champions (the last one may be short of a pair).
    int sec = 0;
    float acc = 0, bound = total * static_cast<float>(std::min(members, team_size)) / static_cast<float>(team_size);
    for (const auto& e : entries) {
        zone_of[static_cast<std::size_t>(e.gi)] = static_cast<std::int8_t>(sec);
        acc += e.rate;
        if (sec < sectors - 1 && acc >= bound) {
            ++sec;
            bound += total * static_cast<float>(std::min(members, team_size - sec * members)) / static_cast<float>(team_size);
        }
    }
}

#if A2_CAMPNET
// Camp policy net (agent2/lab/cn_rl.js, on-policy RL in the engine lab): among the top kCnK candidates by the bot's
// own score, logit = A2_CN_SHARP x log(score / best) + A2_CN_BASE for the bot's pick + MLP(features). With zero
// weights it reproduces the bot's choice exactly; lab builds sample (cn_cfg mode 1) and log every decision.
int Bot::campnet_pick(CnCand* cn, int n, int base, int& best_need, float& best_score) {
    // Keep the original scorer when the turn cannot afford neural inference.
    if (bc::fuel_remaining() < static_cast<std::uint64_t>(tune::kDetSafety) + 18000) return base;
    const int mode = ngp::training() ? 1 : 0;
    // Keep the kCnK best by score, the bot's pick first.
    std::sort(cn, cn + n, [&](const CnCand& a, const CnCand& b) { return (a.gi == base) != (b.gi == base) ? a.gi == base : a.score > b.score; });
    n = std::min(n, lab_cn::kK);
#if V55_COMMIT_EVENT
    // A capture completes the mission. The learned pick's 40-round lock must not survive it into a respawn wait.
    if (cn_commit >= 0 && w.groups[static_cast<std::size_t>(cn_commit)].state == GroupState::respawning) {
        cn_commit = -1;
        cn_last_base = -1;
    }
#endif
    // A committed pick (an earlier sample) stands while it is still a candidate and fresh: no resampling every turn.
    if (cn_commit >= 0 && round - cn_commit_round <= 40)
        for (int k = 0; k < n; ++k)
            if (cn[k].gi == cn_commit) {
                best_need = cn[k].need;
                best_score = cn[k].score;
                return cn_commit;
            }
    cn_commit = -1;
#if A2_LAB
    // Paired branching: the forced slot's first camp decision at or after the forced round takes the forced candidate.
    const bool forced = lab::cn_force[0] == slot && lab::cn_force[3] == 0 && round >= lab::cn_force[1];
    if (!forced && base == cn_last_base) return base;
#else
    if (base == cn_last_base) return base;
#endif
    cn_last_base = base;
    const float top = cn[0].score; // the bot's own pick
    float logit[lab_cn::kK], mx = -1e30f;
    for (int k = 0; k < n; ++k) {
        float* f = cn[k].f;
        f[0] = std::min(0.0f, std::log(std::max(cn[k].score, 1e-9f) / std::max(top, 1e-9f)));
        f[lab_cn::kF - 1] = k == 0 ? 1.0f : 0.0f;
        const float out = ngp::residual(f);
        logit[k] = A2_CN_SHARP * f[0] + (k == 0 ? A2_CN_BASE : 0.0f) + out;
        mx = std::max(mx, logit[k]);
    }
    float z = 0.0f, p[lab_cn::kK];
    for (int k = 0; k < n; ++k) z += p[k] = std::exp(logit[k] - mx);
    int pick = 0;
#if A2_LAB
    if (forced) {
        lab::cn_force[3] = 1;
        pick = std::min(lab::cn_force[2], n - 1);
        if (lab::cn_force[2] >= n) lab::cn_force[3] = 2; // not enough candidates: the branch is void
    } else
#endif
    if (mode == 1) {
        float u = ngp::uniform(slot) * z;
        while (pick < n - 1 && (u -= p[pick]) > 0.0f) ++pick;
    } else {
        for (int k = 1; k < n; ++k)
            if (logit[k] > logit[pick]) pick = k;
    }
#if A2_LAB
    if (lab::cn_cfg[2] < lab::kCnLogMax) {
        float* e = lab::cn_log + static_cast<std::size_t>(lab::cn_cfg[2]++) * lab::kCnEntry;
        e[0] = static_cast<float>(n), e[1] = static_cast<float>(pick), e[2] = std::log(p[pick] / z), e[3] = static_cast<float>(round), e[4] = forced ? 1.0f : 0.0f;
        for (int k = 0; k < lab::kCnK; ++k)
            for (int i = 0; i < lab::kCnF; ++i) e[5 + k * lab::kCnF + i] = k < n ? cn[k].f[i] : 0.0f;
    }
#endif
#if A2_LAB
    cn_commit = pick != 0 || forced ? cn[pick].gi : -1; // off-base samples (and forced picks) stand for up to 40 rounds
#else
    cn_commit = pick != 0 ? cn[pick].gi : -1; // off-base samples stand for up to 40 rounds
#endif
    if (ngp::training()) {
        float obs[8 * 18] = {};
        for (int k = 0; k < n; ++k)
            for (int i = 0; i < 18; ++i) obs[k * 18 + i] = cn[k].f[i];
        ngp::trace(my_id, round, n, pick, std::log(p[pick] / z), obs);
    }
    cn_commit_round = round;
    best_need = cn[pick].need;
    best_score = cn[pick].score;
    return cn[pick].gi;
}
#endif

int Bot::score_groups(int participants_hint, int& best_need, float& best_score) {
#if A2_CAMPNET
    CnCand cn[kCnMax];
    int n_cn = 0;
#endif
    PROF(score);
    PROF_CHECK("score0");
#if V58_DIRECTOR
    if (const int assignment = economy_assignment(best_need, best_score); assignment >= 0) return assignment;
#endif
#if A2_SOLE_GEM
    // Sole gem camp (stampede: one 20-monster group holds every gem). Winners farm gold until mid-game, then the whole
    // team clears it again and again; our job calls never filled and it was never attacked. One check per call, never
    // inside the group loop (hot-path instructions cost games: the bot runs at its fuel limit).
    if (sole_gem_group == -2) {
        sole_gem_group = -1;
        float total = 0.0f;
        for (const auto& g2 : w.groups) total += static_cast<float>(g2.gems);
        for (std::size_t k = 0; k < w.groups.size(); ++k)
            if (total > 0.0f && static_cast<float>(w.groups[k].gems) >= 0.9f * total) sole_gem_group = static_cast<int>(k);
    }
    if (sole_gem_group >= 0 && round >= A2_SOLE_FROM && hp >= max_hp * 0.6f && gems < tune::kTributeCarry) {
        best_need = team_size;
        best_score = 1e9f;
        return sole_gem_group;
    }
#endif
#if A2_GATE_JOB
    // Gated altars (boss-battle: every altar access tile holds a monolith camp, banking opens only while it is dead).
    // Carriers held 170-570 gems all game and never banked; top teams bank from round ~650. While the gate is shut,
    // healthy champions take the gate group as a whole-team job. Once per call, like A2_SOLE_GEM.
    if (w.no_bank && w.altar_gated && round >= A2_GATE_FROM && hp >= max_hp * 0.6f)
        for (int ci : w.gate_camps) {
            const int gg = w.camp_group[static_cast<std::size_t>(ci)];
            if (gg >= 0 && w.groups[static_cast<std::size_t>(gg)].state == GroupState::alive) {
                best_need = team_size;
                best_score = 1e9f;
                return gg;
            }
        }
#endif
    const float dps = my_dps(nullptr);
    int best = -1;
    best_need = 1;
    best_score = 0;
    // Visit groups nearest-first and stop scoring a group as soon as even a free kill could not beat
    // the best score so far (branch and bound): most groups are pruned after one distance lookup.
    // Buffers are left uninitialised on purpose: filling memory costs 1 fuel per byte.
    constexpr int kMaxOrder = 256;
    struct Entry {
        int first, second;
    };
    Entry order[kMaxOrder]; // trivial type: no per-element construction cost
    int n_order = 0;
    {
    PROF(s_order);
    // Distances: one tile index for our position, then one load per group from its static field.
    const std::size_t here_idx = field_index(pos);
    const bool have_ptrs = w.field_ptr.size() == w.groups.size();
    // Visit groups in last turn's distance order: we move a step or two per turn, so the list is
    // nearly sorted and an insertion sort is close to free (the old counting sort cost ~4k fuel).
    if (group_order.size() != w.groups.size()) {
        group_order.resize(w.groups.size());
        for (std::size_t gi = 0; gi < w.groups.size(); ++gi) group_order[gi] = static_cast<int>(gi);
    }
    for (int gi : group_order) {
        if (n_order >= kMaxOrder) break;
        if (avoid_until[static_cast<std::size_t>(gi)] > round) continue;
        int dist = kUnreach;
        const std::uint16_t* f = have_ptrs ? w.field_ptr[static_cast<std::size_t>(gi)] : nullptr;
        if (f)
            dist = f[here_idx];
        else
            // Field not built yet (first turns only): straight-line distance is a lower bound.
            for (int ci : w.groups[static_cast<std::size_t>(gi)].camps) dist = std::min<int>(dist, cheb(w.camps[ci].pos, pos));
        if (dist == kUnreach) continue;
        int i = n_order++;
        for (; i > 0 && order[i - 1].first > dist; --i) order[i] = order[i - 1];
        order[i] = {dist, gi};
    }
    // Remember the order for next turn (groups skipped this turn keep their place at the end).
    {
        int k = 0;
        for (int i = 0; i < n_order; ++i) group_order[static_cast<std::size_t>(k++)] = order[i].second;
        if (k < static_cast<int>(group_order.size())) {
            // Append the groups not visited this turn, in their old relative order.
            std::vector<char>& seen = order_seen;
            seen.assign(w.groups.size(), 0);
            for (int i = 0; i < n_order; ++i) seen[static_cast<std::size_t>(order[i].second)] = 1;
            for (std::size_t gi = 0; gi < w.groups.size(); ++gi)
                if (!seen[gi]) group_order[static_cast<std::size_t>(k++)] = static_cast<int>(gi);
        }
    }
    }
    // Score the current target first: its (sticky) score is a strong bound.
    for (int oi = 1; oi < n_order; ++oi)
        if (order[oi].second == target_group) {
            std::swap(order[0], order[oi]);
            break;
        }
    // Route search keeps the K best first targets (pruning against the K-th best score).
#if X3_TEAM >= 12
    // Evaluate the proposed job before branch-and-bound can prune it. All normal
    // feasibility, risk, health, ownership and territory checks still apply.
    for (int oi=1;oi<n_order;++oi) if (order[oi].second==x3_proposal) {
        std::swap(order[0],order[oi]);break;
    }
#endif
    const int keep = tune::kRouteDepth >= 2 ? std::clamp(tune::kRouteK, 1, 8) : 1;
    RouteCand top[8];
    int n_top = 0;
    // With the route search, groups within kRouteSlack of the best single score stay candidates.
    auto prune_bound = [&] {
        if (keep == 1) return best_score;
        const float kth = n_top < keep ? 0.0f : top[n_top - 1].score;
        return std::max(kth, best_score * tune::kRouteSlack);
    };
    if (NOVA_BIGJOB > 0.0f && big_group.size() != w.groups.size()) {
        // Static per map: total gems over all groups, and which groups hold a dominant share of them.
        float total = 0.0f;
        for (const auto& g2 : w.groups) total += static_cast<float>(g2.gems);
        big_group.assign(w.groups.size(), 0);
        for (std::size_t k = 0; k < w.groups.size(); ++k)
            big_group[k] = total > 0.0f && w.groups[k].gems > 0 && static_cast<float>(w.groups[k].gems) >= NOVA_BIGJOB * total;
    }
    // Claims and our health do not change while scoring candidates. Scan earlier
    // allies once per call instead of repeating the same job/soak work per group.
    const bool lower_call = tune::kInitiateJobs && !no_initiate && round >= call_ban_until && open_call_by_lower();
    int evaluated = 0; // groups past the bound (APEX_DET caps them)
    for (int oi = 0; oi < n_order; ++oi) {
        // Out of fuel (huge maps, first turn): settle for the best group scored so far.
        if (tune::kDet) {
            if (best >= 0 && (evaluated >= tune::kDetScoreN || bc::fuel_remaining() < static_cast<std::uint64_t>(tune::kDetSafety))) break;
        } else if ((oi & 3) == 3 && best >= 0 && bc::fuel_remaining() < tune::kScoreFloor)
            break;
        const int dist = order[oi].first;
        const std::size_t gi = static_cast<std::size_t>(order[oi].second);
#if X1_FLEEDROP
        if (static_cast<int>(gi) == flee_group && round - last_flee_round <= X1_FLEEDROP) continue;
#endif
        auto& g = w.groups[gi];
        const int approach = std::max(0, dist - (g.state == GroupState::reward ? 0 : range));
        int wait = 0;
        if (g.state == GroupState::respawning)
            wait = static_cast<int>(static_cast<float>(std::max(0, g.respawn_round - round - approach)) * tune::kWaitWeight);
        if (NOVA_BIGCAMP > 0 && g.gems >= 120)
            wait = static_cast<int>(wait * (NOVA_BIGCAMP * 0.01f)); // big strips respawn on a cycle: cheap waiting
#if 1
        if ((A2_MID_W != 1.0f || A2_LAB) && mid_group.size() != w.groups.size()) {
            // Contested middle (A2_MID_W): mirror games are won there (936 real-engine games: the winner's camp-gem
            // edge is +262 in the middle, +63 on its own side, +13 on the enemy's). Static per map: a group's place
            // between the two spawn centres (Chebyshev), 0.35-0.65 of the way.
            mid_group.assign(w.groups.size(), 0);
            float ax = 0, ay = 0, bx = 0, by = 0;
            int na = 0, nb = 0;
            for (vec2 p : w.spawn_tiles) ax += static_cast<float>(p.x), ay += static_cast<float>(p.y), ++na;
            for (vec2 p : w.enemy_spawn.positions()) bx += static_cast<float>(p.x), by += static_cast<float>(p.y), ++nb;
            if (na > 0 && nb > 0) {
                ax /= static_cast<float>(na), ay /= static_cast<float>(na), bx /= static_cast<float>(nb), by /= static_cast<float>(nb);
                for (std::size_t k = 0; k < w.groups.size(); ++k) {
                    if (w.groups[k].camps.empty() || w.groups[k].gems == 0) continue;
                    const vec2 c = w.camps[w.groups[k].camps[0]].pos;
                    const float da = std::max(std::abs(static_cast<float>(c.x) - ax), std::abs(static_cast<float>(c.y) - ay));
                    const float db = std::max(std::abs(static_cast<float>(c.x) - bx), std::abs(static_cast<float>(c.y) - by));
                    const float r = da / std::max(1.0f, da + db);
                    mid_group[k] = r >= 0.35f && r <= 0.65f;
                }
            }
        }
        // Lab knob 40 scales the middle weight (exp(0.3k); 0 = this build's A2_MID_W).
        const float mid_mult = gi < mid_group.size() && mid_group[gi] ? A2_MID_W * std::exp(0.3f * LABK(40)) : 1.0f;
#endif
        {
            const float best_case = (static_cast<float>(g.gems) + gold_weight() * static_cast<float>(g.gold)) * mid_mult *
                tune::kStickiness / (static_cast<float>(approach + wait) + capture_time + 4.0f)
#if X1_PRUNEFIX
                // audit B03: campwatch and the dominant-group multiplier are applied after this prune, so include them in
                // the optimistic bound or a group they would lift is never scored.
                * (A2_CAMPWATCH ? A2_CW_MULT : 1.0f) * (NOVA_BIGJOB > 0.0f && round >= NOVA_BIGJOB_FROM && gi < big_group.size() && big_group[gi] ? NOVA_BIGJOB_MULT : 1.0f)
#endif
                ;
            if (best_case <= prune_bound()
#if X3_TEAM >= 12
                && static_cast<int>(gi)!=x3_proposal
#endif
                ) {
#ifdef APEX_SCOREDBG
                if (g.harmless && g.gems > 0 && round < 60)
                    std::printf("SDBG R%d slot%d G%zu pruned d%d st%d best_case %.3f bound %.3f\n", round, slot, gi, dist,
                        static_cast<int>(g.state), best_case, prune_bound());
#endif
                continue;
            }
        }
        ++evaluated;
        if (group_capture_covered(g)) {
            avoid_until[gi] = round + 6; // an ally is already capturing it
            continue;
        }
        if ((NOVA_DUO & 8) && duo_ignore_slot >= 0 && g.state == GroupState::reward && !g.camps.empty() && w.enemies.empty()) {
            // NOVA_DUO bit 8: our ranged follower takes the capture; we walk on and tank the next camp.
            bool follower_near = false;
            for (const auto& a : w.allies)
                if (a.id == ally_handle[static_cast<std::size_t>(duo_ignore_slot)] && cheb(a.pos, w.camps[g.camps[0]].pos) <= 4)
                    follower_near = true;
            if (follower_near) {
                avoid_until[gi] = round + 3;
                continue;
            }
        }
        if (tune::kShareGold && g.state == GroupState::reward && w.enemies.empty() &&
            poorer_ally_takes(g, static_cast<int>(gi), false)) {
            avoid_until[gi] = round + 4; // a poorer ally takes this reward
            continue;
        }
        int lower = 0, higher = 0;
        {
            PROF(s_claims);
            std::tie(lower, higher) = claims_split(static_cast<int>(gi));
        }
        const int claims = lower + higher;
        const float hp_left = g.hp_left(w.camps);
        int need = 1;
        {
            PROF(s_need);
            need = champions_needed(g, hp_left);
        }
        // NOVA_BIGJOB: the soak model caps at 7 and kept stampede's 17k-health gem camp "impossible" until round 250;
        // opponents with our lineup take it near round 150. A dominant camp is a whole-team job.
        if (NOVA_BIGJOB > 0.0f && gi < big_group.size() && big_group[gi] && need > team_size) need = team_size;
        if (NOVA_BIGJOB > 0.0f && gi < big_group.size() && big_group[gi] && round % 25 == 0)
            LOG("BIG R%d slot%d G%zu need%d team%d claims%d hp_left%.0f state%d dist%d\n", round, slot, gi, need, team_size,
                claims, hp_left, static_cast<int>(g.state), dist);
        if (need > team_size) continue;
        // A job that needs more champions than are on it: open it as a call for help (allies see the
        // claim and join), but only if no earlier slot already has an open call we could answer.
        bool initiating = need > std::max(claims + 1, participants_hint);
#if A2_DPLAN
        // A planned crew job (draft-turn team plan): the crew arrives together, so it is not an uncertain call for help.
        if (dplan_group() == static_cast<int>(gi)) initiating = false;
#endif
        // Siege: spells reach 4 tiles and camps only 3, so casters can wear any camp down safely.
        const float sdps = initiating && tune::kSiege && !in_role_pack ? siege_dps(g) : 0.0f;
        const bool siege = sdps > 0.0f;
        if (siege) initiating = false;
        else if (initiating) {
            const bool big = NOVA_BIGJOB > 0.0f && gi < big_group.size() && big_group[gi];
            if (!tune::kInitiateJobs || no_initiate || round < call_ban_until || need > (big ? team_size : UB_JOB_MAX) || lower_call)
                continue;
        }
        const bool solo_job = need == 1 && (g.state == GroupState::reward || hp_left < 1500.0f);
        // Staffing cap (APEX_CAP_STAFF = n): a group that earlier-acting allies already staff to its
        // need (plus n - 1 spare) is theirs. Without it whole teams piled onto one wolf group, or
        // waited two at a time beside one respawning group, while the next group sat untouched.
        if (tune::kCapStaff > 0 && !solo_job && g.state != GroupState::reward && lower >= need + tune::kCapStaff - 1) continue;
        // Small jobs belong to the earliest-acting claimant; later slots leave them alone.
        // (Everyone reacting to everyone else's claims made whole teams flip targets each turn.)
        const int helpers = solo_job ? 0 : claims;
        const int participants = siege ? 1 : std::max({need, helpers + 1, participants_hint});
        const float kill = siege ? hp_left / sdps : hp_left / (my_dps(&g) + static_cast<float>(participants - 1) * dps);
        float value = static_cast<float>(g.gems) + gold_weight() * static_cast<float>(g.gold);
#if A2_DPLAN
        if (dplan_group() == static_cast<int>(gi)) value *= A2_DP_MULT; // the team plan's current step
#endif
        if (APEX_BOOT_ITEMS > 0 && g.harmless && my_items() < static_cast<float>(APEX_BOOT_ITEMS)) value *= 1.0f + tune::kBootBonus;
        // (With gold sharing, finished groups ignore claims: the poorest champion there takes them.)
        if (solo_job && !(tune::kShareGold && g.state == GroupState::reward) &&
            (tune::kIncumbent ? senior_claims(static_cast<int>(gi)) : lower) > 0)
            value *= 0.15f;
        if (round - g.enemy_round < 15 && !(NOVA_BIGJOB > 0.0f && gi < big_group.size() && big_group[gi])) value *= UB_ENEMY_CAMP;
#if A2_CAMPWATCH
        // Camp watch (ladder replays: the top teams walk into contested camps, weight -0.32 against our -1.06): a group
        // the enemy farmed recently that is about to respawn is where they come next. A healthy champion with an ally
        // beside the group goes there first, so the fight starts with them under camp fire and outnumbered.
        if (g.state == GroupState::respawning && g.respawn_round - round <= A2_CW_LEAD && round - g.enemy_round <= A2_CW_MEM &&
            hp >= max_hp * 0.8f && gems < 20 && allies_near_group(g) >= 1)
            value *= A2_CW_MULT;
#endif
        value *= mid_mult;
#if A2_ZONES
        // Territories: another sector's group is worth A2_ZONE_W of its value (captures and team jobs excepted).
        if (zone_of.size() != w.groups.size()) build_zones();
        if (zone_of[gi] >= 0 && zone_of[gi] != my_zone && g.state != GroupState::reward && need <= 1) value *= A2_ZONE_W;
#endif
#if A2_THREAT
        // Threat-aware camp choice: an exposed champion (hurt or carrying) discounts groups inside the zone enemies
        // could reach from recent sightings. Only lowers values, so the pruning bound stays valid.
        if (hp < max_hp * A2_THREAT_HP || gems >= A2_THREAT_GEMS) {
            const bc::bitboard& zone = a2_threat_zone(w, round);
            for (int ci : g.camps)
                if (bit(zone, w.camps[static_cast<std::size_t>(ci)].pos)) {
                    value *= A2_THREAT_GROUP;
                    break;
                }
        }
#endif
        if (NOVA_BIGJOB > 0.0f && round >= NOVA_BIGJOB_FROM && gi < big_group.size() && big_group[gi]) value *= NOVA_BIGJOB_MULT;
        // Altar-side groups (APEX_ALTAR_BONUS): their gems bank at once, without a trip.
        if (tune::kAltarBonus > 0.0f && w.altar_ready && !g.camps.empty() && fdist(w.altar_field, w.camps[g.camps[0]].pos) <= 6)
            value *= 1.0f + tune::kAltarBonus;
        // Numbers (APEX_NUMBERS_INVADE): with enough extra living champions, take the enemy side's groups.
        if (alive_us - alive_them >= tune::kNumbersInvade && w.enemy_ready && w.group_margin[gi] < 0) value *= 1.0f + tune::kNumbersBonus;
        // Territory (APEX_TERRITORY, until round APEX_TERRITORY_UNTIL): our own side first. The evaluator puts
        // early contact at -13 gems per champion; c1 spent 63% of its time on the enemy half against 46% for
        // the top teams and earned 30% less in the first 150 rounds.
        if (MONO_MULT != 1.0f)
            for (int ci : g.camps)
                if (w.camps[static_cast<std::size_t>(ci)].type == bc::camp_type::monolith) {
                    value *= MONO_MULT; // MONO_MULT: commit to (or ignore) the monolith group
                    break;
                }
        if (HOME_FRONT > 0 && w.enemy_ready && w.group_margin[gi] >= -tune::kTerritoryMargin && w.group_margin[gi] < HOME_FRONT)
            value *= HOME_FRONT_MULT; // frontier groups on our side: where most fights (and deaths) happen
        if (tune::kTerritory != 1.0f && round < tune::kTerritoryUntil &&
#if X3_DRAFT_PATHS
            (w.enemy_ready || w.draft_margin_early) &&
#else
            w.enemy_ready &&
#endif
            w.group_margin[gi] < -tune::kTerritoryMargin)
            value *= tune::kTerritory;
        // Cohesion (APEX_COHESION): a camp far from every teammate gives up the safety of numbers. The top
        // teams operate 7.5 tiles apart against our 11.3 and die a third as often (540 decoded ladder games):
        // value falls by APEX_COHESION per tile beyond APEX_COHESION_DIST from the nearest living teammate.
        if (tune::kCohesion > 0.0f && !w.allies.empty() && !g.camps.empty()) {
            const vec2 gp = w.camps[g.camps[0]].pos;
            int dmin = 999;
            for (const auto& a : w.allies) dmin = std::min(dmin, cheb(a.pos, gp));
            const int over = dmin - (tune::kCohesionDist + static_cast<int>(std::lround(2.0f * LABK(38))));
            if (over > 0) value /= 1.0f + tune::kCohesion * static_cast<float>(over);
        }
        // NOVA_BUDDY: farm our own group, but near our buddy's target (read from its claim slot, so it works
        // out of vision): top bots farm separate camps a few tiles apart and fight with help close by.
        if (NOVA_BUDDY > 0.0f && !g.camps.empty()) {
            const vec2 anchor = buddy_anchor();
            if (anchor.x >= 0) {
                const int over = cheb(anchor, w.camps[g.camps[0]].pos) - NOVA_BUDDY_DIST;
                if (over > 0) value /= 1.0f + NOVA_BUDDY * static_cast<float>(over);
            }
        }
        // NOVA_SEED (0 = off): a small deterministic jitter on group values so one official map can be replayed
        // as many distinct games (evaluation only; neutral on average).
        if (NOVA_SEED > 0) {
            std::uint32_t hs = static_cast<std::uint32_t>(NOVA_SEED) * 2654435761u ^ static_cast<std::uint32_t>(gi) * 40503u ^
                static_cast<std::uint32_t>(round / 20) * 2246822519u ^ static_cast<std::uint32_t>(slot + 1) * 3266489917u;
            hs ^= hs >> 15;
            hs *= 2246822519u;
            hs ^= hs >> 13;
            value *= 1.0f + NOVA_SEED_EPS * (static_cast<float>(hs & 0xffffu) / 32767.5f - 1.0f);
        }
        // Champion-turns the team spends on this group, plus the health it drains: lost health costs a
        // trip home later (APEX_HP_COST turns per full health bar), which made wolves look better
        // than harmless gem clusters.
        float drain = 0.0f;
        if (tune::kHpCost > 0.0f && !g.harmless && g.state != GroupState::reward) {
            const float team_dps = my_dps(&g) + static_cast<float>(participants - 1) * dps;
            drain = soak_coefficient(static_cast<int>(gi), hp_left) * camp_taken_mult / std::max(team_dps, 1.0f) /
                std::max(max_hp, 1.0f) * tune::kHpCost;
        }
        const float cost = static_cast<float>(participants) * (static_cast<float>(approach + wait) + kill) +
            capture_time + 4.0f + drain;
        float cycle_cost = cost;
#if X3_BANKCYCLE == 1
        if (w.altar_ready && !w.no_bank && g.gems > 0) {
            int bank_distance = kUnreach;
            for (int ci : g.camps)
                bank_distance = std::min(bank_distance, static_cast<int>(fdist(w.altar_field, w.camps[ci].pos)));
            if (bank_distance != kUnreach)
                cycle_cost = economic_cycle::delivery_cost(cost, static_cast<float>(g.gems),
                    gold_weight() * static_cast<float>(g.gold), bank_distance);
#if X3_TRACE
            if (round % 100 == 0 && cycle_cost > cost)
                std::printf("X3_CYCLE R%d slot%d G%zu collect%.2f cycle%.2f bank%d\n", round, slot, gi, cost, cycle_cost, bank_distance);
#endif
        }
#endif
        float score = value / cycle_cost;
#if UB_CAMPFIX
        // Camp-choice correction learned from ladder replays (ladder/camp_choice2.py): a conditional logit fitted to
        // our champions' and to the top teams' camp captures; their difference, added to our log score, moves our
        // choices toward theirs (less gold-cluster farming, more elk / wolf groups, less fear of nearby enemies).
        if (round <= UB_CAMPFIX_UNTIL && !g.camps.empty()) {
            int elks = 0, wolves = 0, big = 0;
            for (int ci : g.camps) {
                const auto t = w.camps[static_cast<std::size_t>(ci)].type;
                elks += t == bc::camp_type::elk;
                wolves += t == bc::camp_type::wolf;
                big += t == bc::camp_type::golem || t == bc::camp_type::monolith;
            }
            const vec2 gp = w.camps[static_cast<std::size_t>(g.camps[0])].pos;
            bool enemy6 = false, ally4 = false;
            for (const auto& e : w.enemies) enemy6 = enemy6 || cheb(e.pos, gp) <= 6;
            for (const auto& a : w.allies) ally4 = ally4 || cheb(a.pos, gp) <= 4;
            constexpr float fix[10] = {UB_CAMPFIX_W};
            const float z = fix[1] * static_cast<float>(g.gems) / 10.0f +
                (fix[2] + (round <= 200 ? fix[3] : 0.0f)) * static_cast<float>(g.gold) / 100.0f + fix[4] * (g.harmless ? 1.0f : 0.0f) +
                fix[5] * static_cast<float>(elks) + fix[6] * static_cast<float>(wolves) + fix[7] * static_cast<float>(big) +
                fix[8] * (enemy6 ? 1.0f : 0.0f) + fix[9] * (ally4 ? 1.0f : 0.0f);
            score *= std::exp(UB_CAMPFIX_SCALE * std::max(-4.0f, std::min(4.0f, z)));
        }
#endif
#if UB_QCAMP
        // Offline-RL camp value (ladder/q_camp.py): Q fitted on ~29k logged ladder camp choices (ours and the top teams')
        // to what the champion earned over the next 60 rounds (gold + 10 x gems - 150 per death). Linear in the
        // group's features times our own state (1, round, max health, strength), so it values a group for a champion
        // as strong as us. A gentle nudge on the hand-built score: x exp(UB_Q_BETA x Q / 100).
        if (!g.camps.empty()) {
            int elks = 0, wolves = 0, big = 0;
            for (int ci : g.camps) {
                const auto t = w.camps[static_cast<std::size_t>(ci)].type;
                elks += t == bc::camp_type::elk;
                wolves += t == bc::camp_type::wolf;
                big += t == bc::camp_type::golem || t == bc::camp_type::monolith;
            }
            const vec2 gp = w.camps[static_cast<std::size_t>(g.camps[0])].pos;
            bool enemy6 = false, ally4 = false;
            for (const auto& e : w.enemies) enemy6 = enemy6 || cheb(e.pos, gp) <= 6;
            for (const auto& a : w.allies) ally4 = ally4 || cheb(a.pos, gp) <= 4;
            const float f[10] = {static_cast<float>(cheb(pos, gp)) / 10.0f, static_cast<float>(g.gems) / 10.0f, static_cast<float>(g.gold) / 100.0f,
                g.harmless ? 1.0f : 0.0f, static_cast<float>(elks), static_cast<float>(wolves), static_cast<float>(big), enemy6 ? 1.0f : 0.0f,
                ally4 ? 1.0f : 0.0f, static_cast<float>(g.camps.size()) / 10.0f};
            const float s[4] = {1.0f, static_cast<float>(round) / 1000.0f, max_hp / 1000.0f, strength / 100.0f};
            constexpr float qw[40] = {UB_Q_W};
            float q = 0.0f;
            for (int i = 0; i < 10; ++i)
                for (int j = 0; j < 4; ++j) q += qw[i * 4 + j] * f[i] * s[j];
            score *= std::exp(std::max(-3.0f, std::min(3.0f, UB_Q_BETA * q / 100.0f)));
        }
#endif
#ifdef APEX_SCOREDBG
        if (g.harmless && g.gems > 0 && round < 60)
            std::printf("SDBG R%d slot%d G%zu d%d st%d claims %d/%d value %.1f cost %.1f score %.3f best %.3f\n", round, slot, gi,
                dist, static_cast<int>(g.state), lower, higher, value, cost, score, best_score);
#endif
        if (initiating) score *= UB_JOB_INIT; // uncertain help: prefer jobs we can finish now
        if (siege) score *= 0.8f;
        if (static_cast<int>(gi) == target_group) score *= tune::kStickiness; // finish what we started
        if constexpr (learner::on) {
            // NOVA_LEARNER: learned residual on the hand score. Zero weights = identity, so the
            // switch is a no-op until trained weights land in NOVA_LEARNER_W.
            const int state_ord = static_cast<int>(g.state);
            float phi[16];
            learner::gather(&g, hp_left, kill, drain, approach, wait, dist, participants, need, state_ord,
                g.harmless, lower, higher, value, score, siege, initiating, solo_job, phi);
            phi[0] = static_cast<float>(g.gems) / 64.0f > 3.0f ? 3.0f : static_cast<float>(g.gems) / 64.0f;
            phi[1] = static_cast<float>(g.gold) / 64.0f > 3.0f ? 3.0f : static_cast<float>(g.gold) / 64.0f;
            score = learner::fix(score, phi);
        }
        if (tune::kBelief && tune::kBeliefW > 0.0f && score > prune_bound() && !g.camps.empty() && bc::fuel_remaining() > (tune::kDet ? static_cast<std::uint64_t>(tune::kDetSafety) : 30000)) {
            // Enemies that could be at this group before we are done with it (beliefs), beyond what our side
            // brings: contested jobs get champions caught alone.
            const int finish = approach + wait + static_cast<int>(kill);
            const vec2 gp = w.camps[g.camps[0]].pos;
            const float e = w.expected_enemies(gp, std::min(finish, 12) + 2);
            int friends = 1;
            for (const auto& a : w.allies) friends += cheb(a.pos, gp) <= 6;
            const float excess = e - tune::kBeliefAlly * static_cast<float>(friends);
            if (excess > 0.0f) score /= 1.0f + tune::kBeliefW * excess;
        }
        if (score > best_score) {
            best_score = score;
            best = static_cast<int>(gi);
            best_need = need;
        }
#if X3_TEAM >= 12
        if (static_cast<int>(gi)==x3_proposal) {x3_proposal_score=score;x3_proposal_need=need;}
#endif
#if A2_CAMPNET
        if (score > 0.0f && n_cn < kCnMax && bc::fuel_remaining() > static_cast<std::uint64_t>(tune::kDetSafety) + 12000) {
            CnCand& c = cn[n_cn++];
            c.gi = static_cast<int>(gi), c.need = need, c.score = score;
            int elks = 0, wolves = 0, big = 0;
            for (int ci : g.camps) {
                const auto t = w.camps[static_cast<std::size_t>(ci)].type;
                elks += t == bc::camp_type::elk, wolves += t == bc::camp_type::wolf, big += t == bc::camp_type::golem || t == bc::camp_type::monolith;
            }
            const vec2 gp = g.camps.empty() ? pos : w.camps[static_cast<std::size_t>(g.camps[0])].pos;
            bool enemy6 = false, ally4 = false;
            for (const auto& e : w.enemies) enemy6 = enemy6 || cheb(e.pos, gp) <= 6;
            for (const auto& a : w.allies) ally4 = ally4 || cheb(a.pos, gp) <= 4;
            const float f[lab_cn::kF] = {0.0f, static_cast<float>(cheb(pos, gp)) / 10.0f, static_cast<float>(g.gems) / 10.0f, static_cast<float>(g.gold) / 100.0f,
                g.harmless ? 1.0f : 0.0f, static_cast<float>(elks), static_cast<float>(wolves), static_cast<float>(big), enemy6 ? 1.0f : 0.0f, ally4 ? 1.0f : 0.0f,
                static_cast<float>(need) / 3.0f, hp / std::max(1.0f, max_hp), max_hp / 1000.0f, strength / 100.0f, static_cast<float>(round) / 1000.0f,
                static_cast<float>(gems) / 50.0f, camp_taken_mult, 0.0f};
            for (int k = 0; k < lab_cn::kF; ++k) c.f[k] = f[k];
        }
#endif
        if (keep > 1 && (n_top < keep || score > top[n_top - 1].score)) {
            // Turns until this champion is free again: walk, wait, kill, capture.
            const int finish = approach + wait + static_cast<int>(kill) + capture_time;
            int i = n_top < keep ? n_top++ : keep - 1;
            for (; i > 0 && top[i - 1].score < score; --i) top[i] = top[i - 1];
            top[i] = {static_cast<int>(gi), need, value, cost, score, finish};
        }
    }
    if (keep > 1 && n_top >= 2 && bc::fuel_remaining() > tune::kRouteFuel && (!A2_FIELDFIRST || w.fields_ready())) {
        bool bank = false;
        const int pick = tune::kPlan ? plan_search(top, n_top, bank) : route_search(top, n_top);
        PROF_CHECK("route1");
        if (tune::kPlan && bank) plan_bank_round = round;
        if (pick >= 0) {
            best = top[pick].gi;
            best_need = top[pick].need;
            best_score = top[pick].score;
        }
    }
#if A2_CAMPNET
    if (best >= 0 && n_cn >= 2) best = campnet_pick(cn, n_cn, best, best_need, best_score);
#endif
    return best;
}

// Follow-up table for one champion alone, rebuilt once per turn in a single pass over the groups.
void Bot::refresh_follow_ups() {
    if (follow_round == round) return;
    follow_round = round;
    const std::size_t n = w.groups.size();
    follow_value.resize(n);
    follow_fixed.resize(n);
    follow_respawn.resize(n);
    const float base_dps = my_dps(nullptr);
    for (std::size_t gi = 0; gi < n; ++gi) {
        const auto& g = w.groups[gi];
        const float dps = (type == bc::champion_type::varg && g.camps.size() > 1) ? base_dps * 1.6f : base_dps;
        const float kill = g.hp_left(w.camps) / std::max(dps, 1.0f);
        float value = static_cast<float>(g.gems) + gold_weight() * static_cast<float>(g.gold);
        if (round - g.enemy_round < 15) value *= UB_ENEMY_CAMP;
        // Safe alone: the camps' damage over the kill stays well under our health.
        const bool solo = g.harmless || g.strength * kill < hp * 0.8f;
        if (!solo || avoid_until[gi] > round) value = 0.0f;
        follow_value[gi] = value;
        follow_fixed[gi] = kill + static_cast<float>(capture_time) + 4.0f;
        follow_respawn[gi] = g.state == GroupState::respawning ? g.respawn_round : -1;
    }
    // Groups a teammate has claimed are theirs.
    for (int s = 0; s < std::min(team_size, kClaimSlots); ++s) {
        const int c = claim_of(s);
        if (s != slot && c >= 0 && c < static_cast<int>(n)) follow_value[static_cast<std::size_t>(c)] = 0.0f;
    }
}

// Extend each first target with its best follow-up group(s) and return the index (into top) of
// the route with the best gems per champion-turn. Group-to-group distances are static rows.
int Bot::route_search(const RouteCand* top, int n_top) {
    PROF(route);
    PROF_CHECK("route0");
    refresh_follow_ups();
    const int n = static_cast<int>(w.groups.size());
    const int depth = std::min(tune::kRouteDepth, 3);
    const int m_keep = std::clamp(tune::kRouteM, 1, 4);
    const float* fv = follow_value.data();
    const float* ff = follow_fixed.data();
    const int* fr = follow_respawn.data();
    int new_rows = 0; // building a row costs ~2k fuel; at most two per turn
    auto row_of = [&](int from) {
        const bool may = new_rows < 2;
        const bool had = w.pair_row(from, false) != nullptr;
        const std::uint16_t* r = w.pair_row(from, may);
        if (r && !had) ++new_rows;
        return r;
    };
    // Cost of walking to g from a point `t0` turns from now, `d` steps away.
    auto leg_cost = [&](int g, int d, int t0, int& done) {
        const int walk = std::max(0, d - range);
        const int arrive = t0 + walk;
        int wait = fr[g] >= 0 ? std::max(0, fr[g] - round - arrive) : 0;
        if (NOVA_BIGCAMP > 0 && w.groups[static_cast<std::size_t>(g)].gems >= 120)
            wait = static_cast<int>(wait * (NOVA_BIGCAMP * 0.01f)); // big strips: waiting on the respawn cycle is cheap
        done = arrive + wait + static_cast<int>(ff[g]);
        return static_cast<float>(walk + wait) + ff[g];
    };
    int best_i = -1;
    float best_rate = 0.0f;
    for (int i = 0; i < n_top; ++i) {
        if (bc::fuel_remaining() < tune::kRouteFuel / 2) break;
        const RouteCand& c = top[i];
        const float sticky = c.gi == target_group ? tune::kStickiness : 1.0f;
        float route = c.score; // the first target alone (stickiness included)
        const std::uint16_t* row1 = row_of(c.gi);
        if (row1) {
            struct Step {
                int gi;
                float value, cost;
                int done;
            };
            Step keep2[4];
            int n2 = 0;
            for (int g2 = 0; g2 < n; ++g2) {
                if (fv[g2] <= 0.0f || g2 == c.gi || row1[g2] == kUnreach) continue;
                int done2 = 0;
                const float cost2 = leg_cost(g2, row1[g2], c.finish, done2);
                const float rate = (c.value + fv[g2]) / (c.cost + cost2) * sticky;
                if (rate > route) route = rate;
                if (depth >= 3) {
                    // Keep the m_keep follow-ups with the best rate of their own for level 3.
                    const float own = fv[g2] / cost2;
                    if (n2 == m_keep && keep2[n2 - 1].value / keep2[n2 - 1].cost >= own) continue;
                    int k = n2 < m_keep ? n2++ : m_keep - 1;
                    for (; k > 0 && keep2[k - 1].value / keep2[k - 1].cost < own; --k) keep2[k] = keep2[k - 1];
                    keep2[k] = {g2, fv[g2], cost2, done2};
                }
            }
            for (int j = 0; j < n2; ++j) {
                const Step& s2 = keep2[j];
                const std::uint16_t* row2 = row_of(s2.gi);
                if (!row2) continue;
                for (int g3 = 0; g3 < n; ++g3) {
                    if (fv[g3] <= 0.0f || g3 == c.gi || g3 == s2.gi || row2[g3] == kUnreach) continue;
                    int done3 = 0;
                    const float cost3 = leg_cost(g3, row2[g3], s2.done, done3);
                    const float rate = (c.value + s2.value + fv[g3]) / (c.cost + s2.cost + cost3) * sticky;
                    if (rate > route) route = rate;
                }
            }
        }
        if (route > best_rate) {
            best_rate = route;
            best_i = i;
        }
    }
    return best_i;
}

// Farming planner (APEX_PLAN): searches short sequences of jobs, where a job is a camp group (walk, wait for a
// respawn, kill, capture) or a bank trip (walk to the nearest altar, channel ceil(gems / 10)), and returns the
// first job of the sequence with the best gain per turn. Gains use the position evaluator's learned rates: a
// banked gem is worth 1, a carried one APEX_PLAN_CARRY (0.75 from 311k top-team positions), so banking turns
// every carried gem's discount into value. Returns the index into `top`, or -1 with bank_first set.
int Bot::plan_search(const RouteCand* top, int n_top, bool& bank_first) {
    PROF(plan);
    bank_first = false;
#if X3_BANKCYCLE >= 3
    // Optional planning must leave the executor's safety reserve intact.
    if (bc::fuel_remaining() < 50000) return -1;
    n_top = std::min(n_top, 4);
#endif
    refresh_follow_ups();
    if (!w.ensure_altar_field()) return -1;
    const int n = static_cast<int>(w.groups.size());
    const float kappa = tune::kPlanCarry;
    const float* fv = follow_value.data();
    const float* ff = follow_fixed.data();
    const int* fr = follow_respawn.data();
    int new_rows = 0;
    auto row_of = [&](int from) {
        const bool may = new_rows < 2
#if X3_BANKCYCLE >= 3
            && bc::fuel_remaining() >= 50000
#endif
            ;
        const bool had = w.pair_row(from, false) != nullptr;
        const std::uint16_t* r = w.pair_row(from, may);
        if (r && !had) ++new_rows;
        return r;
    };
    auto gems_of = [&](int gi) { return static_cast<float>(w.groups[static_cast<std::size_t>(gi)].gems); };
    auto altar_from_group = [&](int gi) {
        const auto& g = w.groups[static_cast<std::size_t>(gi)];
#if X3_BANKCYCLE >= 2
        int distance = kUnreach;
        for (int ci : g.camps) distance = std::min(distance, static_cast<int>(fdist(w.altar_field, w.camps[ci].pos)));
        return distance;
#else
        return g.camps.empty() ? kUnreach : static_cast<int>(fdist(w.altar_field, w.camps[g.camps[0]].pos));
#endif
    };
    auto channel = [](float bag) { return std::max(1, static_cast<int>(std::ceil(bag / 10.0f))); };
    const float carried0 = static_cast<float>(gems);
    // Gain per turn of a finished plan: groups collected (value), gems collected, time, and whether it banked.
    auto rate = [&](float value, float collected, float time, bool banked) {
        (void)collected; // banked: everything is worth 1, so the bag we started with gains its discount back
#if X3_BANKCYCLE >= 2
        // Gold is available immediately; discount only newly carried gems.
        const float gain = banked ? value + (1.0f - kappa) * carried0
                                  : std::max(0.0f, value - (1.0f - kappa) * collected);
#else
        const float gain = banked ? value + (1.0f - kappa) * carried0 : kappa * value;
#endif
        return gain / std::max(time, 1.0f);
    };
    float best = 0.0f;
    int best_i = -1;
    // Bank right now.
    const int here_altar = static_cast<int>(fdist(w.altar_field, pos));
    if (gems >= 10 && here_altar != kUnreach) {
        const float t = static_cast<float>(here_altar + channel(carried0));
        best = (1.0f - kappa) * carried0 / std::max(t, 1.0f) * tune::kPlanBankBias;
        bank_first = true;
    }
    auto leg = [&](int g, int d, int t0, int& done) {
        const int walk = std::max(0, d - range);
        const int arrive = t0 + walk;
        const int wait = fr[g] >= 0 ? std::max(0, fr[g] - round - arrive) : 0;
        done = arrive + wait + static_cast<int>(ff[g]);
        return static_cast<float>(walk + wait) + ff[g];
    };
    // APEX_PLAN 2: the camp choice stays the greedy best (top[0]); the planner only decides whether to bank first.
    if (tune::kPlan == 2) n_top = std::min(n_top, 1);
    for (int i = 0; i < n_top; ++i) {
        if (bc::fuel_remaining() <
#if X3_BANKCYCLE >= 3
            45000
#else
            tune::kRouteFuel / 2
#endif
            ) break;
        const RouteCand& c = top[i];
        const float sticky = c.gi == target_group ? tune::kStickiness : 1.0f;
        const float g1 = gems_of(c.gi);
        const float t1 = static_cast<float>(c.finish);
        float route = rate(c.value, g1, t1, false) * sticky;
        // Camp, then bank.
        const int a1 = altar_from_group(c.gi);
        if (a1 != kUnreach) route = std::max(route, rate(c.value, g1, t1 + static_cast<float>(a1 + channel(carried0 + g1)), true) * sticky);
        const std::uint16_t* row1 = row_of(c.gi);
        if (row1) {
            struct Step {
                int gi;
                float value, cost;
                int done;
            };
            Step keep2[4];
            int n2 = 0;
            const int m_keep = std::clamp(tune::kRouteM, 1, 4);
            for (int g2 = 0; g2 < n; ++g2) {
#if X3_BANKCYCLE >= 3
                if ((g2 & 7) == 0 && bc::fuel_remaining() < 45000) break;
#endif
                if (fv[g2] <= 0.0f || g2 == c.gi || row1[g2] == kUnreach) continue;
                int done2 = 0;
                const float cost2 = leg(g2, row1[g2], c.finish, done2);
                const float own = fv[g2] / cost2;
                if (n2 == m_keep && keep2[n2 - 1].value / keep2[n2 - 1].cost >= own) continue;
                int k = n2 < m_keep ? n2++ : m_keep - 1;
                for (; k > 0 && keep2[k - 1].value / keep2[k - 1].cost < own; --k) keep2[k] = keep2[k - 1];
                keep2[k] = {g2, fv[g2], cost2, done2};
            }
            for (int j = 0; j < n2; ++j) {
                const Step& s2 = keep2[j];
                const float v12 = c.value + s2.value, g12 = g1 + gems_of(s2.gi), t12 = t1 + s2.cost;
                route = std::max(route, rate(v12, g12, t12, false) * sticky);
                const int a2 = altar_from_group(s2.gi);
                if (a2 != kUnreach) route = std::max(route, rate(v12, g12, t12 + static_cast<float>(a2 + channel(carried0 + g12)), true) * sticky);
                if (tune::kPlanDepth >= 3 && X3_BANKCYCLE < 3) {
                    const std::uint16_t* row2 = row_of(s2.gi);
                    if (!row2) continue;
                    for (int g3 = 0; g3 < n; ++g3) {
#if X3_BANKCYCLE >= 3
                if ((g3 & 7) == 0 && bc::fuel_remaining() < 45000) break;
#endif
                        if (fv[g3] <= 0.0f || g3 == c.gi || g3 == s2.gi || row2[g3] == kUnreach) continue;
                        int done3 = 0;
                        const float cost3 = leg(g3, row2[g3], s2.done, done3);
                        const float v = v12 + fv[g3], gg = g12 + gems_of(g3), tt = t12 + cost3;
                        route = std::max(route, rate(v, gg, tt, false) * sticky);
                        const int a3 = altar_from_group(g3);
                        if (a3 != kUnreach) route = std::max(route, rate(v, gg, tt + static_cast<float>(a3 + channel(carried0 + gg)), true) * sticky);
                    }
                }
            }
        }
        if (route > best) {
            best = route;
            best_i = i;
            bank_first = false;
        }
    }
#if X3_TRACE && X3_BANKCYCLE >= 2
    if (round % 100 == 0)
        std::printf("X3_SEARCH R%d slot%d candidates%d pick%d bank%d rate%.3f fuel%llu\n", round, slot, n_top, best_i, bank_first, best, static_cast<unsigned long long>(bc::fuel_remaining()));
#endif
    return best_i;
}
// Same identity as the draft (draft.cpp): map size, draft picks and the engine's camp-group count.
bool Bot::is_official_map() {
    if (official_map < 0) {
        std::uint32_t ngroups = 0;
        const int ng = d::sdk_map_num_camp_groups(&ngroups) == 0 ? static_cast<int>(ngroups) : -1;
        unsigned picks = static_cast<unsigned>(team_size); // champions; Cassi & Issac are two bodies for one pick
        try {
            picks = bc::draft::team_size();
        } catch (...) {
        }
        official_map = nova_map_id(static_cast<int>(bc::map::width()), static_cast<int>(bc::map::height()), picks, ng) >= 0;
    }
    return official_map == 1;
}

bool Bot::farm() {
    PROF(farm);
    PROF_CHECK("farm0");
#if X3_TEAM >= 12
    x3_proposal=-1;x3_proposal_score=0;x3_proposal_need=1;
#endif
    if (avoid_until.size() != w.groups.size()) avoid_until.assign(w.groups.size(), 0);
#if V58_DIRECTOR && V58_ROUTE
    if (economy_release_capture()) return true;
#endif
    int best = -1, best_need = 1;
    float best_score = 0;

    // Short on fuel (first turn on a huge map, or a heavy fight turn): keep the current target rather
    // than rescoring every group, so the turn cannot run out of fuel and get suspended.
    // Deterministic (APEX_DET): keep the current target in turns the fight search ran (its playouts used the fuel),
    // otherwise only below the safety floor.
    // The first turn (initialisation on the doubled budget) never farms: it ends near the floor on big maps.
    const bool low_fuel = tune::kDet ? (field_calls == 0 || ts_ran_round == round ||
                                        bc::fuel_remaining() < static_cast<std::uint64_t>(tune::kDetSafety) + 10000)
                                     : bc::fuel_remaining() < tune::kLowFuel;
#if APEX_PROFILE
    ++prof::farm_calls;
    prof::farm_low += low_fuel;
    prof::farm_route_skip += bc::fuel_remaining() < tune::kRouteFuel;
    prof::td_then_farm += prof::td_round == round;
#endif
    if (low_fuel) {
        if (target_group < 0 || target_group >= static_cast<int>(w.groups.size()) || avoid_until[target_group] > round) {
#if APEX_PROFILE
            ++prof::farm_gaveup;
#endif
            return false;
        }
        best = target_group;
    }
#if X3_TEAM
    if (!low_fuel) {
        const int assigned=team_economic_assignment(best_need);
        if (assigned == -3 && gems > 0) {
#if X3_BANK_COMMIT
            team_bank_commit();
#endif
            force_tribute=true;
            const bool banking=tribute_if_needed();
            force_tribute=false;
            if (banking) {write_claim(-1);mode="team-bank";return true;}
        }
        if (assigned>=0) {
#if X3_TEAM >= 12
            x3_proposal=assigned;
#else
            best=assigned;
#endif
        }
    }
#endif
    // Escort (APEX_ESCORT): a caster farms where the nearest healthy melee ally farms, so a protector is
    // beside it when enemies arrive (alone, casters spent up to 30% of their turns fleeing).
    if (tune::kEscort > 0 && !low_fuel && !melee && best < 0) {
        int lead = -1, lead_d = tune::kEscort + 1;
        for (const auto& a : w.allies) {
            if (a.range > 1 || a.hp < a.max_hp * 0.3f) continue;
            const int d = cheb(a.pos, pos);
            if (d >= lead_d) continue;
            int s = -1;
            for (int k = 0; k < std::min(team_size, kClaimSlots); ++k)
                if (ally_handle[static_cast<std::size_t>(k)] == a.id) s = k;
            if (s < 0 || s == slot) continue;
            const int lc = claim_of(s);
            if (lc >= static_cast<int>(w.groups.size()) || avoid_until[lc] > round || group_capture_covered(w.groups[lc])) continue;
            lead_d = d;
            lead = lc;
        }
        if (lead >= 0) {
            best = lead;
            best_need = 1;
            mode = "escort";
        }
    }
    if (tune::kRoleSquad > 0)
        for (const auto& a : w.allies)
            for (int k = 0; k < std::min(team_size, 8); ++k)
                if (ally_handle[static_cast<std::size_t>(k)] == a.id) slot_type[static_cast<std::size_t>(k)] = a.type;
    // Role squads (APEX_ROLE_SQUAD): the casters and Issac (and Ren at 2) farm as one pack behind the
    // lowest living member, as the top teams do; the other melee champions farm alone.
    if (tune::kRoleSquad > 0 && !low_fuel && best < 0) {
        auto in_pack = [&](bc::champion_type t) {
            return t == bc::champion_type::cassi || t == bc::champion_type::issac || t == bc::champion_type::stellar ||
                t == bc::champion_type::tavi || t == bc::champion_type::prism || t == bc::champion_type::willow ||
                (tune::kRoleSquad >= 2 && t == bc::champion_type::ren);
        };
        if (in_pack(type)) {
            int leader = -1, melee_leader = -1, alive = 0;
            for (int s = 0; s < std::min(team_size, kClaimSlots); ++s) {
                const auto t = slot_type[static_cast<std::size_t>(s)];
                if (!in_pack(t)) continue;
                if (s != slot && claim_of(s) == static_cast<int>(kClaimCodeDead)) continue;
                ++alive;
                if (leader < 0) leader = s;
                if (melee_leader < 0 && (t == bc::champion_type::issac || t == bc::champion_type::ren)) melee_leader = s;
            }
            if (melee_leader >= 0) leader = melee_leader; // a melee member picks jobs it can fight (no slow sieges)
            in_role_pack = alive >= 2;
            if (alive >= 2) {
                if (leader == slot) {
                    best = score_groups(alive, best_need, best_score);
                    best_need = 1; // the pack is with us: no staging for helpers
                } else if (leader >= 0) {
                    const int lc = claim_of(leader);
                    if (lc < static_cast<int>(w.groups.size()) && avoid_until[lc] <= round &&
                        (tune::kSquadShare || !group_capture_covered(w.groups[lc]))) {
                        best = lc;
                        best_need = 1;
                    } else {
                        // No usable job from the leader: close in on it rather than wander off alone.
                        for (const auto& a : w.allies)
                            if (a.id == ally_handle[static_cast<std::size_t>(leader)] && cheb(a.pos, pos) > 2) {
                                bc::bitboard goal;
                                goal.clear();
                                goal.draw_chebyshev(a.pos, 2.0f);
                                mode = "regroup";
                                walk_toward(goal);
                                return true;
                            }
                        if (lc < static_cast<int>(w.groups.size())) return false; // beside the leader: hold
                    }
                }
            }
        }
    }
    // Squads: slots split round-robin; the lowest living slot leads and the rest follow its claim.
    const int squads = A2_GROUP_UNTIL > 0 && round >= A2_GROUP_UNTIL ? 0 : tune::kSquads;
    if (squads > 0 && !low_fuel) {
        const int my_squad = slot % squads;
        int leader = -1, alive = 0;
        for (int s = my_squad; s < std::min(team_size, kClaimSlots); s += squads) {
            if (s != slot && claim_of(s) == static_cast<int>(kClaimCodeDead)) continue; // dead members do not count
            ++alive;
            if (leader < 0) leader = s;
        }
        if (leader == slot) {
            best = score_groups(alive, best_need, best_score);
        } else if (leader >= 0) {
            const int lc = claim_of(leader);
            if (lc < static_cast<int>(w.groups.size()) && avoid_until[lc] <= round && (tune::kSquadShare || !group_capture_covered(w.groups[lc]))) {
                best = lc;
                best_need = 1; // the squad arrives together; no staging for followers
            }
        }
    }
    // NOVA_DUO: the ranged member of a buddy pair joins its melee buddy's camp fight (fight_camps puts ranged
    // champions at full range, so the closer buddy draws the camps). Reward, respawning and harmless groups
    // are not joined: there the ranged member picks its own job.
    bool duo_leader = false;
    duo_ignore_slot = -1;
    if (NOVA_DUO > 0 && duo_map_ok < 0) duo_map_ok = NOVA_DUO_MAPS == 0 || !is_official_map();
    if (NOVA_DUO > 0 && duo_map_ok == 1 && !low_fuel && best < 0 && round < NOVA_DUO_UNTIL) {
        const int b = buddy();
        auto melee_type = [](bc::champion_type t) {
            return t == bc::champion_type::ryth || t == bc::champion_type::vendetta || t == bc::champion_type::issac ||
                t == bc::champion_type::marcella || t == bc::champion_type::ren || t == bc::champion_type::varg;
        };
        const bool buddy_alive = b >= 0 && claim_of(b) != static_cast<int>(kClaimCodeDead);
        if (buddy_alive && melee && !melee_type(slot_type[static_cast<std::size_t>(b)])) {
            duo_leader = (NOVA_DUO & 2) != 0;
            duo_ignore_slot = b; // our follower's claim on our job is help, not a rival claim
        }
        if (buddy_alive && !melee && melee_type(slot_type[static_cast<std::size_t>(b)])) {
            const int bcl = claim_of(b);
            bool keep_own = false;
            if ((NOVA_DUO & 4) && target_group >= 0 && target_group < static_cast<int>(w.groups.size()) && target_group != bcl) {
                const auto& og = w.groups[static_cast<std::size_t>(target_group)];
                if (og.state == GroupState::alive && !og.harmless)
                    for (int ci : og.camps)
                        keep_own |= w.camps[ci].dead || w.camps[ci].hp < w.camps[ci].max_hp; // already engaged
            }
            if ((NOVA_DUO & 8) && target_group >= 0 && target_group < static_cast<int>(w.groups.size()) &&
                w.groups[static_cast<std::size_t>(target_group)].state == GroupState::reward && w.has_field(target_group) &&
                w.group_distance(target_group, pos) <= 4 && !group_capture_covered(w.groups[static_cast<std::size_t>(target_group)])) {
                keep_own = true; // we take the capture; the buddy has moved on to tank the next camp
                best = target_group;
                best_need = 1;
            }
            if (!keep_own && best < 0 && bcl >= 0 && bcl < static_cast<int>(w.groups.size()) && avoid_until[static_cast<std::size_t>(bcl)] <= round) {
                const auto& bg = w.groups[static_cast<std::size_t>(bcl)];
                const int dist = w.has_field(bcl) ? w.group_distance(bcl, pos) : kUnreach;
                if (bg.state == GroupState::alive && !bg.harmless && dist <= NOVA_DUO_DIST) {
                    best = bcl;
                    best_need = 1;
                }
                LOG("DUO R%d slot%d buddy%d claim%d state%d harmless%d dist%d -> best%d\n", round, slot, b, bcl,
                    static_cast<int>(bg.state), bg.harmless ? 1 : 0, dist, best);
            }
        }
    }
    // Pair mode (WHIM's opening shape): the last kPair claim slots farm as one squad (the lowest
    // living one picks, the others follow its claim), so two-champion camps need no help calls;
    // the other champions farm solo.
    no_initiate = false;
    const int claimable = std::min(team_size, kClaimSlots);
    if (tune::kPair > 0 && (A2_GROUP_UNTIL == 0 || round < A2_GROUP_UNTIL) && squads == 0 && !low_fuel && best < 0 && claimable >= tune::kPair + 1) {
        const int first = claimable - tune::kPair;
        if (slot >= first && slot < claimable) {
            int leader = -1, alive = 0;
            for (int s = first; s < claimable; ++s) {
                if (s != slot && claim_of(s) == static_cast<int>(kClaimCodeDead)) continue;
                ++alive;
                if (leader < 0) leader = s;
            }
            if (leader == slot) {
                best = score_groups(alive, best_need, best_score);
            } else if (leader >= 0) {
                const int lc = claim_of(leader);
                if (lc < static_cast<int>(w.groups.size()) && avoid_until[lc] <= round && (tune::kSquadShare || !group_capture_covered(w.groups[lc]))) {
                    best = lc;
                    best_need = 1;
                }
            }
        } else {
            no_initiate = !tune::kSoloInitiate;
        }
    }
    if (best < 0) best = score_groups(duo_leader ? 2 : 1, best_need, best_score);
    if (best < 0 && (tune::kDet ? ts_ran_round != round && bc::fuel_remaining() > static_cast<std::uint64_t>(tune::kDetSafety) + 10000
                                : bc::fuel_remaining() > tune::kLowFuel / 2)) {
        // Nothing is safe to finish alone: chip at the best big camp anyway. Damage persists,
        // and the disengage rule walks us out before the camp kills us.
        best = score_groups(team_size, best_need, best_score);
        best_need = 1;
    }
#if A2_PLAN
    // Team camp plan: replace a solo choice with this champion's row of the team assignment (not mid-capture).
    if (best >= 0 && best_need == 1 && !(w.groups[static_cast<std::size_t>(best)].state == GroupState::reward &&
                                         bit(w.groups[static_cast<std::size_t>(best)].tiles, pos))) {
        const int planned = a2_team_plan();
        if (planned >= 0) best = planned;
    }
#endif
    PROF_CHECK("farmsel");
#if X3_TEAM >= 12
    // Pay at most a 10% local opportunity cost for a coordinated allocation.
    // An unscored/infeasible proposal is refused through the normal claim write.
    if (x3_proposal>=0 && x3_proposal_score>0 && x3_proposal_score>=0.9f*best_score) {
        best=x3_proposal;best_need=x3_proposal_need;best_score=x3_proposal_score;
    }
#if X3_TRACE
    if (x3_proposal>=0) std::printf("X3_CONTRACT R%d slot%d proposed%d accepted%d score%.3f\n",round,slot,x3_proposal,best==x3_proposal,x3_proposal_score);
#endif
#endif

    // The planner chose a bank trip first (APEX_PLAN).
    if (tune::kPlan && plan_bank_round == round && gems >= 10) {
        force_tribute = true;
        if (tribute_if_needed()) {
            mode = "plan-bank";
            return true;
        }
        force_tribute = false;
    }
    if (best != target_group) {
        staging_since = -1;
        staging_walk_since = -1;
        my_claim_since = round;
    }
    target_group = best;
    write_claim(best);
    if (best < 0) return false;
#ifdef A3_DEBUG
    if (w.groups[best].state == GroupState::reward && bit(w.groups[best].tiles, pos)) {
        int on = 0; for (const auto& a : w.allies) on += bit(w.groups[best].tiles, a.pos);
        std::printf("A3OWN R%d me%u g%d allies_on=%d enemies=%d other_owner=%d\n", round, my_id, best, on,
            static_cast<int>(w.enemies.size()), a3_other_owner(w.groups[best]) ? 1 : 0);
    }
#endif
#ifdef A3_DEBUG
    if (w.groups[best].state == GroupState::reward && bit(w.groups[best].tiles, pos)) {
        int on = 0; for (const auto& a : w.allies) on += bit(w.groups[best].tiles, a.pos);
        std::printf("A3OWN R%d me%u g%d allies_on=%d enemies=%d other_owner=%d\n", round, my_id, best, on,
            static_cast<int>(w.enemies.size()), a3_other_owner(w.groups[best]) ? 1 : 0);
    }
#endif
    if (w.groups[best].state == GroupState::reward && bit(w.groups[best].tiles, pos) && w.enemies.empty() &&
        ((tune::kShareGold && poorer_ally_takes(w.groups[best], best, true)) || (A3_ONE_OWNER && a3_other_owner(w.groups[best])))) {
        // A poorer ally is on the region: progress continues without us and it gets the whole reward.
        avoid_until[best] = round + 8;
        best = score_groups(1, best_need, best_score);
        staging_since = -1;
        staging_walk_since = -1;
        my_claim_since = round;
        target_group = best;
        write_claim(best);
        if (best < 0) return false;
    }
    auto& g = w.groups[best];
    if (tune::kRecallTravel > 0 && g.state != GroupState::reward && w.enemies.empty() && !bit(w.hot_zone, pos) &&
        !bit(w.ally_spawn, pos) && w.has_field(best)) {
        // The target is far from us but near home: recall (5 turns, heals and shops) and walk from spawn.
        const int here = w.group_distance(best, pos);
        int from_home = kUnreach;
        for (vec2 sp : w.spawn_tiles) from_home = std::min(from_home, w.group_distance(best, sp));
        if (here != kUnreach && from_home != kUnreach && here > from_home + 5 + tune::kRecallTravel) {
            bool threat = false;
            for (const auto& sg : w.sightings) threat |= round - sg.round <= 5 && cheb(sg.pos, pos) <= 8;
            if (!threat) {
                try {
                    bc::self().recall();
                    mode = "recall-travel";
                    return true;
                } catch (const std::exception& e) {
                    LOG("recall-travel error %s\n", e.what());
                }
            }
        }
    }
    PROF_CHECK("farmmove");

    switch (g.state) {
    case GroupState::reward: {
        mode = "capture";
        if (bit(g.tiles, pos)) return true; // capturing: hold position
        mode = "to-capture";
        if (!walk_toward(g.tiles) && walk_unreachable) {
            // No walking route to the capture tiles (big-world/islands: camps on an island behind a two-tile hole
            // moat; ranged allies kill them from the shore). Holding here froze champions for the rest of the game.
            const auto gi = static_cast<std::size_t>(&g - &w.groups[0]);
            if (gi < avoid_until.size()) avoid_until[gi] = round + 300;
            return false;
        }
        return true;
    }
    case GroupState::respawning: {
        mode = "wait-respawn";
#if V54_HOLD
        // Lead lock (sole gem camp only): any occupied spawn tile delays the whole group's respawn (engine-checked:
        // a held stampede group stayed down 120 rounds against 65). With a banked lead of at least one cycle, one
        // champion with an empty bag stands on a tile; teammates wait beside it as before, so it is not alone.
        if (static_cast<int>(&g - &w.groups[0]) == sole_gem_group && round >= A2_SOLE_FROM &&
            ally_score - enemy_score >= V54_HOLD_LEAD && gems < 10 && hp >= max_hp * 0.5f) {
            const int gi = sole_gem_group;
            bool other = false;
            for (int s = 0; s < std::min(team_size, kClaimSlots); ++s)
                other |= s != slot && claim_onsite(s) && claim_cache[static_cast<std::size_t>(s)] == gi;
            if (!other) {
                mode = "hold";
                if (!bit(g.tiles, pos)) walk_toward(g.tiles);
                if (bit(g.tiles, pos)) mark_onsite(gi);
                return true;
            }
        }
#endif
        if (tune::kUseWaits) {
            const int wait = g.respawn_round - round;
            const int altar_trip = gems >= 10 && w.ensure_altar_field()
                ? 2 * static_cast<int>(fdist(w.altar_field, pos)) + (gems + 9) / 10 : 0;
            const int home_trip = std::min(2 * static_cast<int>(fdist(w.spawn_field, pos)), 12);
            if (gems >= 10 && wait > altar_trip + 2) {
                force_tribute = true;
                return tribute_if_needed();
            }
            if (gold >= 90 && !shop_done && wait > home_trip + 4 && type != bc::champion_type::tavi) {
                heading_home = true;
                return go_home_if_needed();
            }
        }
        bc::bitboard goal;
        goal.clear();
        for (int ci : g.camps) goal.draw_chebyshev(w.camps[ci].pos, static_cast<float>(range));
        goal &= ~g.tiles; // standing on a spawn tile delays the respawn
        if (bit(g.tiles, pos) || !bit(goal, pos)) walk_toward(goal);
        return true;
    }
    case GroupState::alive: {
        PROF_CHECK("f_alive");
        const bool r = fight_camps(g, best_need);
        PROF_CHECK("f_camps");
        return r;
    }
    }
    return false;
}

void Bot::opportunistic_attack() {
    auto& me = bc::self();
    if (!me.can_attack()) {
#if V58_ACT & 4
        if (!melee && walked && !cast_done) {
            bool ready = false;
            for (int s = 0; s < 2; ++s) ready |= spell_ready(s) && spells[s].kind == bc::ability_kind::attack_reset;
            if (ready) for (const auto& enemy : w.enemies)
                if (cheb(pos, enemy.pos) <= range && use_reset_and_attack(enemy.unit, enemy.pos)) return;
        }
#endif
        return;
    }
    for (const auto& e : w.enemies)
        if (cheb(e.pos, pos) <= range && attack_unit(e.unit, e.pos)) return;
}

// Wards are free and permanent: leave one at each objective we work at (a capture or an altar),
// so our vision keeps reporting camp timers and enemy carriers there after we leave.
void Bot::drop_ward() {
#if V58_VISION
    vision_objective();
#endif
    if (!tune::kWards) return;
    const bool at_objective = std::string_view(mode) == "capture" || std::string_view(mode) == "tribute" ||
        std::string_view(mode) == "siege";
    if (!at_objective) return;
    if (ward_pos.x >= 0 && cheb(ward_pos, pos) <= 10) return;
    auto& me = bc::self();
    try {
        if (me.ward_cooldown() > 0) return;
        for (int r = 0; r <= 1; ++r)
            for (int dx = -r; dx <= r; ++dx)
                for (int dy = -r; dy <= r; ++dy) {
                    const vec2 q{pos.x + dx, pos.y + dy};
                    if (!in_bounds(q, w.width, w.height) || bit(w.static_blocked, q)) continue;
                    if (me.place_ward(q)) {
                        ward_pos = q;
                        return;
                    }
                }
    } catch (const std::exception& e) {
        LOG("ward error %s\n", e.what());
    }
}

// ---------------------------------------------------------------- turn

// Precompute group distance fields with whatever fuel the turn left over. Each build's search depth
// is capped to fit (cost is predictable from the depth), so a build never runs the turn out of fuel.
void Bot::update_numbers() {
    if (num_handles[0].empty()) {
        for (const auto& c : bc::champions(team::ally)) num_handles[0].push_back(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(c)));
        for (const auto& c : bc::champions(team::enemy)) num_handles[1].push_back(static_cast<std::uint32_t>(static_cast<bc::handle_champion_t>(c)));
    }
    int n[2] = {0, 0};
    for (int s = 0; s < 2; ++s)
        for (std::uint32_t h : num_handles[s]) {
            std::int32_t alive = 1;
            d::sdk_champion_is_alive(h, &alive);
            n[s] += alive != 0;
        }
    alive_us = n[0];
    alive_them = n[1];
}

void Bot::build_fields() {
#ifdef UB_FIELDLOG
    static bool logged = false;
    if (!logged && w.fields_ready() && !w.groups.empty()) {
        logged = true;
        std::printf("FIELDSREADY R%d groups %zu\n", round, w.groups.size());
    }
#endif
    if (tune::kDet) {
        // Deterministic (APEX_DET): a fixed number of full-depth fields per turn: 2x on the first turn (it also
        // initialises), 4x on dead turns, kDetFields on calm turns, none with an enemy in view.
        const std::uint64_t full = static_cast<std::uint64_t>(w.width + w.height + 40) * field_chunks() + 3000;
        int quota = field_calls++ == 0 ? (NOVA_FUEL_FIRST ? 1000 : 2 * tune::kDetFields)
                                       : was_dead ? (NOVA_FUEL_FIRST ? 1000 : 4 * tune::kDetFields)
                                                  : w.enemies.empty() ? (NOVA_FUEL_OPEN ? 6 : tune::kDetFields)
                                                                      : 0;
        auto room = [&] {
            // NOVA_FUEL_OPEN keeps a route-search-sized reserve: the per-champion work below still
            // needs to clear the 40k route-search gate after prospecting has taken its share.
            return bc::fuel_remaining() >
                full + static_cast<std::uint64_t>(NOVA_FUEL_OPEN ? 30000 : tune::kDetSafety);
        };
        if (!w.altar_ready && quota > 0 && room()) w.ensure_altar_field(), --quota;
        if ((tune::kTerritory < 1.0f || HOME_SIDE || tune::kNumbersInvade < 99) && !w.enemy_ready && quota > 0 && room()) w.ensure_enemy_field(), --quota;
        if (!w.fields_ready() && quota > 0) w.prepare_field_order();
        while (!w.fields_ready() && quota > 0 && !w.field_order.empty() && room()) {
            PROF(field);
            if (!w.build_next_group_field(full)) return;
            PROF_CHECK("field");
            --quota;
        }
        return;
    }
    if (!w.altar_ready &&
        bc::fuel_remaining() > tune::kFieldBuildReserve + static_cast<std::uint64_t>(w.width + w.height + 40) * field_chunks())
        w.ensure_altar_field();
    if ((tune::kTerritory < 1.0f || tune::kNumbersInvade < 99) && !w.enemy_ready &&
        bc::fuel_remaining() > tune::kFieldBuildReserve + static_cast<std::uint64_t>(w.width + w.height + 40) * field_chunks())
        w.ensure_enemy_field();
    if (!w.fields_ready() && bc::fuel_remaining() > tune::kFieldBuildReserve + 15000) w.prepare_field_order();
    while (!w.fields_ready()) {
        const std::uint64_t left = bc::fuel_remaining();
        if (left < tune::kFieldBuildReserve || w.field_order.empty()) return;
        PROF(field);
        if (!w.build_next_group_field(left - tune::kFieldBuildReserve)) return;
    }
}

void Bot::play_turn() {
    PROF(turn);
#if A2_TEL
    a2tel::TurnGuard a2_guard;
#endif
#ifdef APEX_FUEL_NOISE
    {
        // Test only: burn a fixed extra amount of fuel each turn (checks how sensitive decisions are to fuel use).
        volatile std::uint32_t sink = 0;
        for (int i = 0; i < APEX_FUEL_NOISE; ++i) sink = sink + static_cast<std::uint32_t>(i);
    }
#endif
    auto& me = bc::self();
    round = static_cast<int>(bc::round_number());
    if (!inited) {
        PROF(init);
        init();
        PROF_CHECK("init");
    }
#if A2_TEL
    a2tel::who = type;

#endif
    if (APEX_BRAIN) {
        brain::load(team_size);
        brain::adapt(static_cast<int>(bc::global_submitted_gems(team::ally)),
            static_cast<int>(bc::global_submitted_gems(team::enemy)));
#if A2_RACE
        {
            // Race-state layer (Agent 2): games end at the winning gem count, and the close ones are races. Project
            // both teams' finish from their banking rate over the last 80 rounds; ahead by A2_RACE_LEAD rounds, play
            // safe and bank small bags; behind by as much, contest (more aggression, hunting). Applied on top of the
            // brain profile, which resets these knobs every turn.
            static int hist[2][64] = {};
            const int us = static_cast<int>(bc::global_submitted_gems(team::ally));
            const int them = static_cast<int>(bc::global_submitted_gems(team::enemy));
            const int slot10 = static_cast<int>(round / 10) & 63;
            hist[0][slot10] = us, hist[1][slot10] = them;
            if (round >= 120) {
                const int old = (slot10 - 8) & 63;
                const float target = static_cast<float>(bc::constants::winning_gems);
                const float ru = std::max(0.05f, static_cast<float>(us - hist[0][old]) / 80.0f);
                const float rt = std::max(0.05f, static_cast<float>(them - hist[1][old]) / 80.0f);
                float lead = (target - static_cast<float>(them)) / rt - (target - static_cast<float>(us)) / ru;
#if A2_RACE >= 2
                // Learned win probability (tools/winprob_fit.py, 138k samples of 12k pool games; held-out accuracy
                // 73.6%): the posture switches at P(win) > 0.8 (safe) and < 0.25 (contest) instead of a projected lead.
                {
                    const float z = 0.4234f + 0.6994f * static_cast<float>(us - them) / 100.0f - 0.0988f * us / 1000.0f -
                        0.1687f * them / 1000.0f + 0.0218f * (ru - rt) - 0.1711f * static_cast<float>(round) / 1000.0f;
                    const float pwin = 1.0f / (1.0f + std::exp(-z));
                    lead = pwin > 0.8f ? A2_RACE_LEAD : pwin < 0.25f ? -A2_RACE_LEAD : 0.0f;
#if A2_RACE >= 4
                    // Continuous posture (paper: press with an advantage, farm when behind): aggression scales with
                    // P(win); a likely loser also banks smaller bags. Replaces the threshold postures below.
                    tune::kAggression *= 1.0f + 0.6f * (pwin - 0.5f);
                    if (pwin < 0.35f)
                        tune::kTributeCarry = std::max(8, static_cast<int>(static_cast<float>(tune::kTributeCarry) * 0.7f + 0.5f));
                    lead = 0.0f;
#endif
                }
#endif
#if A2_RACE >= 3
                // OpenAI Five's style (paper 4.1): press with an advantage, avoid fights and farm when behind - the
                // inverse of the contest-when-behind posture above (which lost, E39).
                if (lead >= A2_RACE_LEAD) {
                    tune::kAggression *= 1.3f;
                    tune::kHunt = true;
                    mode_race = 1;
                } else if (lead <= -A2_RACE_LEAD) {
                    tune::kAggression *= 0.7f;
                    tune::kHunt = false;
                    tune::kTributeCarry = std::max(8, static_cast<int>(static_cast<float>(tune::kTributeCarry) * 0.7f + 0.5f));
                    tune::kRetreatHp = std::min(0.9f, tune::kRetreatHp + 0.05f);
                    mode_race = -1;
                } else {
                    mode_race = 0;
                }
                if (false)
#endif
                if (lead >= A2_RACE_LEAD) {
                    tune::kAggression *= 0.7f;
                    tune::kTributeCarry = std::max(8, static_cast<int>(static_cast<float>(tune::kTributeCarry) * 0.6f + 0.5f));
                    tune::kRetreatHp = std::min(0.9f, tune::kRetreatHp + 0.1f);
                    tune::kHunt = false;
                    mode_race = 1;
                } else if (lead <= -A2_RACE_LEAD) {
                    tune::kAggression *= target - static_cast<float>(them) <= 100.0f ? 1.6f : 1.35f;
                    tune::kHunt = true;
                    tune::kRetreatHp = std::max(0.1f, tune::kRetreatHp - 0.05f);
                    mode_race = -1;
                } else {
                    mode_race = 0;
                }
            }
        }
#endif
    }
    // Opening bank (APEX_EARLY_CARRY): c5 carried ~56 gems from round 50 into the mid-map fights (killers take
    // bags) and banked 3 by round 50 against the top teams' 26; bank smaller bags until APEX_EARLY_UNTIL.
    if (tune::kEarlyCarry > 0 && round < tune::kEarlyUntil) tune::kTributeCarry = std::min(tune::kTributeCarry, tune::kEarlyCarry);
    if (NOVA_GOLD_UNSEEN >= 0.0f && inited && !is_official_map()) tune::kGoldWeight = NOVA_GOLD_UNSEEN;
    if (NOVA_LATE_CARRY < 1.0f && round >= NOVA_LATE_CARRY_R)
        tune::kTributeCarry = std::max(8, static_cast<int>(static_cast<float>(tune::kTributeCarry) * NOVA_LATE_CARRY + 0.5f));
#if LADDER_TABLES
    // Per-map strategy profile (research/v71): the pool map is recognised once, on the first initialised turn.
    if (!v71_done_ && inited) {
        v71_done_ = true;
        std::uint32_t total_gems = 0;
        for (const auto& gr : w.groups) total_gems += gr.gems;
        const int n_groups = static_cast<int>(w.groups.size());
        struct KnobSet { int index; float value; };
        struct MapRow { int w, h, groups; std::uint32_t gems; int first, count; };
        static constexpr KnobSet kSets[] = {
            {0, 1.2175f},
            {22, 0.944f},
            {23, 1.2943f},
            {43, 0.6418f},
            {4, -1.8362f},
            {36, 0.899f},
            {37, -0.9017f},
            {0, -0.7825f},
            {1, 0.8715f},
            {3, 1.7757f},
            {22, -1.056f},
            {23, -0.7057f},
            {43, -1.3582f},
            {8, -0.1083f},
            {8, 2.8917f},
            {11, 3.3947f},
            {38, -0.8763f},
            {41, 1.2595f},
            {4, 1.1638f},
            {36, -1.601f},
            {5, 0.8612f},
            {6, -0.9976f},
            {7, 1.0269f},
            {13, -1.1724f},
            {44, 1.0254f},
            {40, 2.6259f},
            {40, -1.3741f},
            {23, 1.2943f},
            {32, -1.1939f},
            {23, 2.2943f},
            {32, -2.6939f},
            {24, -0.9936f},
            {25, 1.3635f},
            {31, 1.1874f},
            {0, 0.7175f},
            {22, 0.444f},
            {23, 0.7943f},
            {0, -0.2825f},
            {3, 0.7757f},
            {22, -0.556f},
            {23, -0.2057f},
            {41, 2.2595f},
        };
        static constexpr MapRow kRows[] = {
            {100, 100, 12, 270u, 41, 1}, // 00ambush: teamfight
            {37, 31, 13, 258u, 26, 1}, // 00anvil: nomid
            {29, 29, 34, 154u, 15, 3}, // 00breadcrumbs: group
            {41, 41, 20, 280u, 26, 1}, // 00collision: nomid
            {50, 50, 14, 400u, 26, 1}, // 00contest: nomid
            {61, 61, 6, 158u, 13, 1}, // 00crater: gems
            {41, 30, 8, 230u, 15, 3}, // 00eight: group
            {30, 30, 6, 68u, 31, 3}, // 00fragment: search
            {93, 93, 9, 113u, 41, 1}, // 00galaxy: teamfight
            {50, 40, 18, 364u, 25, 1}, // 00gem-fields: mid
            {30, 30, 19, 200u, 14, 1}, // 00gemfight: gold
            {50, 40, 17, 1404u, 37, 4}, // 00great-wall: softcaut
            {40, 40, 14, 200u, 4, 3}, // 00interlock: bank
            {35, 31, 34, 592u, 13, 1}, // 00lost-world: gems
            {35, 29, 14, 114u, 26, 1}, // 00quarry: nomid
            {40, 40, 51, 1158u, 4, 3}, // 00road-of-riches: bank
            {30, 80, 18, 258u, 25, 1}, // 00rushbait-v2: mid
            {45, 30, 22, 638u, 37, 4}, // 00swirl: softcaut
            {31, 31, 7, 359u, 0, 4}, // 00vault: aggr
            {50, 41, 31, 1180u, 27, 2}, // 01boss-battle: ranged
            {61, 61, 11, 177u, 25, 1}, // 01concentrated-wealth: mid
            {51, 40, 12, 752u, 15, 3}, // 01corridors: group
            {50, 50, 29, 72u, 7, 6}, // 01elk-arena: caut
            {31, 31, 12, 88u, 14, 1}, // 01hooks: gold
            {60, 60, 46, 608u, 26, 1}, // 01islands: nomid
            {40, 40, 21, 990u, 41, 1}, // 01shortcut: teamfight
            {50, 50, 16, 334u, 26, 1}, // 01starfish: nomid
            {80, 80, 14, 532u, 13, 1}, // 01starvation: gems
            {50, 40, 28, 1096u, 14, 1}, // 01the-farm: gold
            {40, 30, 28, 472u, 26, 1}, // 01yellow-brick-road: nomid
            {30, 30, 14, 102u, 15, 3}, // 02arena: group
            {51, 51, 24, 458u, 13, 1}, // 02crossing: gems
            {51, 51, 22, 1038u, 14, 1}, // 02fields: gold
            {45, 45, 11, 404u, 14, 1}, // 02gift-wrapping: gold
            {41, 41, 22, 688u, 14, 1}, // 02guardians: gold
            {30, 30, 15, 452u, 20, 5}, // 02stalactites: hunt
            {45, 45, 35, 388u, 18, 2}, // 02the-pack: hoard
            {30, 30, 20, 148u, 27, 2}, // 02the-pond: ranged
            {35, 35, 34, 449u, 26, 1}, // 02treasure-box: nomid
            {50, 46, 20, 732u, 29, 2}, // 02uncharted-lands: ranged2
            {31, 31, 6, 126u, 15, 3}, // adgato-gemcombat1: group
            {51, 31, 9, 168u, 27, 2}, // adgato-gemcombat2: ranged
            {51, 51, 10, 308u, 34, 3}, // adgato-gemcombat3: softaggr
            {41, 61, 8, 252u, 37, 4}, // adgato-gemcombat4: softcaut
            {99, 99, 24, 735u, 25, 1}, // adgato-gemcombat5: mid
        };
        for (const auto& r : kRows)
            if (r.w == w.width && r.h == w.height && r.groups == n_groups && r.gems == total_gems) {
                for (int k = 0; k < r.count; ++k) lab::knobs[kSets[r.first + k].index] = kSets[r.first + k].value;
                ladder_known = true;
                break;
            }
    }
#endif
#if A2_LAB
    {
        // Engine-lab joint search (lab.h knobs, agent2/lab/knob_es.js); all zero = this build's own play. Knobs the
        // brain resets every turn scale the current value; the others are set from their first-turn values.
        static bool based = false;
        static int b_hunt_range = 0, b_hunt_gems = 0, b_chase = 0, b_stage = 0;
        static float b_hunt_hp = 0, b_wait = 0, b_need = 0, b_dhp = 0;
        if (!based) {
            based = true;
            b_hunt_range = tune::kHuntRange, b_hunt_gems = tune::kHuntGems, b_chase = tune::kChaseRange, b_stage = tune::kStageTimeout;
            b_hunt_hp = tune::kHuntHp, b_wait = tune::kWaitWeight, b_need = tune::kNeedPool, b_dhp = tune::kDangerHp;
        }
        const float* k = lab::knobs;
        auto ri = [](float v) { return static_cast<int>(std::lround(v)); };
        tune::kAggression *= std::exp(0.3f * k[0]);
        tune::kRetreatHp = std::clamp(tune::kRetreatHp + 0.1f * k[1], 0.05f, 0.95f);
        tune::kDangerTtd *= std::exp(0.3f * k[2]);
        tune::kDangerHp = std::clamp(b_dhp + 0.05f * k[3], 0.0f, 0.9f);
        tune::kTributeCarry = std::max(8, ri(static_cast<float>(tune::kTributeCarry) * std::exp(0.3f * k[4])));
        tune::kHuntRange = std::max(0, b_hunt_range + ri(3.0f * k[5]));
        tune::kHuntHp = std::clamp(b_hunt_hp + 0.1f * k[6], 0.1f, 1.0f);
        tune::kChaseRange = std::max(0, b_chase + ri(2.0f * k[7]));
        tune::kGoldWeight *= std::exp(0.4f * k[8]);
        tune::kWaitWeight = b_wait * std::exp(0.4f * k[9]);
        tune::kNeedPool = b_need * std::exp(0.3f * k[10]);
        tune::kCohesion = std::max(0.0f, tune::kCohesion + 0.05f * k[11]);
        tune::kShopGold = std::max(30, tune::kShopGold + ri(30.0f * k[12]));
        tune::kHuntGems = std::max(0, b_hunt_gems + ri(5.0f * k[13]));
        tune::kStageTimeout = std::max(1, b_stage + ri(3.0f * k[14]));
        if (k[15] > 1.0f) tune::kHunt = true;
        else if (k[15] < -1.0f) tune::kHunt = false;
        tune::kAggression *= std::exp(0.3f * (range > 1 ? k[23] : k[22])); // melee / ranged aggression
        // 43-44: the early game (before round 250; the kill leader at round 200 wins 68% of mirror games): aggression
        // x exp(0.3k) and hunt range + 3k.
        if (round < 250) {
            tune::kAggression *= std::exp(0.3f * k[43]);
            tune::kHuntRange = std::max(0, tune::kHuntRange + ri(3.0f * k[44]));
        }
        // 33-34: bag size before banking for Marcella (+2 gold per tributed gem) and Prism (Focus per carried gem).
        if (type == bc::champion_type::marcella) tune::kTributeCarry = std::max(8, ri(static_cast<float>(tune::kTributeCarry) * std::exp(0.3f * k[33])));
        if (type == bc::champion_type::prism) tune::kTributeCarry = std::max(8, ri(static_cast<float>(tune::kTributeCarry) * std::exp(0.3f * k[34])));
    }
#endif
#if HOME_SIDE
    // HOME_SIDE (win search, 28 Oct): our own half first. From replays of 262 lost games branched at rounds 150-800,
    // this switch turned the most losses into wins; on 400 untouched random maps vs the ext bot it won 501/800 against
    // v72's 436/800, with a third fewer deaths. Enemy-side camp groups are worth HOME_TERR of their value and champion
    // fights are taken with HOME_AGGR of the aggression.
    if (!(ladder_known && !LADDER_HOME)) {
    tune::kTerritory = HOME_TERR;
    tune::kAggression *= HOME_AGGR;
    }
    if (SCARCE_CAMPS > 0 && inited && static_cast<int>(w.groups.size()) <= 2 * SCARCE_CAMPS)
        tune::kTerritory = SCARCE_TERR, tune::kAggression *= SCARCE_AGGR / HOME_AGGR; // scarce map: no home side
#endif
#if X1_PLAN
    {
        // X1_PLAN team plans (research/x1/PLAN_TWO_MACHINES.md, port of v76p's PLAN_ROUND / PLAN_ID): from
        // X1_PLAN_ROUND on, the whole team plays plan X1_PLAN_ID on top of the knobs set above. The two values are read
        // through volatile so every branch build runs the same instructions and its games equal the base build's until
        // the switch round (the branch farm relies on this). X1_PLAN_ROUND -1 or 5000: never switch.
        static volatile int plan_round = X1_PLAN_ROUND, plan_id = X1_PLAN_ID;
        const int pr = plan_round;
        #if X3_PLAN_END
        static volatile int plan_end = X3_PLAN_END;
        const int plan = economic_cycle::plan_active(round, pr, plan_end) ? plan_id : 0;
#else
        const int plan = pr >= 0 && round >= pr ? plan_id : 0;
#endif
#if X3_TRACE
        static int previous_plan = -1;
        if (previous_plan != plan) {
            std::printf("X3_PLAN R%d slot%d plan%d\n", round, slot, plan);
            previous_plan = plan;
        }
#endif
        float terr = tune::kTerritory, aggr = 1.0f, carry = 1.0f;
        int hunt = 0;
        if (plan == 1) terr = 1.0f;                                     // full map: enemy-side camps at full value
        else if (plan == 2) carry = 1.6f;                               // hoard: bigger bags, fewer bank trips
        else if (plan == 3) aggr = 1.25f;                               // fight harder
        else if (plan == 4) terr = 0.0f, aggr = 0.65f;                  // turtle: own half only, avoid fights
        else if (plan == 5) terr = 0.15f;                               // stricter home
        else if (plan == 6) terr = 0.0f, aggr = 0.8f, carry = 0.7f, hunt = -99; // early-contact answer: stay home, bank small and often, no hunting
        else if (plan == 7) carry = 0.6f;                               // fast bank: small bags, finish the race early
        else if (plan == 8) terr = 1.0f, aggr = 1.3f, hunt = 3;         // push: invade, fight, hunt further
        tune::kTerritory = terr;
        tune::kAggression *= aggr;
        if (carry != 1.0f) tune::kTributeCarry = std::max(8, static_cast<int>(static_cast<float>(tune::kTributeCarry) * carry + 0.5f));
        // The hunt range is not reset each turn (unlike the scaled knobs above), so offset it from its first value.
        static int base_hunt = -1;
        if (base_hunt < 0) base_hunt = tune::kHuntRange;
        #if X3_PLAN_END
        tune::kHuntRange = std::max(0, base_hunt + hunt);
#else
        if (hunt) tune::kHuntRange = std::max(0, base_hunt + hunt);
#endif
    }
#endif
    if (FIRST_SAFE && inited && !fs_team_died) {
        if (num_handles[0].empty()) update_numbers();
        for (std::uint32_t h : num_handles[0]) {
            std::int32_t alive = 1;
            d::sdk_champion_is_alive(h, &alive);
            if (!alive) fs_team_died = true;
        }
        if (!fs_team_died) tune::kDangerTtd *= FS_TTD, tune::kRetreatHp = std::min(0.95f, tune::kRetreatHp + FS_RET);
    }
#if X1_ANTIFEED
    if (inited) {
        // X1_ANTIFEED (top-team games, research/x1/TOP_TEAMS_2026-11-02.md: in 9 of 35 games we died 23-48 times with
        // almost no kills and banked < 100). Count team deaths (an ally seen alive, then dead); with X1_ANTIFEED or more
        // in the last X1_ANTIFEED_WIN rounds the whole team plays safe: own half, less aggression, earlier retreat,
        // more weight on danger. Only knobs that are reset every turn are scaled, so nothing compounds.
        static std::uint32_t seen[8] = {};
        static bool was_alive[8] = {};
        static int death_round[16] = {};
        static int n_deaths = 0;
        if (num_handles[0].empty()) update_numbers();
        int k = 0;
        for (std::uint32_t h : num_handles[0]) {
            if (k >= 8) break;
            std::int32_t alive = 1;
            d::sdk_champion_is_alive(h, &alive);
            if (seen[k] != h) seen[k] = h, was_alive[k] = alive != 0;
            else {
                if (was_alive[k] && !alive) death_round[n_deaths++ % 16] = round;
                was_alive[k] = alive != 0;
            }
            ++k;
        }
        int recent = 0;
        for (int i = 0; i < std::min(n_deaths, 16); ++i) recent += round - death_round[i] <= X1_ANTIFEED_WIN;
        if (recent >= X1_ANTIFEED) {
            tune::kTerritory = 0.0f;
            tune::kAggression *= 0.6f;
            tune::kRetreatHp = std::min(0.95f, tune::kRetreatHp + 0.15f);
            tune::kDangerTtd *= 1.3f;
        }
    }
#endif
#if X1_TEAMWIN
    if (inited) {
        // X1_TEAMWIN (audit F03: cuts ended 859 banked + 170 carried vs 1083; no single bag reached 1000, so win_now never
        // fired). Sum every live ally's bag so each carrier banks once the team's bags finish the race.
        if (num_handles[0].empty()) update_numbers();
        int carry = 0;
        for (std::uint32_t h : num_handles[0]) {
            std::int32_t alive = 1;
            d::sdk_champion_is_alive(h, &alive);
            std::uint32_t g = 0;
            if (alive && d::sdk_champion_gems(h, &g) == 0) carry += static_cast<int>(g);
        }
        team_carry = std::max(carry, gems);
    }
#endif
#if X1_BAGRISK
    {
        // X1_BAGRISK (x1 audit loss cases: single deaths lost bags of 85-154 gems; showdown, gemcombat3 and fan lost
        // 308-531 carried gems a game). With X1_BAGRISK or more gems and an enemy seen within 10 in the last 5 rounds,
        // the bank threshold drops to the bag in hand, so the carrier banks now instead of farming on.
        if (gems >= X1_BAGRISK) {
            bool near = false;
            for (const auto& e : w.enemies) near |= cheb(e.pos, pos) <= 10;
            for (const auto& sg : w.sightings) near |= round - sg.round <= 5 && cheb(sg.pos, pos) <= 10;
            if (near) tune::kTributeCarry = std::min(tune::kTributeCarry, gems);
        }
    }
#endif
    tune::kShopGold = std::max(30, static_cast<int>(static_cast<float>(tune::kShopGold) * GT_SHOP));
    tune::kNeedPool *= DEATH_NEED;
#if X1_ECON
    // X1_ECON (audit F02 + top-team games: collection explains 68% of the loss deficit; top teams earn ~2x our gold by
    // R500; dunes R431-471 had our five champions waiting / staging while the enemy collected 177). Per-turn multipliers
    // on the respawn-wait cost, the helper staging timeout and the solo camp health budget (all reset every turn).
    tune::kWaitWeight *= X1_WAIT_MULT;
    tune::kStageTimeout = std::max(1, static_cast<int>(static_cast<float>(tune::kStageTimeout) * X1_STAGE_MULT + 0.5f));
    tune::kNeedPool *= X1_NEED_MULT;
#endif
    tune::kRetreatHp = std::min(0.95f, tune::kRetreatHp + DEATH_RETREAT);
    tune::kDangerTtd *= DEATH_TTD;
    cast_done = false;
    keep_channel = false;
    walked = false;
    force_tribute = false;
#if A2_LAB
    {
        // Engine lab intervention (lab.h): record the current choice, then forbid it / force or hold the bank trip.
        const auto me_id = static_cast<std::int32_t>(my_id);
        const int lk = lab::ctl.kind < 0 ? -lab::ctl.kind : lab::ctl.kind;
        const bool calm = w.enemies.empty() && !heading_home;
        // forbid: farming calmly; bank now: a small bag the bot would keep carrying; hold: a bag the bot banks soon.
        const bool cond = lk == 1 ? (target_group >= 0 && calm && hp > 0.5f * max_hp) : lk == 2 ? (gems >= 8 && gems < 20 && calm) : lk == 3 ? (gems >= 20 && calm) : false; // 4/5: handle_enemies
        if (lab::ctl.champ == me_id && round >= lab::ctl.round && !lab::macro_done) {
            // Macro what-ifs: what this champion sees at the decision point (agent2/lab/exit_lab.js, macro_fit.py).
            lab::macro_done = true;
            float* f = lab::macro_feat;
            int allies6 = 0, near_ally = 99, recent = 0;
            for (const auto& a : w.allies) {
                const int d = cheb(a.pos, pos);
                allies6 += d <= 6, near_ally = std::min(near_ally, d);
            }
            for (const auto& sg : w.sightings) recent += round - sg.round <= 15 && cheb(sg.pos, pos) <= 15;
            const bool tg = target_group >= 0 && static_cast<std::size_t>(target_group) < w.groups.size();
            const int tdist = tg && w.has_field(target_group) ? w.group_distance(target_group, pos) : 40;
            const float us_b = static_cast<float>(bc::global_submitted_gems(team::ally)), them_b = static_cast<float>(bc::global_submitted_gems(team::enemy));
            f[0] = hp / std::max(1.0f, max_hp), f[1] = gems / 50.0f, f[2] = gold / 300.0f, f[3] = std::min(tdist, 40) / 20.0f;
            f[4] = tg ? w.groups[static_cast<std::size_t>(target_group)].gems / 50.0f : 0.0f;
            f[5] = tg && w.groups[static_cast<std::size_t>(target_group)].state == GroupState::reward;
            f[6] = static_cast<float>(allies6), f[7] = std::min(near_ally, 40) / 20.0f, f[8] = static_cast<float>(w.enemies.size());
            f[9] = static_cast<float>(recent), f[10] = round / 2000.0f, f[11] = (us_b - them_b) / 500.0f, f[12] = us_b / 1000.0f, f[13] = them_b / 1000.0f;
            f[14] = w.altar_ready ? std::min<float>(fdist(w.altar_field, pos), 60.0f) / 30.0f : 2.0f;
            f[15] = std::min<float>(fdist(w.spawn_field, pos), 60.0f) / 30.0f, f[16] = range > 1, f[17] = team_size / 5.0f;
            f[18] = gems / static_cast<float>(std::max(1, tune::kTributeCarry)), f[19] = 1.0f;
            f[lab::kMacroF] = static_cast<float>(round);
        }
        if (lab::ctl.champ == me_id && round >= lab::ctl.round && lab::ctl.rec_round == -2 && cond) {
            lab::ctl.rec_round = round;
            lab::ctl.rec_target = target_group;
            lab::ctl.rec_gems = gems;
            lab::ctl.rec_hp = static_cast<std::int32_t>(100.0f * hp / std::max(1.0f, max_hp));
            lab::ctl.rec_dist = target_group >= 0 && w.has_field(target_group) ? w.group_distance(target_group, pos) : -1;
            if (lab::ctl.kind == 1 && target_group >= 0 && static_cast<std::size_t>(target_group) < avoid_until.size())
                avoid_until[static_cast<std::size_t>(target_group)] = round + lab::ctl.len;
        } else if (lab::ctl.champ == me_id && lab::ctl.rec_round >= 0 && lab::ctl.rec_after == -2 && round > lab::ctl.rec_round) {
            lab::ctl.rec_after = target_group; // what it chose instead (or kept)
        }
        if (lab::active(me_id, round, 2) && gems > 0) force_tribute = true;
    }
#endif
    shared = read_shared();
    decode_claims();
#if V54_ONSITE
    if (inited && claim_onsite(slot)) {
        // Our on-site mark is stale once we have left the group (home trip, flight, death): clear it.
        const int gi = claim_cache[static_cast<std::size_t>(slot)];
        bool near = false;
        if (gi >= 0 && static_cast<std::size_t>(gi) < w.groups.size())
            for (int ci : w.groups[static_cast<std::size_t>(gi)].camps) near |= cheb(w.camps[ci].pos, pos) <= 5;
        if (!near) unmark_onsite();
    }
#endif
    if (tune::kIncumbent && inited) track_claims();

    const auto state = me.state();
    if (state.is_dead() && !was_dead) {
        // One line per death: what we were doing and what we could see.
        LOG("DEATH R%d %s at(%d,%d) gems%d mode=%s G%d enemies=%zu nearest=%d hpPrev=%.0f\n", round,
            bc::to_string(type).c_str(), pos.x, pos.y, gems, mode, target_group, w.enemies.size(), last_enemy_dist, hp);
        if (APEX_DEATHLOG) {
            std::printf("DEATH R%d %s gems%d\n", round, bc::to_string(type).c_str(), gems);
            for (int k = 0; k < 4; ++k) {
                const auto& n = notes[(note_i + k) & 3];
                if (n.round == 0) continue;
                std::printf("  R%d %s p(%d,%d) hp%d/%d g%d mode=%s G%d enemies=%d near=%d ehp=%d allies4=%d spawn=%d\n",
                    n.round, bc::to_string(type).c_str(), n.pos.x, n.pos.y, n.hp, n.max_hp, n.gems, n.mode, n.target,
                    n.enemies, n.near_enemy, n.enemy_hp, n.allies_near, n.spawn_dist);
            }
        }
    }
#ifdef APEX_FIGHTLOG
    if (state.is_dead() && !was_dead) std::printf("DIED R%d %s\n", round, bc::to_string(type).c_str());
#endif
#if A2_MICLOG
    if (state.is_dead() && !was_dead) std::printf("MD %d %d %d %d %d\n", round, slot, static_cast<int>(type), gems, last_enemy_dist);
#endif
    was_dead = state.is_dead();
    debug_block({
        if (state.is_dead()) {
            std::printf("P %d %u -1 -1 0 0 0\n", round, static_cast<unsigned>(static_cast<bc::handle_champion_t>(me)));
        } else {
            const auto p = me.position();
            std::printf("P %d %u %d %d %.0f %.0f %u\n", round, static_cast<unsigned>(static_cast<bc::handle_champion_t>(me)), p.x, p.y,
                me.health(), me.max_health(), me.gem_count());
        }
    });
    if (state.is_dead()) {
        episode_tick(true);
#ifdef APEX_TSTRACE
        if (!ts_dead_logged && (ts_dead_logged = true))
            for (int k = 0; k < 2; ++k) {
                const std::string& t = ts_trace[(ts_trace_i + k) & 1];
                if (!t.empty()) std::printf("DIED R%d after %s\n", round, t.c_str());
            }
#endif
        gold = static_cast<int>(me.gold_count());
        type = me.champion_name();
        shop();
        refresh_emblems();
        heading_home = false;
        if (inited && target_group != kClaimDead) {
            target_group = kClaimDead;
            write_claim(kClaimDead);
        }
        // Dead turns have the whole budget free: use it to precompute distance fields.
        if (inited) build_fields();
        return;
    }
    {
        PROF(refresh);
        refresh_self();
    }
#if A2_MICLOG
    mic_can_attack0 = me.can_attack();
#endif
    PROF_CHECK("refresh");
    // A recall started before a capture landed: if the bag now finishes the race, walk to an altar instead.
    if (state.contains(bc::champion_state::recalling) && win_now() && hp >= max_hp * tune::kDangerHp) {
        try {
            me.cancel_recall();
        } catch (const std::exception& e) {
            LOG("cancel recall error %s\n", e.what());
        }
    } else if (state.contains(bc::champion_state::recalling) || state.contains(bc::champion_state::submitting_gems) ||
        state.contains(bc::champion_state::teleporting)) {
        // Channel guard (APEX_CHANNEL_GUARD, from apex_v22): a channel used to end our turn unseen, and a quarter
        // of the deaths came mid-tribute or mid-recall with the whole bag. Cancel when the enemies in reach kill
        // us before the channel ends, and play the turn instead.
        if (tune::kChannelGuard <= 0.0f || state.contains(bc::champion_state::teleporting)) return;
        w.update(round);
        std::int32_t left = 0;
        d::sdk_champion_channel_time(my_id, &left);
        float incoming = 0.0f;
        for (const auto& e : w.enemies)
            if (cheb(e.pos, pos) <= e.range + 2) incoming += e.strength + e.focus * 0.5f;
        if (incoming * static_cast<float>(left + 1) * tune::kChannelGuard < hp) return;
#if A2_HIDEREC
        // A2_HIDEREC: a recall from a bush no enemy can see into (no visible enemy in our cluster, no known ward on it)
        // cannot be hit, so it is not cancelled. Without this the bush recall (started because we are hidden) and this
        // guard alternate every turn while an enemy waits outside: the champion stands for 10+ turns, neither
        // recalling nor leaving (lab logs: 77% of bush recalls were cancelled on the next turn).
        if (state.contains(bc::champion_state::recalling) && hidden_here()) return;
#endif
        try {
            if (state.contains(bc::champion_state::submitting_gems)) me.cancel_submit_gems();
            else me.cancel_recall();
        } catch (const std::exception& e) {
            LOG("channel cancel error %s\n", e.what());
            return;
        }
    }

    {
        PROF(world);
        w.update(round);
        PROF_CHECK("w_update");
#if A2_BELIEF
        for (const auto& e : w.enemies)
            if (e.hp > 0) a2bel::note(e.id, e.pos.x, e.pos.y, round, e.range, e.strength, e.hp);
#endif
        if (tune::kBelief) w.update_beliefs(round, tune::kDet ? static_cast<std::uint64_t>(tune::kDetSafety) : 40000);
#if A2_LAB
        {
            // Engine lab, death what-ifs (lab.h kinds 6 / 7; start at ctl.round unconditionally): 6 regroup = walk to the
            // nearest living ally, playing normally once within 2 tiles; 7 home = walk to our spawn.
            const auto me_id = static_cast<std::int32_t>(my_id);
            const int lk = lab::ctl.kind < 0 ? -lab::ctl.kind : lab::ctl.kind;
            if (lab::ctl.champ == me_id && (lk == 6 || lk == 7) && round >= lab::ctl.round && lab::ctl.rec_round == -2) {
                lab::ctl.rec_round = round;
                lab::ctl.rec_gems = gems;
                lab::ctl.rec_hp = static_cast<std::int32_t>(100.0f * hp / std::max(1.0f, max_hp));
            }
            if (lab::active(me_id, round, 6)) {
                int best = 99;
                vec2 at{};
                for (const auto& a : w.allies)
                    if (a.hp > 0 && cheb(a.pos, pos) < best) best = cheb(a.pos, pos), at = a.pos;
                if (best < 99 && best > 2) {
                    bc::bitboard goal;
                    goal.clear();
                    set_bit(goal, at);
                    mode = "lab-regroup";
                    walk_toward(goal);
                    return;
                }
            }
            if (lab::active(me_id, round, 7) && !bit(w.ally_spawn, pos)) {
                mode = "lab-home";
                walk_toward(w.ally_spawn);
                return;
            }
        }
#endif
#if A2_AMBUSH
        // Altar ambush (exploit candidate): one champion waits beside the altar nearest the enemy spawn, where their
        // carriers bank; with enemies in sight it plays the normal fight / tribute-denial logic.
        if (slot == A2_AMBUSH_SLOT % std::max(1, team_size) && round >= A2_AMBUSH_FROM && w.enemies.empty() &&
            hp > 0.6f * max_hp && gems < 10 && !w.altars.empty()) {
            static vec2 post{-1, -1};
            if (post.x < 0) {
                int sx = 0, sy = 0, sn = 0;
                for (int y = 0; y < w.height; ++y)
                    for (int x = 0; x < w.width; ++x)
                        if (bit(w.enemy_spawn, vec2{x, y})) sx += x, sy += y, ++sn;
                const vec2 es{sn ? sx / sn : w.width / 2, sn ? sy / sn : w.height / 2};
                post = w.altars[0];
                for (const vec2 a : w.altars)
                    if (cheb(a, es) < cheb(post, es)) post = a;
            }
            if (cheb(pos, post) > 2) {
                bc::bitboard goal;
                goal.clear();
                for (int dy = -2; dy <= 2; ++dy)
                    for (int dx = -2; dx <= 2; ++dx) {
                        const vec2 q{post.x + dx, post.y + dy};
                        if (q.x >= 0 && q.y >= 0 && q.x < w.width && q.y < w.height && !bit(w.static_blocked, q)) set_bit(goal, q);
                    }
                mode = "ambush-walk";
                walk_toward(goal);
            } else {
                mode = "ambush-wait";
            }
            return;
        }
#endif
#ifdef APEX_BELIEFLOG
        if (tune::kBelief && slot == 0 && round % 20 == 0) {
            std::printf("BEL R%d p(%d,%d) seen %zu:", round, pos.x, pos.y, w.enemies.size());
            for (const auto& b : w.beliefs) std::printf(" %u/%d", b.area, b.alive ? 1 : 0);
            std::printf(" | E(here,6)=%.2f E(here,12)=%.2f\n", w.expected_enemies(pos, 6), w.expected_enemies(pos, 12));
        }
#endif
    }
    last_enemy_dist = 99;
    for (const auto& e : w.enemies) last_enemy_dist = std::min(last_enemy_dist, cheb(e.pos, pos));
    if (NOVA_ALTAR_INFER && prev_enemy_score >= 0 && enemy_score > prev_enemy_score) {
        // Someone just banked. If no visible enemy stands by a visible altar, the banker is at an unseen one.
        bool seen_banker = false;
        for (vec2 a : w.altars)
            for (const auto& e : w.enemies) seen_banker |= cheb(e.pos, a) <= bc::constants::submit_gems_range + 1;
        if (!seen_banker)
            for (vec2 a : w.altars)
                if (!bit(w.visible, a)) w.add_sighting(a, round - 1);
    }
    prev_enemy_score = enemy_score;
    if (tune::kOppModel) update_opp_model();
    if (tune::kNumbers != 0.0f || tune::kNumbersInvade < 99) {
        update_numbers();
        if (APEX_BRAIN && tune::kNumbers != 0.0f) // adapt() resets the aggression every turn
            tune::kAggression *= std::clamp(1.0f + tune::kNumbers * static_cast<float>(alive_us - alive_them), 0.6f, 1.6f);
    }
#ifdef APEX_OPPLOG
    if (tune::kOppModel && round % 100 == 0)
        std::printf("OPP R%d slot%d obs %d/%d %d/%d %d/%d %d/%d %d/%d est %.2f\n", round, slot, opp_ret[0], opp_obs[0], opp_ret[1],
            opp_obs[1], opp_ret[2], opp_obs[2], opp_ret[3], opp_obs[3], opp_ret[4], opp_obs[4], opp_flee_estimate());
#endif
    PROF_CHECK("world");
    episode_tick(false);
    PROF_CHECK("episode");
#ifdef APEX_EARLYLOG
    if (round == 50 || round == 100 || round == 150) std::printf("EARLY R%d %s carry %d score %d gold %d maxhp %.0f\n", round, bc::to_string(type).c_str(), gems, ally_score, gold, max_hp);
#endif
#ifdef APEX_TSTRACE
    ts_dead_logged = false;
#endif
#ifdef APEX_CHECK_VISION
    if (round % 7 == 3) {
        bc::bitboard mine;
        w.vision_from(pos, mine);
        const auto a = (mine & ~w.visible).positions().size(), b = (w.visible & ~mine).positions().size();
        std::printf("VISCHECK R%d p(%d,%d) bush%d extra%zu missing%zu\n", round, pos.x, pos.y, w.bush_cluster(pos) >= 0, a, b);
        if (w.bush_cluster(pos) >= 0) {
            // H2: everything opaque (all bushes), then add own cluster.
            bc::bitboard own, h2, h3;
            w.cluster_board(pos, own);
            bc::bitboard opaque = bc::map::walls() | w.bushes;
            opaque.shadow_cast_into(pos, 8, h2);
            h2 &= ~(w.bushes & ~own);
            h2 |= own;
            // H3: own cluster transparent but its tiles hidden beyond radius; 4-connected cluster.
            bc::bitboard own4;
            own4.clear();
            {
                std::vector<vec2> st{pos};
                set_bit(own4, pos);
                const vec2 d4[4] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                while (!st.empty()) {
                    vec2 c = st.back();
                    st.pop_back();
                    for (vec2 d : d4) {
                        vec2 q = c + d;
                        if (q.x < 0 || q.y < 0 || q.x >= w.width || q.y >= w.height || !bit(w.bushes, q) || bit(own4, q)) continue;
                        set_bit(own4, q);
                        st.push_back(q);
                    }
                }
            }
            bc::bitboard op3 = (bc::map::walls() | w.bushes) & ~own4;
            op3.shadow_cast_into(pos, 8, h3);
            h3 &= ~(w.bushes & ~own4);
            h3 |= own4;
            std::printf("VISBUSH R%d engine%zu mine%zu own8_%zu own4_%zu | H2 extra%zu missing%zu | H3 extra%zu missing%zu\n", round,
                w.visible.positions().size(), mine.positions().size(), own.positions().size(), own4.positions().size(),
                (h2 & ~w.visible).positions().size(), (w.visible & ~h2).positions().size(),
                (h3 & ~w.visible).positions().size(), (w.visible & ~h3).positions().size());
        }
    }
#endif
    if (!NOVA_NO_SIGHT) {
        read_sighting();
        share_sighting();
    }
    PROF_CHECK("sight");
#if APEX_EVENTS && (X3_TEAM < 4 || X3_TEAM >= 10)
    // No enemy in view: publish a newly learned respawn timer, unless a fresh sighting would be lost.
    if (w.enemies.empty() && !w.pending_events.empty()) {
        std::uint64_t v = read_shared();
        bool fresh_sighting = false;
        if (!((v >> 63) & 1) && (v >> kSightX) != 0) {
            int age = (round & kSightRoundMask) - static_cast<int>((v >> kSightRound) & kSightRoundMask);
            if (age < 0) age += kSightRoundMask + 1;
            fresh_sighting = age <= (APEX_EVENTS >= 2 ? 11 : 4); // v2: never overwrite a sighting teammates still use (<= 10)
        }
        if (!fresh_sighting) {
            const int gi = w.pending_events.back();
            w.pending_events.pop_back();
            if (gi < 127) {
                v &= (std::uint64_t{1} << kSightX) - 1;
                v |= static_cast<std::uint64_t>(gi) << kSightX;
                v |= static_cast<std::uint64_t>(w.groups[static_cast<std::size_t>(gi)].respawn_round & 255) << kSightY;
                v |= std::uint64_t{1} << 63;
                bc::shared_memory.write(0, std::span<std::uint64_t, 1>{&v, 1});
                shared = v;
                decode_claims();
            }
        }
    }
    if (w.pending_events.size() > 8) w.pending_events.erase(w.pending_events.begin());
#endif
    PROF_CHECK("events");
    if (bit(w.ally_spawn, pos) || type == bc::champion_type::tavi) {
        shop();
        refresh_emblems();
    }
    PROF_CHECK("shop");


    support_casts();
    PROF_CHECK("support");
    mode = "idle";
    if (ward_reveal()) w.update(round); // the ward shows the bush now: look again
    PROF_CHECK("wardrev");
    if (counter_ambush()) {
        // We moved (into the attacker's bush, or away from it): look again before deciding.
        w.update(round);
    }
    PROF_CHECK("ambush");
#if A2_FIELDFIRST
    // Group fields first (A2_FIELDFIRST): built from the turn's leftover fuel they never arrived on big maps full of
    // holes (islands: 14 of 46 by round 250), and straight-line distances sent champions at camps they cannot reach.
    if (inited && tune::kDet && !w.fields_ready() && w.enemies.empty()) {
        const std::uint64_t full = static_cast<std::uint64_t>(w.width + w.height + 40) * field_chunks() + 3000;
        if (!w.altar_ready && bc::fuel_remaining() > full + static_cast<std::uint64_t>(tune::kDetSafety) + 40000) w.ensure_altar_field();
        else {
            w.prepare_field_order();
            if (!w.field_order.empty() && bc::fuel_remaining() > full + static_cast<std::uint64_t>(tune::kDetSafety) + 40000) w.build_next_group_field(full);
        }
    }
#endif
#if V58_DIRECTOR
    economy_update(); // once per observation; the elected coordinator replans at most every ten rounds or completion
#endif
    const bool fought =
#if V58_SURVIVE
        survive_contact() ||
#endif
#if V58_ACT & 2
        act_enemy_before_walk() ||
#endif
        handle_enemies();
#if A2_SHIELDLATE
    if (fought && !cast_done) {
        shield_late_pass = true; // the dash was not used: the shield may go now
        support_casts();
        shield_late_pass = false;
    }
#endif
    PROF_CHECK("enemies");
#if A2_TEL
    // Flee-hit check: after the hit, did the turn still move and cast? (kind 13: bit 0 moved, bit 1 cast)
    if (a2tel::fleehit_round == round) a2tel::bump(13u * 4096 + (walked ? 1u : 0u) + (cast_done ? 2u : 0u));
#endif
    if (fought) {
        if (std::string_view(mode) == "idle") mode = "enemy";
        if (tune::kDistress && std::string_view(mode).starts_with("flee")) share_sighting(true);
        opportunistic_attack();
    } else if (win_now() && hp >= max_hp * tune::kDangerHp && tribute_if_needed()) {
        // Our bag finishes the race: bank it before anything else (shopping can wait).
        mode = "tribute-win";
    } else if (go_home_if_needed()) {
        if (std::string_view(mode) == "idle") mode = "home";
#if (A2_TEAM & 2)
    } else if (a2_join_fight()) {
#endif
    } else if (NOVA_RUSH_UNTIL > 0 && rush()) {
#if A2_FOG
    } else if (fog_regroup()) {
#endif
#if X1_FLEEHOLD
    } else if ([&] {
        // X1_FLEEHOLD (audit F01: after a flee, the next turn without handled contact went straight back to farming the
        // retained camp target, so champions alternated approach / flee into the same enemies until they died, cuts and
        // galaxy). For X1_FLEEHOLD rounds after a flee, keep away from any enemy seen within 8 in the last 4 rounds.
        if (round - last_flee_round > X1_FLEEHOLD) return false;
        vec2 threat{-100, -100};
        int best = 9;
        for (const auto& e : w.enemies) { const int d = cheb(e.pos, pos);
#if X3_ARBITRATION
            if (x3_arbiter_enabled() && d>std::max(5,e.range+2)) continue;
#endif
            if (d < best) best = d, threat = e.pos; }
        for (const auto& s : w.sightings) { if (round - s.round > 4) continue; const int d = cheb(s.pos, pos);
#if X3_ARBITRATION
            if (x3_arbiter_enabled() && d>5) continue;
#endif
            if (d < best) best = d, threat = s.pos; }
        if (best > 8) return false;
        mode = "flee-hold";
        return retreat_from(threat);
    }()) {
#endif
#if X1_ALONE
    } else if ([&] {
        // X1_ALONE (teammate death study, 100 v81 mirrors: 51% of deaths had no ally within 5): alone with an enemy
        // within 10, walk to the nearest ally before farming on; the fight logic above already ran this turn.
        int ally_d = 99, enemy_d = 99;
        const AllyRec* near = nullptr;
        for (const auto& a : w.allies) { const int d = cheb(a.pos, pos); if (d < ally_d) ally_d = d, near = &a; }
        for (const auto& e : w.enemies) enemy_d = std::min(enemy_d, cheb(e.pos, pos));
        if (!near || ally_d <= 5 || enemy_d > 10 || gems >= tune::kTributeCarry) return false;
#if X3_ARBITRATION
        if (x3_arbiter_enabled() && target_group>=0 && target_group<static_cast<int>(w.groups.size())) {
            const auto& g=w.groups[target_group];
            // Calm regrouping must not reset productive capture progress. Actual
            // enemy contact was handled above; imminent danger still wins.
            if (enemy_d>4 && g.state==GroupState::reward && bit(g.tiles,pos)) return false;
            if (enemy_d>6 && g.state==GroupState::alive && hp>=0.6f*max_hp &&
                g.hp_left(w.camps)<=2.0f*my_dps(&g) && w.has_field(target_group) &&
                w.group_distance(target_group,pos)<=range) return false;
        }
#endif
        bc::bitboard goal;
        goal.clear();
        goal.draw_chebyshev(near->pos, 2.0f);
        mode = "alone-regroup";
        return walk_toward(goal);
    }()) {
#endif
#if X3_TEAM >= 9
    } else if ([&] {
#if X3_BANK_COMMIT
        const bool continuing=team_bank_committed();
        if (!continuing) {
#endif
        if (claim_of(slot)!=125 || gems<=0) return false;
        int need=1;
        if (team_economic_assignment(need)!=-3) return false;
#if X3_BANK_COMMIT
            team_bank_commit();
        }
#endif
        force_tribute=true;
        const bool action=tribute_if_needed();
        force_tribute=false;
        if (action) {write_claim(-1);mode="team-bank-race";}
        return action;
    }()) {
#endif
    } else if (hunt()) {
    } else if (tribute_if_needed()) {
        mode = "tribute";
    } else {
        if (!farm()) mode = "nofarm";
        PROF_CHECK("d_farm");
        opportunistic_attack();
        PROF_CHECK("d_opp");
        support_casts();
    }
    PROF_CHECK("decide");
#if A2_MICLOG
    {
        // MT round slot type hp% nd0 nd inr mode cd0 cd1 used canatk0 canatk walked allies3 enemies3 gems x y ntype
        int nd = 99, inr = 0, al3 = 0, en3 = 0;
        const EnemyRec* ne = nullptr;
        for (const auto& e : w.enemies) {
            const int dd = cheb(e.pos, pos);
            if (dd < nd) nd = dd, ne = &e;
            inr += dd <= range;
            en3 += dd <= 3;
        }
        if (nd <= 4 || last_enemy_dist <= 4) {
            for (const auto& a : w.allies) al3 += a.id != my_id && cheb(a.pos, pos) <= 3;
            int cdn[2] = {99, 99}, used = -1;
            for (int s = 0; s < 2; ++s) {
                std::int32_t c = 99;
                if (spells[s].present) d::sdk_champion_cooldown(my_id, static_cast<std::uint32_t>(s), &c);
                cdn[s] = c;
                if (cooldown[s] == 0 && c > 0) used = s;
            }
            std::printf("MT %d %d %d %.2f %d %d %d %s %d %d %d %d %d %d %d %d %d %d\n", round, slot, static_cast<int>(type),
                hp / std::max(1.0f, max_hp), last_enemy_dist, nd, inr, mode, cooldown[0], cooldown[1], used,
                mic_can_attack0 ? 1 : 0, me.can_attack() ? 1 : 0, walked ? 1 : 0, al3, en3, gems,
                ne ? static_cast<int>(ne->type) : -1);
        }
    }
#endif
    drop_ward();
    if (tune::kTSearch && w.enemies.empty()) ts_prewarm(); // champion kits for the search, on calm turns
    prelock_altars();
    update_priority();
    PROF_CHECK("tail");
#if X3_TEAM == 7
    if (w.enemies.empty() && bc::fuel_remaining()>=80000) {
        x3_prepare=true;
        int crew=1;
        (void)team_economic_assignment(crew);
        x3_prepare=false;
    }
#endif
    build_fields();
    PROF_CHECK("fields");
#if X3_DRAFT_PATHS && X3_TRACE
    draft_paths_verify(w);
#endif
#if X3_TEAM >= 8
    if (w.enemies.empty() && bc::fuel_remaining()>=
#if X3_TEAM >= 9
        ((ally_score+team_size*tune::kTributeCarry>=static_cast<int>(bc::constants::winning_gems)) ? 20000u : 80000u)
#else
        80000u
#endif
        ) {
        x3_prepare=true;
        int crew=1;
        (void)team_economic_assignment(crew);
        x3_prepare=false;
    }
#endif
#if X1_BUSHPRE
    w.prelabel_bushes(static_cast<std::uint64_t>(X1_BUSHPRE) * 1000);
    PROF_CHECK("bushpre");
#endif
#ifdef APEX_MODESTATS
    // Debug: how many turns each champion spends in each behaviour (printed every 200 rounds).
    {
        static const char* names[24];
        static int counts[24];
        int k = 0;
        while (k < 24 && names[k] && std::string_view(names[k]) != mode) ++k;
        if (k < 24) {
            names[k] = mode;
            ++counts[k];
        }
        // Failure signals: walking modes that did not move (stuck), targets dropped while still
        // alive (abandons), and the longest streak of unproductive turns.
        static vec2 last_pos{-1, -1};
        static int stuck = 0, abandons = 0, idle_run = 0, idle_max = 0, last_target = -9;
        const std::string_view m(mode);
        if ((m == "approach" || m == "to-capture" || m == "home") && pos == last_pos) ++stuck;
        const bool idle = m == "stage" || m == "wait-respawn" || m == "nofarm" || m == "idle";
        idle_run = idle ? idle_run + 1 : 0;
        idle_max = std::max(idle_max, idle_run);
        if (last_target >= 0 && last_target < static_cast<int>(w.groups.size()) && target_group != last_target &&
            target_group != kClaimDead && w.groups[last_target].state == GroupState::alive)
            ++abandons;
        last_target = target_group;
        last_pos = pos;
        if (round % 50 == 0) {
            std::printf("MODES R%d %s slot%d:", round, bc::to_string(type).c_str(), slot);
            for (int i = 0; i < 24 && names[i]; ++i) std::printf(" %s=%d", names[i], counts[i]);
            std::printf("\n");
            std::printf("DIAG R%d %s slot%d stuck=%d abandons=%d idlemax=%d\n", round, bc::to_string(type).c_str(), slot,
                stuck, abandons, idle_max);
        }
    }
#endif
    if (APEX_PROFILE && slot == 0 && round % 250 == 0) prof::report(round);
#ifdef APEX_SPELLSTAT
    // Debug: spells spent on camps vs champions, and whether a champion-capable spell is ready when an enemy
    // first comes within 5 tiles after at least 6 quiet rounds (a new contact).
    {
        int near = 99;
        for (const auto& e : w.enemies) near = std::min(near, cheb(e.pos, pos));
        if (near <= 5) {
            if (round - spellstat_last_contact > 6) {
                ++spellstat_contacts;
                bool ready = false;
                for (int s2 = 0; s2 < 2; ++s2)
                    ready |= spells[s2].present && spells[s2].enemies && cooldown[s2] == 0 &&
                        (spells[s2].kind == bc::ability_kind::damage || spells[s2].kind == bc::ability_kind::cc ||
                            spells[s2].kind == bc::ability_kind::aoe_damage);
                bool has = false;
                for (int s2 = 0; s2 < 2; ++s2)
                    has |= spells[s2].present && spells[s2].enemies && (spells[s2].kind == bc::ability_kind::damage ||
                        spells[s2].kind == bc::ability_kind::cc || spells[s2].kind == bc::ability_kind::aoe_damage);
                spellstat_has += has;
                spellstat_ready += ready;
            }
            spellstat_last_contact = round;
        }
        if (round % 100 == 0)
            std::printf("SPELLSTAT R%d %s camp=%d enemy=%d contacts=%d with_spell=%d ready=%d\n", round,
                bc::to_string(type).c_str(), spellstat_camp, spellstat_enemy, spellstat_contacts, spellstat_has, spellstat_ready);
    }
#endif
    if (APEX_PROFILE && round == 400)
        std::printf("FARMFUEL slot%d calls %u low %u route_skip %u gaveup %u td_then_farm %u\n", slot, prof::farm_calls, prof::farm_low,
            prof::farm_route_skip, prof::farm_gaveup, prof::td_then_farm);
    if (APEX_TRACE && slot == 0 && round % 25 == 0)
        std::printf("PHASE R%d us %d them %d kills %d\n", round, ally_score, enemy_score, team_kills_seen);
    if (APEX_DEATHLOG) {
        auto& n = notes[note_i];
        note_i = (note_i + 1) & 3;
        n.round = round;
        n.hp = static_cast<int>(hp);
        n.max_hp = static_cast<int>(max_hp);
        n.gems = gems;
        n.mode = mode;
        n.target = target_group;
        n.pos = pos;
        n.enemies = static_cast<int>(w.enemies.size());
        n.near_enemy = last_enemy_dist;
        n.enemy_hp = 0;
        for (const auto& e : w.enemies) n.enemy_hp += static_cast<int>(e.hp);
        n.spawn_dist = fdist(w.spawn_field, pos);
        n.allies_near = 0;
        for (const auto& a : w.allies)
            if (a.id != my_id && cheb(a.pos, pos) <= 4) ++n.allies_near;
    }
    debug_block({ std::printf("M %d %u %s %d\n", round, my_id, mode, target_group); });
    LOG("R%d %-11s p(%d,%d) hp%.0f/%.0f g%d $%d %s G%d st%d fuel%llu\n", round, bc::to_string(type).c_str(), pos.x, pos.y, hp,
        max_hp, gems, gold, mode, target_group, target_group >= 0 ? static_cast<int>(w.groups[target_group].state) : -1,
        static_cast<unsigned long long>(bc::fuel_remaining()));
}
