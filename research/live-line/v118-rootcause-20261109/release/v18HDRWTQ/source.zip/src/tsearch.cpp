// Tactical search, bot side: snapshot the local fight into a ts::State, play every root candidate forward
// against two enemy models while fuel lasts, and carry out the best one (APEX_TSEARCH).
#include "bot.h"
#include "fight.h"
#include "tsearch.h"
#include "a2map.h"
#include "local_model.h"
#if A2_LAB
#include "lab.h"
#endif

#include <cstring>
#include <variant>

namespace d = cambc::detail;

namespace {
// Champion kits from the immutable designs, cached per type.
struct KitSpell {
    std::int8_t kind = 0, range = 0, radius = 0;
    std::uint8_t flags = 0;
    float mod = 0;
};
struct Kit {
    bool loaded = false;
    KitSpell sp[2];
};

const Kit& kit_of(bc::champion_type type) {
    static std::array<Kit, 16> table{};
    static Kit none;
    const int t = static_cast<int>(type);
    if (t < 0 || t >= ((A2_KITFIX & 1) ? 16 : 12)) return none; // engine 3.0: Heart of Ruin is type 12
    Kit& k = table[t];
    if (k.loaded) return k;
    k.loaded = true;
    try {
        bc::champion design{type};
        const auto abilities = design.abilities();
        for (int s = 0; s < 2; ++s) {
            const auto& info = abilities[s].info();
            if (!info) continue;
            KitSpell& ks = k.sp[s];
            std::visit(
                [&](const auto& a) {
                    using A = std::decay_t<decltype(a)>;
                    ks.kind = static_cast<std::int8_t>(A::kind);
                    if (a.exclusive_with_movement) ks.flags |= ts::SF_EXCL_WALK;
                    if (a.valid_targets.contains(bc::ability_target_mask::enemies)) ks.flags |= ts::SF_ENEMY;
                    if (a.valid_targets.contains(bc::ability_target_mask::allies)) ks.flags |= ts::SF_ALLY;
                    if constexpr (requires { a.range; }) ks.range = static_cast<std::int8_t>(a.range);
                    if constexpr (requires { a.modifier; }) ks.mod = a.modifier;
                    if constexpr (requires { a.radius; }) ks.radius = static_cast<std::int8_t>(a.radius);
                    if constexpr (std::is_same_v<A, bc::ability_dash>)
                        if (TS_DASHX && a.duration > 0) ks.flags |= ts::SF_STUN; // striking dash stun
                },
                *info);
            if (ks.kind == ts::K_CC) ks.flags |= ts::SF_STUN;
            if (ks.kind == ts::K_AOE && type == bc::champion_type::ryth) ks.flags |= ts::SF_STUN; // Ryth's area stun
            if (ks.kind == ts::K_RESET && type == bc::champion_type::marcella) ks.flags |= ts::SF_ENH;
            if (ks.kind == ts::K_DASH && ks.range <= 0) ks.range = 2;
        }
    } catch (...) {
    }
    return k;
}

// Fills a unit from live numbers; cooldowns we cannot read count as ready (the cautious guess).
void fill_unit(ts::Unit& u, int team, bc::champion_type type, vec2 p, float hp, float max_hp, float str, float focus,
    int range, int gems, std::uint32_t handle, bool acted, const int* known_cd) {
    u = ts::Unit{};
    u.team = static_cast<std::int8_t>(team);
    u.x = static_cast<std::int16_t>(p.x);
    u.y = static_cast<std::int16_t>(p.y);
    u.hp = hp;
    u.max_hp = std::max(max_hp, 1.0f);
    u.str = str;
    u.range = static_cast<std::int8_t>(range);
    u.gems = static_cast<std::int16_t>(gems);
    u.flags = ts::U_ALIVE | (acted ? ts::U_ACTED : 0);
    if (type == bc::champion_type::varg) u.flags |= ts::U_SPLASH;
    if (type == bc::champion_type::marcella) u.flags |= ts::U_STUN_IMMUNE;
    if (type == bc::champion_type::vendetta) u.flags |= ts::U_RESET_ON_KILL;
    if ((A2_KITFIX & 4) && type == bc::champion_type::heart_of_ruin) u.flags |= ts::U_RUIN;
    if (type == bc::champion_type::ren) u.retaliate = 0.2f * focus;
    const Kit& k = kit_of(type);
    for (int s = 0; s < 2; ++s) {
        const KitSpell& ks = k.sp[s];
        ts::SSpell& sp = u.sp[s];
        sp.kind = ks.kind;
        sp.range = ks.range;
        sp.radius = ks.radius;
        sp.flags = ks.flags;
        sp.value = ks.mod * focus;
        int cd = 0;
        if (known_cd) {
            cd = known_cd[s];
        } else {
            std::int32_t c = 0;
            if (d::sdk_champion_cooldown(handle, static_cast<std::uint32_t>(s), &c) == 0) cd = c;
        }
        sp.cd = static_cast<std::int8_t>(std::clamp(cd, 0, 99));
    }
    // Live shield and stun.
    d::buff_data buffs[6];
    std::uint32_t nb = 0;
    if (d::sdk_champion_buff_data(handle, buffs, 6, &nb) == 0)
        for (std::uint32_t i = 0; i < nb && i < 6; ++i) {
            if (buffs[i].type == 0) {
                u.shield = buffs[i].data.shield.value;
                u.shield_turns = static_cast<std::int8_t>(std::clamp(buffs[i].data.shield.duration, 0, 9));
            } else if (buffs[i].type == 1 && buffs[i].data.stun.duration > 0) {
                u.stunned = 1;
            } else if (buffs[i].type == 2) {
                u.flags |= ts::U_ENHANCED;
            }
        }
}
} // namespace

// Loads one champion kit per call (designs cost fuel to read): run on calm turns so fights never pay it.
void Bot::ts_prewarm() {
    static int next = 0;
    if (next >= ((A2_KITFIX & 1) ? 13 : 12) || bc::fuel_remaining() < 60000) return;
    kit_of(static_cast<bc::champion_type>(next++));
}

// The local fight as a ts::State: us (unit 0), allies within 7, enemies within 8; false when no enemy is in range.
bool Bot::ts_snapshot(ts::State& s, ts::Map& m, const EnemyRec** eref) {
    m.blocked = w.static_blocked.ptr();
    m.w = w.width;
    m.h = w.height;
    m.stride = static_cast<int>(bc::detail::layout().chunk_stride);
    if (ts_home[0].x < 0) {
        auto centre = [](const bc::bitboard& b) {
            long sx = 0, sy = 0, n = 0;
            for (vec2 p : b.positions()) sx += p.x, sy += p.y, ++n;
            return n ? vec2{static_cast<int>(sx / n), static_cast<int>(sy / n)} : vec2{0, 0};
        };
        ts_home[0] = centre(w.ally_spawn);
        ts_home[1] = centre(w.enemy_spawn);
    }
    m.home_x[0] = static_cast<std::int16_t>(ts_home[0].x);
    m.home_y[0] = static_cast<std::int16_t>(ts_home[0].y);
    m.home_x[1] = static_cast<std::int16_t>(ts_home[1].x);
    m.home_y[1] = static_cast<std::int16_t>(ts_home[1].y);

    // Unit 0 is us; then allies within 7 and enemies within 8 (nearest first by insertion order).
    int my_cd[2] = {cooldown[0], cooldown[1]};
    if (cast_done) {
        // support_casts runs after refresh_self and before handle_enemies.
        // Its real cast changes the engine cooldowns, not the cached array.
        for (int slot = 0; slot < 2; ++slot) {
            std::int32_t live_cd = 99;
            if (d::sdk_champion_cooldown(my_id, static_cast<std::uint32_t>(slot), &live_cd) == 0)
                my_cd[slot] = live_cd;
            else my_cd[slot] = 99;
        }
    }
    fill_unit(s.u[0], 0, type, pos, hp, max_hp, strength, focus, range, gems, my_id, false, my_cd);
    if (cast_done) s.u[0].flags |= ts::U_CAST_INITIAL;
    const auto root_self = bc::self();
    s.root_budget = static_cast<std::uint8_t>((root_self.can_move() ? 0 : 1) |
        (root_self.can_attack() ? 0 : 2) | (walked ? 4 : 0));
    s.n = 1;
    int ci_idx[2][2] = {{-1, -1}, {-1, -1}}; // [team][cassi, issac]
    auto note_ci = [&](int team, bc::champion_type t, int idx) {
        if (t == bc::champion_type::cassi) ci_idx[team][0] = idx;
        if (t == bc::champion_type::issac) ci_idx[team][1] = idx;
    };
    note_ci(0, type, 0);
#if A2_SNAP || A2_TD_AUTH || A2_TEL
    auto add_ally = [&](const AllyRec& a) {
        d::champion_info info{};
        if (d::sdk_champion(a.id, &info) != 0) return false;
        std::uint32_t g = 0;
        d::sdk_champion_gems(a.id, &g);
        const bool acted = (static_cast<std::uint32_t>(info.state) & (1u << 5)) != 0;
        fill_unit(s.u[s.n], 0, a.type, a.pos, a.hp, a.max_hp, a.strength, a.focus, a.range, static_cast<int>(g), a.id, acted, nullptr);
        note_ci(0, a.type, s.n);
        ++s.n;
        return true;
    };
    auto add_enemy = [&](const EnemyRec& e) {
        const bool acted = (e.state & (1u << 5)) != 0;
        fill_unit(s.u[s.n], 1, e.type, e.pos, e.hp, e.max_hp, e.strength, e.focus, e.range, e.gems, e.id, acted, nullptr);
        if (e.tributing() || e.recalling()) s.u[s.n].flags |= ts::U_ACTED; // channelling: it will not fight back now
        note_ci(1, e.type, s.n);
        eref[s.n] = &e;
        ++s.n;
    };
    auto is_ci = [](bc::champion_type t) { return t == bc::champion_type::cassi || t == bc::champion_type::issac; };
    // An enemy the model leaves out still threatens us when it could hit us next turn (the formula's radius).
    auto reaches_us = [&](const EnemyRec& e) { return cheb(e.pos, pos) <= std::max(e.range + 2, 5); };
    a2ts::snap = a2ts::SnapInfo{};
#if A2_SNAP
    // Relevance-ranked snapshot of at most A2_SNAP units (us included). Order: nearest first; at equal distance enemies
    // before allies, then the bigger threat (basic + spell), then the lower handle. The nearest enemy is always in; a
    // Cassi/Issac pair enters whole or not at all (our own partner first); at most three allies. Dropped units stay
    // in the model as movement blockers, and what was dropped is recorded for the verdict's authority.
    struct Cand {
        const AllyRec* a;
        const EnemyRec* e;
        int d;
        float threat;
        std::uint32_t id;
        int partner;
        bool taken;
    };
    Cand cd[16];
    int ncd = 0, enemies = 0, near_d = 99, scene = 1;
    for (const auto& a : w.allies) {
        if (cheb(a.pos, pos) > 7) continue;
        ++scene;
        if (ncd < 16) cd[ncd++] = {&a, nullptr, cheb(a.pos, pos), a.strength + spell_kit(a.type, a.focus).nuke, a.id, -1, false};
    }
    for (const auto& e : w.enemies) {
        const int dd = cheb(e.pos, pos);
        if (dd > 8 || e.hp <= 0) continue;
        ++scene;
        near_d = std::min(near_d, dd);
        ++enemies;
        if (ncd < 16) cd[ncd++] = {nullptr, &e, dd, e.strength + spell_kit(e.type, e.focus).nuke, e.id, -1, false};
    }
    a2ts::snap.scene = scene;
    if (!enemies || near_d > tune::kTsRange) return false;
    auto ctype = [&](const Cand& c) { return c.a ? c.a->type : c.e->type; };
    for (int i = 0; i < ncd; ++i)
        if (is_ci(ctype(cd[i])))
            for (int j = 0; j < ncd; ++j)
                if (j != i && (cd[j].a != nullptr) == (cd[i].a != nullptr) && is_ci(ctype(cd[j])) && ctype(cd[j]) != ctype(cd[i]))
                    cd[i].partner = j;
    int order[16];
    for (int i = 0; i < ncd; ++i) order[i] = i;
    std::sort(order, order + ncd, [&](int x, int y) {
        const Cand &p = cd[x], &q = cd[y];
        if (p.d != q.d) return p.d < q.d;
        if ((p.e != nullptr) != (q.e != nullptr)) return p.e != nullptr;
        if (p.threat != q.threat) return p.threat > q.threat;
        return p.id < q.id;
    });
    const int cap = std::clamp(a2map::snap_cap(static_cast<int>(A2_SNAP)), 2, ts::kMaxUnits);
    int allies_in = 0;
    auto take = [&](int i) {
        if (cd[i].taken) return;
        cd[i].taken = true;
        if (cd[i].a) {
            if (add_ally(*cd[i].a)) ++allies_in;
        } else {
            add_enemy(*cd[i].e);
        }
    };
    // Room for candidate i (with its partner when it has one), within the cap and the three-ally limit.
    auto fits_in = [&](int i) {
        const int p = cd[i].partner >= 0 && !cd[cd[i].partner].taken ? cd[i].partner : -1;
        const int need = 1 + (p >= 0);
        const int need_allies = (cd[i].a != nullptr) + (p >= 0 && cd[p].a != nullptr);
        return s.n + need <= cap && allies_in + need_allies <= 3;
    };
    if (is_ci(type))
        for (int k = 0; k < ncd; ++k) // our own partner: one fate, so it is part of every fight we are in
            if (cd[order[k]].a && is_ci(cd[order[k]].a->type) && cd[order[k]].a->type != type && s.n < cap) {
                take(order[k]);
                break;
            }
    for (int k = 0; k < ncd; ++k) // the nearest enemy, with its partner if there is room
        if (cd[order[k]].e) {
            const int i = order[k];
            if (fits_in(i) && cd[i].partner >= 0) take(cd[i].partner);
            if (s.n < cap) take(i);
            break;
        }
    for (int k = 0; k < ncd && s.n < cap; ++k) {
        const int i = order[k];
        if (cd[i].taken || !fits_in(i)) continue;
        take(i);
        if (cd[i].partner >= 0) take(cd[i].partner);
    }
    {
        static bc::bitboard ts_blocked;
        bool any_dropped = false;
        for (int i = 0; i < ncd; ++i) {
            if (cd[i].taken) {
                if (cd[i].partner >= 0 && !cd[cd[i].partner].taken) a2ts::snap.link_partial = true;
                continue;
            }
            if (!any_dropped) ts_blocked = w.static_blocked, any_dropped = true;
            set_bit(ts_blocked, cd[i].a ? cd[i].a->pos : cd[i].e->pos); // not in the model, still in the way
            if (cd[i].e) {
                ++a2ts::snap.dropped_enemies;
                a2ts::snap.omit_reach |= reaches_us(*cd[i].e);
            } else {
                ++a2ts::snap.dropped_allies;
            }
        }
        if (is_ci(type)) // our own partner visible within 7 but not modelled
            for (int i = 0; i < ncd; ++i)
                if (cd[i].a && is_ci(cd[i].a->type) && cd[i].a->type != type && !cd[i].taken) a2ts::snap.link_partial = true;
        if (any_dropped) m.blocked = ts_blocked.ptr();
    }
    a2ts::snap.n = s.n;
    const int a2_enemies_in = enemies;
    (void)a2_enemies_in;
#else
    // v34's selection (allies then enemies in observation order), recording what it leaves out.
    int scene = 1;
    for (const auto& a : w.allies) {
        if (cheb(a.pos, pos) > 7) continue;
        ++scene;
        if (s.n >= 4) {
            ++a2ts::snap.dropped_allies;
            continue;
        }
        add_ally(a);
    }
    int enemies = 0, near_d = 99;
    for (const auto& e : w.enemies) {
        const int dd = cheb(e.pos, pos);
        if (dd > 8 || e.hp <= 0) continue;
        ++scene;
        if (s.n >= ts::kMaxUnits) {
            ++a2ts::snap.dropped_enemies;
            a2ts::snap.omit_reach |= reaches_us(e);
            continue;
        }
        near_d = std::min(near_d, dd);
        add_enemy(e);
        ++enemies;
    }
    a2ts::snap.scene = scene;
    a2ts::snap.n = s.n;
    (void)is_ci;
    if (!enemies || near_d > tune::kTsRange) return false;
#endif
#else
    for (const auto& a : w.allies) {
        if (s.n >= 4 || cheb(a.pos, pos) > 7) continue;
        d::champion_info info{};
        if (d::sdk_champion(a.id, &info) != 0) continue;
        std::uint32_t g = 0;
        d::sdk_champion_gems(a.id, &g);
        const bool acted = (static_cast<std::uint32_t>(info.state) & (1u << 5)) != 0;
        fill_unit(s.u[s.n], 0, a.type, a.pos, a.hp, a.max_hp, a.strength, a.focus, a.range, static_cast<int>(g), a.id, acted, nullptr);
        note_ci(0, a.type, s.n);
        ++s.n;
    }
    int enemies = 0, near_d = 99;
    for (const auto& e : w.enemies) {
        if (s.n >= ts::kMaxUnits) break;
        const int dd = cheb(e.pos, pos);
        if (dd > 8 || e.hp <= 0) continue;
        near_d = std::min(near_d, dd);
        const bool acted = (e.state & (1u << 5)) != 0;
        fill_unit(s.u[s.n], 1, e.type, e.pos, e.hp, e.max_hp, e.strength, e.focus, e.range, e.gems, e.id, acted, nullptr);
        if (e.tributing() || e.recalling()) s.u[s.n].flags |= ts::U_ACTED; // channelling: it will not fight back now
        note_ci(1, e.type, s.n);
        eref[s.n] = &e;
        ++s.n;
        ++enemies;
    }
    if (!enemies || near_d > tune::kTsRange) return false;
#endif
    s.nc = 0;
    if (tune::kTsCamps)
        for (const auto& g : w.groups) {
            if (g.state != GroupState::alive) continue;
            for (int ci : g.camps) {
                const CampRec& c = w.camps[ci];
                if (c.dead || c.hp <= 0 || c.strength <= 0 || cheb(c.pos, pos) > 7 || s.nc >= ts::kMaxCamps) continue;
                s.camps[s.nc++] = ts::Camp{c.strength, static_cast<std::int16_t>(c.pos.x), static_cast<std::int16_t>(c.pos.y),
                    static_cast<std::int8_t>(c.range)};
            }
        }
    for (int t = 0; t < 2; ++t)
        if (ci_idx[t][0] >= 0 && ci_idx[t][1] >= 0) {
            s.u[ci_idx[t][0]].link = static_cast<std::int8_t>(ci_idx[t][1]);
            s.u[ci_idx[t][1]].link = static_cast<std::int8_t>(ci_idx[t][0]);
        }
#if A2_TS_VIS
    // Vision boards for ts::sees; bush clusters within 3 of every unit get labelled (once per cluster per game).
    static bc::bitboard walls_only = bc::map::walls();
    m.walls = walls_only.ptr();
    m.bushes = w.bushes.ptr();
    m.bush_labeled = w.bush_labeled.ptr();
    m.bush_label = w.bush_label.get();
    m.nstart = s.n;
    for (int i = 0; i < s.n; ++i) m.start_x[i] = s.u[i].x, m.start_y[i] = s.u[i].y;
    for (int i = 0; i < s.n; ++i)
        for (int dy = -3; dy <= 3; ++dy)
            for (int dx = -3; dx <= 3; ++dx) {
                const vec2 q{s.u[i].x + dx, s.u[i].y + dy};
                if (q.x < 0 || q.y < 0 || q.x >= w.width || q.y >= w.height) continue;
                if (bit(w.bushes, q) && !bit(w.bush_labeled, q)) w.bush_cluster(q);
            }
#endif
    return true;
}

bool Bot::tactical_search() {
    PROF(tsearch);
#if A2_TSFULL
    {
        // A2_TSFULL (engine lab only: no fuel limit): the engine labels' full candidate list (ts::gen_full), each played
        // forward with the engine-ranked settings (A2_TSFIX values), the best carried out in the labels' order.
        ts::State s;
        ts::Map m;
        const EnemyRec* eref[ts::kMaxUnits] = {};
        if (!ts_snapshot(s, m, eref)) return false;
        static ts::Action cands[1024];
        const int nc = ts::gen_full(s, m, cands, 1024);
        if (nc < 2) return false;
        const ts::Weights wts{25.0f, 12.0f, 0.0f, 0.0f};
        ts::Policy md;
        md.flee[0] = 0.5f, md.flee[1] = 0.2f, md.aggr[0] = 1.0f, md.aggr[1] = 0.0f;
        int best = -1;
        float best_v = -1e30f;
        for (int i = 0; i < nc; ++i) {
            ts::State c = s;
            if (!ts::apply_root(c, m, cands[i])) continue;
            ts::rollout(c, m, md, tune::kTsRounds);
            const float v = ts::evaluate(c, wts);
            if (v > best_v) best_v = v, best = i;
        }
        if (best < 0) return false;
        const ts::Action& a = cands[best];
        auto& me = bc::self();
        auto cast_it = [&](int slot, int target, int x, int y) {
            if (slot < 0 || !spell_ready(slot)) return;
            try {
                const auto ab = me.abilities()[slot];
                const auto kind = spells[slot].kind;
                bool ok = false;
                if (kind == bc::ability_kind::aoe_damage) ok = ab.use(vec2{x, y});
                else if (kind == bc::ability_kind::shield || kind == bc::ability_kind::attack_reset || target < 0) ok = ab.use();
                else if (target >= 0 && target < ts::kMaxUnits && eref[target]) ok = ab.use(eref[target]->unit);
                if (ok) cast_done = true;
            } catch (const std::exception& ex) {
                LOG("tsfull cast error %s\n", ex.what());
            }
        };
        cast_it(a.pre_slot, a.pre_target, a.pre_x, a.pre_y);
        if (a.move_x >= 0 && me.can_move()) {
            try {
                if (me.move_absolute(vec2{a.move_x, a.move_y})) pos = vec2{a.move_x, a.move_y}, walked = true;
            } catch (const std::exception& ex) {
                LOG("tsfull move error %s\n", ex.what());
            }
        }
        cast_it(a.post_slot, a.post_target, a.post_x, a.post_y);
        if (a.attack >= 0 && a.attack < ts::kMaxUnits && eref[a.attack]) {
            const EnemyRec& e = *eref[a.attack];
            if (attack_unit(e.unit, e.pos) && a.mid_slot >= 0) {
                const bool reset = spells[a.mid_slot].kind == bc::ability_kind::attack_reset;
                cast_it(a.mid_slot, a.mid_target, a.mid_x, a.mid_y);
                if (reset) attack_unit(e.unit, e.pos);
            }
        }
        return true;
    }
#endif
    const auto fuel0 = bc::fuel_remaining();
    if (fuel0 < static_cast<std::uint64_t>(tune::kTsReserve) + 12000) return false;
    ts::State s;
    ts::Map m;
    const EnemyRec* eref[ts::kMaxUnits] = {};
    if (!ts_snapshot(s, m, eref)) return false;

    ts::Action cands[24];
    const int nc = ts::gen_root(s, m, cands, 24);
    if (nc < 2) return false;
    // Most promising first (fuel may only cover a few): fight from here, then the steps that hit, the
    // flight steps (furthest from the nearest enemy), and the rest.
    {
        const ts::Unit& me0 = s.u[0];
        int ne = -1, nd = 99;
        for (int j = 1; j < s.n; ++j)
            if (s.u[j].team == 1 && ts::cheb(me0.x, me0.y, s.u[j].x, s.u[j].y) < nd) nd = ts::cheb(me0.x, me0.y, s.u[j].x, s.u[j].y), ne = j;
        for (int i = 0; i < nc; ++i) {
            ts::Action& a = cands[i];
            const int x = a.dash_slot >= 0 ? a.dash_x : a.move_x >= 0 ? a.move_x : me0.x;
            const int y = a.dash_slot >= 0 ? a.dash_y : a.move_x >= 0 ? a.move_y : me0.y;
            const bool stay = a.dash_slot < 0 && a.move_x < 0;
            float pr = 0;
            if (a.attack >= 0) pr += 4;
            if (a.pre_slot >= 0) pr += 3;
            if (stay) pr += 2;
            if (ne >= 0) pr += 0.5f * static_cast<float>(ts::cheb(x, y, s.u[ne].x, s.u[ne].y) - nd); // flight steps rank next
            a.prior = pr;
        }
        std::sort(cands, cands + nc, [](const ts::Action& p, const ts::Action& q) { return p.prior > q.prior; });
        // Keep the best flight step near the front too.
        int flee = -1, flee_d = -1;
        for (int i = 0; i < nc; ++i) {
            const ts::Action& a = cands[i];
            if (a.attack >= 0 || ne < 0) continue;
            const int x = a.dash_slot >= 0 ? a.dash_x : a.move_x >= 0 ? a.move_x : me0.x;
            const int y = a.dash_slot >= 0 ? a.dash_y : a.move_x >= 0 ? a.move_y : me0.y;
            const int dd = ts::cheb(x, y, s.u[ne].x, s.u[ne].y);
            if (dd > flee_d) flee_d = dd, flee = i;
        }
        if (flee > 2) std::rotate(cands + 2, cands + flee, cands + flee + 1);
    }
    ts::Weights wts{tune::kTsAlive, tune::kTsHp, tune::kTsThreat};
    if (tune::kTsLearned) {
        // Learned exchange rates (tools/exchange.py on 311k top-team positions): a life is worth ~8 gems at
        // the start and ~25 by round 450, carried gems ~0.75 of banked, health in itself little.
        const float t = std::min(1.0f, static_cast<float>(round) / 450.0f);
        wts.alive = NOVA_TD_LIFE0 + (NOVA_TD_LIFE1 - NOVA_TD_LIFE0) * t; // default 8 -> 25
        wts.hp = 3.0f;
        wts.gem = 0.75f;
    }
    ts::Policy models[2];
    models[0].flee[0] = models[1].flee[0] = tune::kTsAllyFlee;
    models[0].flee[1] = tune::kTsFleeA;
    models[1].flee[1] = tune::kTsFleeC;
    if (tune::kOppModel) {
        // This opponent's learned back-off health, bracketed by the two models.
        const float est = opp_flee_estimate();
        if (est >= 0.0f) {
            models[0].flee[1] = std::max(0.02f, est - 0.1f);
            models[1].flee[1] = std::min(0.8f, est + 0.1f);
        }
    }
#if A2_TSFIX
    // A2_TSFIX (engine labels, agent2/lab/sim_rank.js): the settings under which the simulator ranks a fight turn's
    // options most like the engine â€” the lab value (a life 25, a health bar 12; no gems, no threat term), enemies that
    // commit (flee 0.2, no engagement check), our side more careful (flee 0.5, engagement factor 1.0).
    wts = ts::Weights{25.0f, 12.0f, 0.0f, 0.0f};
    for (auto& md : models) {
        md.flee[0] = 0.5f;
        md.flee[1] = 0.2f;
        md.aggr[0] = 1.0f;
        md.aggr[1] = 0.0f;
    }
#endif
    float pass_v[2][24] = {};
    int passes[24] = {};
    bool legal[24];
    for (int i = 0; i < nc; ++i) legal[i] = true;
    // Stage 1: every candidate's position right after our action (cheap), to order the rollouts.
    {
        float stat[24];
        for (int i = 0; i < nc; ++i) {
#if A2_TSX
            // Fuel-guarded: a candidate left unscored is left out of the rollouts (it keeps no stale value).
            if (bc::fuel_remaining() < static_cast<std::uint64_t>(tune::kTsReserve) + 12000) {
                legal[i] = false;
                stat[i] = -1e30f;
                continue;
            }
#endif
            ts::State c = s;
            if (!ts::apply_root(c, m, cands[i])) {
                legal[i] = false;
                stat[i] = -1e30f;
                continue;
            }
            stat[i] = ts::evaluate(c, wts);
        }
        int order[24];
        for (int i = 0; i < nc; ++i) order[i] = i;
        std::sort(order, order + nc, [&](int p, int q) { return stat[p] > stat[q]; });
        ts::Action sorted[24];
        bool lsorted[24];
        for (int i = 0; i < nc; ++i) sorted[i] = cands[order[i]], lsorted[i] = legal[order[i]];
        for (int i = 0; i < nc; ++i) cands[i] = sorted[i], legal[i] = lsorted[i];
    }
    int rollouts = 0;
    std::uint64_t worst = 4000; // most expensive rollout so far (a floor before the first one)
    for (int pass = 0; pass < 2; ++pass)
        for (int i = 0; i < nc; ++i) {
            if (!legal[i]) continue;
            // Never let the search run the turn out of fuel: a suspended turn loses the action.
            const std::uint64_t left = bc::fuel_remaining();
            if (left < static_cast<std::uint64_t>(tune::kTsReserve) + 2 * worst) goto done;
            ts::State c = s;
            if (!ts::apply_root(c, m, cands[i])) {
                legal[i] = false;
                continue;
            }
            ts::rollout(c, m, models[pass], tune::kTsRounds);
            pass_v[pass][i] = ts::evaluate(c, wts);
            ++passes[i];
            ++rollouts;
            const std::uint64_t now = bc::fuel_remaining();
            if (now < left) worst = std::max(worst, left - now);
        }
done:
    // Compare like with like: both models' mean when every candidate has both, else the first model only
    // (over the candidates it reached).
    bool all_two = true;
    for (int i = 0; i < nc; ++i)
        if (legal[i] && passes[i] < 2) all_two = false;
    int best = -1, evaluated = 0;
    float best_v = -1e30f;
    for (int i = 0; i < nc; ++i) {
        if (!legal[i] || passes[i] == 0) continue;
        ++evaluated;
        const float v = all_two ? 0.5f * (pass_v[0][i] + pass_v[1][i]) : pass_v[0][i];
        if (v > best_v) best_v = v, best = i;
    }
#if A2_TEL
    // Action search coverage (kind 19): candidates that got a playout, and whether the search acted.
    a2tel::bump(19u * 4096 + static_cast<std::uint32_t>(std::min(evaluated, 24)) * 2 + (best >= 0 && evaluated >= 2 ? 1u : 0u));
#endif
    if (best < 0 || evaluated < 2) return false;
#ifdef APEX_TSLOG
    if (round % 7 == 0) {
        // Snapshot dump: what the model believes.
        for (int i = 0; i < s.n; ++i) {
            const ts::Unit& u = s.u[i];
            std::printf("TSU R%d i%d t%d p(%d,%d) hp%.0f/%.0f str%.0f rng%d g%d f%d stn%d sh%.0f sp0[k%d cd%d r%d v%.0f f%d] sp1[k%d cd%d r%d v%.0f f%d]\n",
                round, i, u.team, u.x, u.y, u.hp, u.max_hp, u.str, u.range, u.gems, u.flags, u.stunned, u.shield, u.sp[0].kind,
                u.sp[0].cd, u.sp[0].range, u.sp[0].value, u.sp[0].flags, u.sp[1].kind, u.sp[1].cd, u.sp[1].range, u.sp[1].value,
                u.sp[1].flags);
        }
        for (int i = 0; i < nc; ++i)
            std::printf("TSC R%d c%d pre%d move(%d,%d) dash(%d,%d) atk%d passes%d v0 %.1f v1 %.1f%s\n", round, i, cands[i].pre_slot,
                cands[i].move_x, cands[i].move_y, cands[i].dash_x, cands[i].dash_y, cands[i].attack, passes[i], pass_v[0][i],
                pass_v[1][i], i == best ? " <== best" : "");
    }
    {
        const auto now = bc::fuel_remaining();
        std::printf("TS R%d %s units %d cands %d rollouts %d fuel %lld worst %llu both %d best %.1f act pre%d dash%d move%d atk%d\n",
            round, bc::to_string(type).c_str(), s.n, nc, rollouts, static_cast<long long>(fuel0) - static_cast<long long>(now),
            static_cast<unsigned long long>(worst), all_two ? 1 : 0, best_v, cands[best].pre_slot, cands[best].dash_slot,
            cands[best].move_x >= 0 ? 1 : 0, cands[best].attack);
    }
#endif
    (void)rollouts;
#ifdef APEX_TSTRACE
    {
        // Compact record of this search, printed if we die soon after (play_turn).
        char buf[900];
        int len = std::snprintf(buf, sizeof(buf), "TRACE R%d me(%d,%d) hp%.0f/%.0f g%d |", round, pos.x, pos.y, hp, max_hp, gems);
        for (int i = 1; i < s.n && len < 600; ++i) {
            const ts::Unit& u = s.u[i];
            len += std::snprintf(buf + len, sizeof(buf) - len, " %c(%d,%d)hp%.0f s%.0f r%d%s%s", u.team ? 'E' : 'A', u.x, u.y, u.hp, u.str, u.range,
                (u.flags & ts::U_ACTED) ? "*" : "", u.stunned ? "z" : "");
        }
        len += std::snprintf(buf + len, sizeof(buf) - len, " || picked c%d of %d:", best, nc);
        for (int i = 0; i < nc && len < 860; ++i)
            len += std::snprintf(buf + len, sizeof(buf) - len, " [%s%s%s%s %.1f]", cands[i].move_x >= 0 ? "m" : "", cands[i].dash_slot >= 0 ? "d" : "",
                cands[i].attack >= 0 ? "a" : "", cands[i].pre_slot >= 0 ? "s" : "", passes[i] ? pass_v[0][i] : -999.0f);
        ts_trace[ts_trace_i & 1] = buf;
        ++ts_trace_i;
    }
#endif

    // Carry it out. Engine refusals (a hidden unit on the tile) leave the rest of the plan to run.
    const ts::Action& a = cands[best];
    auto& me = bc::self();
    if (a.pre_slot >= 0 && spell_ready(a.pre_slot)) {
        try {
            const auto ab = me.abilities()[a.pre_slot];
            const auto kind = spells[a.pre_slot].kind;
            bool ok = false;
            if (kind == bc::ability_kind::aoe_damage) ok = ab.use(vec2{a.pre_x, a.pre_y});
            else if (kind == bc::ability_kind::shield || kind == bc::ability_kind::attack_reset) ok = ab.use();
            else if (a.pre_target >= 0 && eref[a.pre_target]) ok = ab.use(eref[a.pre_target]->unit);
            if (ok) cast_done = true;
        } catch (const std::exception& ex) {
            LOG("ts cast error %s\n", ex.what());
        }
    }
    if (a.dash_slot >= 0 && spell_ready(a.dash_slot)) {
        try {
            if (me.abilities()[a.dash_slot].use(vec2{a.dash_x, a.dash_y})) {
                cast_done = true;
                pos = vec2{a.dash_x, a.dash_y};
            }
        } catch (const std::exception& ex) {
            LOG("ts dash error %s\n", ex.what());
        }
    }
    if (a.move_x >= 0 && me.can_move()) {
        try {
            if (me.move_absolute(vec2{a.move_x, a.move_y})) {
                pos = vec2{a.move_x, a.move_y};
                walked = true;
            }
        } catch (const std::exception& ex) {
            LOG("ts move error %s\n", ex.what());
        }
    }
    if (a.attack >= 0 && eref[a.attack]) {
        const EnemyRec& e = *eref[a.attack];
        if (attack_unit(e.unit, e.pos) && a.reset_slot >= 0) use_reset_and_attack(e.unit, e.pos);
    }
    return true;
}

// Opponent model: for every enemy seen this round and last round within 3 tiles of us, record whether it moved
// away (backed off) against its health fifth last round.
void Bot::update_opp_model() {
    std::vector<OppSeen> now;
    now.reserve(w.enemies.size());
    for (const auto& e : w.enemies) {
        const int dd = cheb(e.pos, pos);
        const float frac = e.hp / std::max(e.max_hp, 1.0f);
        for (const auto& o : opp_last)
            if (o.id == e.id && o.round == round - 1 && o.dist <= 3) {
                const int b = std::clamp(static_cast<int>(o.frac * 5.0f), 0, 4);
                ++opp_obs[b];
                opp_ret[b] += dd > o.dist;
            }
        now.push_back({e.id, e.pos, frac, dd, round});
    }
    opp_last.swap(now);
}

// The health fraction below which this opponent backs off: the threshold (in fifths) that best separates backing
// off from staying, with a prior pulling to 0.25. -1 until 12 observations below 80% health.
float Bot::opp_flee_estimate() const {
    // Above 80% health "moving away" is mostly repositioning or chasing someone else, so only wounded enemies count.
    int total = 0;
    for (int b = 0; b < 4; ++b) total += opp_obs[b];
    if (total < 12) return -1.0f;
    float best_t = 0.25f, best_s = -1e9f;
    for (int k = 0; k <= 4; ++k) { // threshold k / 5: below it they back off
        float s = 0;
        for (int b = 0; b < 4; ++b) s += b < k ? static_cast<float>(opp_ret[b]) : static_cast<float>(opp_obs[b] - opp_ret[b]);
        const float t = static_cast<float>(k) / 5.0f;
        s -= 3.0f * std::fabs(t - 0.25f); // prior
        if (s > best_s) best_s = s, best_t = t;
    }
    return std::clamp(best_t, 0.05f, 0.7f);
}

// Fight or run, by search (APEX_TS_DECIDE): play the next rounds forward twice, once with us fighting and once
// with us running (everyone else on the usual policy; both enemy models while fuel lasts), judge both end
// states with the learned exchange rates, and return +1 (fight), -1 (run) or 0 (no clear answer, or no fuel).
// The local-fight evaluator's 22 inputs for unit 0 (same definitions as tools/local_fights.py).
static void local_features(const ts::State& s, const ts::Map& m, int round, float* f) {
    const ts::Unit& me = s.u[0];
    auto d = [&](const ts::Unit& u) { return ts::cheb(me.x, me.y, u.x, u.y); };
    int k = 0;
    f[k++] = static_cast<float>(round) / 1000.0f;
    f[k++] = me.range <= 1 ? 1.0f : 0.0f;
    f[k++] = me.hp / std::max(me.max_hp, 1.0f);
    f[k++] = me.hp / 1000.0f;
    f[k++] = me.str / 100.0f;
    f[k++] = static_cast<float>(me.gems) / 50.0f;
    f[k++] = static_cast<float>((me.sp[0].cd == 0) + (me.sp[1].cd == 0)) / 2.0f;
    float an = 0, ahp = 0, astr = 0, amin = 1, aclose = 0, en = 0, ehp = 0, estr = 0, emin = 1, enear = 6, egems = 0, erng = 0, eclose = 0, eready = 0;
    for (int i = 1; i < s.n; ++i) {
        const ts::Unit& u = s.u[i];
        if (!u.alive() || d(u) > 6) continue;
        const float frac = u.hp / std::max(u.max_hp, 1.0f);
        if (u.team == 0) {
            an += 1, ahp += u.hp, astr += u.str, amin = std::min(amin, frac), aclose += d(u) <= 2;
        } else {
            en += 1, ehp += u.hp, estr += u.str, emin = std::min(emin, frac), enear = std::min(enear, static_cast<float>(d(u)));
            egems += u.gems, erng += u.range > 1, eclose += d(u) <= 2, eready += (u.sp[0].cd == 0) + (u.sp[1].cd == 0);
        }
    }
    const float fs[] = {an / 3.0f, ahp / 1000.0f, astr / 100.0f, amin, aclose / 3.0f, en / 3.0f, ehp / 1000.0f, estr / 100.0f, emin,
        enear / 6.0f, egems / 50.0f, erng / 3.0f, eclose / 3.0f, eready / 4.0f,
        static_cast<float>(ts::cheb(me.x, me.y, m.home_x[0], m.home_y[0])) / 30.0f};
    for (float v : fs) f[k++] = v;
}

// A plan's worth: what the simulated rounds won or lost (lives at the phase's value plus bags), plus the
// learned evaluator's prediction for the next 10 rounds from where we stand at the end (APEX_TS_LOCALNET).
static float plan_value(const ts::State& start, const ts::State& end, const ts::Map& m, int round, float life) {
    float v = 0;
    for (int i = 0; i < start.n; ++i) {
        if (!start.u[i].alive() || end.u[i].alive()) continue;
        const float lost = life + static_cast<float>(start.u[i].gems);
        v += start.u[i].team == 0 ? -lost : lost;
    }
    if (end.u[0].alive()) {
        float f[local_model::kIn];
        local_features(end, m, round, f);
        v += local_model::eval(f);
    }
    return v;
}
// The fight and the flight themselves stay c1's (positioning, kiting, the escape planner).
int Bot::tactical_decide() {
    PROF(tdecide);
#if APEX_PROFILE
    prof::td_round = round;
#endif
#if A2_TEL
    // Status: 0 no eligible enemy, 1 safety reserve, 2 predicted budget, 3 incomplete, 4 inside margin, 5 fight, 6 run.
    PROF_CHECK("td0");
    int a2_scene = 1;
    for (const auto& e : w.enemies) a2_scene += e.hp > 0 && cheb(e.pos, pos) <= 8;
    for (const auto& a : w.allies) a2_scene += cheb(a.pos, pos) <= 7;
    a2_scene = std::min(a2_scene, 12);
    const std::uint64_t a2_f0 = bc::fuel_remaining();
#define A2RET(st, v)                                                                                                   \
    do {                                                                                                               \
        a2ts::snap.status = st;                                                                                        \
        a2tel::td_status(a2_scene, st);                                                                                \
        a2tel::bump(11u * 4096 + static_cast<std::uint32_t>(st) * 8 + (a2ts::snap.omit_reach ? 1u : 0u) +              \
            (a2ts::snap.link_partial ? 2u : 0u) + (a2ts::snap.dropped_enemies > 0 ? 4u : 0u));                         \
        PROF_CHECK("td1");                                                                                             \
        return v;                                                                                                      \
    } while (0)
#elif A2_SNAP || A2_TD_AUTH
#define A2RET(st, v)                                                                                                   \
    do {                                                                                                               \
        a2ts::snap.status = st;                                                                                        \
        return v;                                                                                                      \
    } while (0)
#else
#define A2RET(st, v) return v
#endif
    if (bc::fuel_remaining() < (tune::kDet ? static_cast<std::uint64_t>(tune::kDetSafety) + 10000
                                           : static_cast<std::uint64_t>(tune::kTsReserve) + 30000))
        A2RET(1, 0);
    ts::State s;
    ts::Map m;
    const EnemyRec* eref[ts::kMaxUnits] = {};
    if (!ts_snapshot(s, m, eref)) A2RET(0, 0);
    if (tune::kTsPhantom && tune::kBelief &&
        (tune::kDet || bc::fuel_remaining() > static_cast<std::uint64_t>(tune::kTsReserve) + 45000)) {
        // Reinforcements (APEX_TS_PHANTOM): enemies we cannot see that could join before the horizon, from the
        // beliefs (expected enemies within reach minus the visible ones there). Each whole expected one enters the
        // playouts as a fresh copy of the nearest visible enemy, a horizon's walk away on the enemies' side.
        const int reach = 2 + tune::kTsDecideRounds;
        int nearest = -1, visible_in = 0;
        for (int i = 1; i < s.n; ++i) {
            if (s.u[i].team != 1) continue;
            const int dd = ts::cheb(s.u[i].x, s.u[i].y, pos.x, pos.y);
            visible_in += dd <= reach;
            if (nearest < 0 || dd < ts::cheb(s.u[nearest].x, s.u[nearest].y, pos.x, pos.y)) nearest = i;
        }
        const float hidden = w.expected_enemies(pos, reach) - static_cast<float>(visible_in);
        int add = static_cast<int>(hidden + 0.4f); // 0.6 expected -> one phantom
        if (nearest >= 0)
            for (; add > 0 && s.n < ts::kMaxUnits; --add) {
                const ts::Unit& src = s.u[nearest];
                const int dx = ts::sgn(src.x - pos.x), dy = ts::sgn(src.y - pos.y);
                int px = -1, py = -1;
                for (int k = reach; k >= 2 && px < 0; --k)
                    for (int jx = -1; jx <= 1 && px < 0; ++jx)
                        for (int jy = -1; jy <= 1 && px < 0; ++jy) {
                            const int x = pos.x + dx * k + jx, y = pos.y + dy * k + jy;
                            if (ts::free_tile(s, m, x, y)) px = x, py = y;
                        }
                if (px < 0) break;
                ts::Unit ph = src;
                ph.x = static_cast<std::int16_t>(px);
                ph.y = static_cast<std::int16_t>(py);
                ph.hp = ph.max_hp;
                ph.gems = 0;
                ph.link = -1;
                ph.stunned = 0;
                ph.flags = static_cast<std::uint8_t>(ts::U_ALIVE | (src.flags & (ts::U_SPLASH | ts::U_STUN_IMMUNE | ts::U_RESET_ON_KILL | ts::U_RUIN)));
                for (auto& sp : ph.sp)
                    if (sp.cd < 99) sp.cd = 0;
                s.u[s.n++] = ph;
            }
    }
    // Weights of the fight-or-run search, in banked gems. Defaults: learned in self-play (a life 8 -> 25 gems by
    // round 450, a health bar 3, a carried gem 0.75). NOVA_TD_*: set from real games (tools/exchange_fit.py).
    const float t = std::min(1.0f, static_cast<float>(round) / static_cast<float>(NOVA_TD_ROUND));
    const float life = NOVA_TD_LIFE0 + (NOVA_TD_LIFE1 - NOVA_TD_LIFE0) * t;
    ts::Weights wts{life, NOVA_TD_HP_SHARE > 0.0f ? NOVA_TD_HP_SHARE * life : NOVA_TD_HP, tune::kTsThreat, NOVA_TD_GEM};
    ts::Policy models[2];
    models[0].flee[0] = models[1].flee[0] = tune::kTsAllyFlee;
    models[0].flee[1] = tune::kTsFleeA;
    models[1].flee[1] = tune::kTsFleeC;
    if (tune::kOppModel) {
        // This opponent's learned back-off health, bracketed by the two models.
        const float est = opp_flee_estimate();
        if (est >= 0.0f) {
            models[0].flee[1] = std::max(0.02f, est - 0.1f);
            models[1].flee[1] = std::min(0.8f, est + 0.1f);
        }
    }
#if A2_ENEMY_NET
    for (auto& mdl : models) {
        mdl.enemy_net = true;
        mdl.round = round;
    }
#endif
    if (tune::kTsCalib) {
        // Calibrated against the engine (tools/simcheck.py, 2,590 real fight rounds): units engage only when they win
        // the race (aggression 1.4), no automatic double hits, units run below 25-45% health, and the team that
        // has acted more this round started it.
        int acted[2] = {0, 0};
        for (int i = 1; i < s.n; ++i)
            if (s.u[i].flags & ts::U_ACTED) ++acted[s.u[i].team];
        for (auto& mdl : models) {
            mdl.aggr[0] = mdl.aggr[1] = 1.4f;
            mdl.use_reset = false;
            mdl.first = acted[1] >= acted[0] ? 1 : 0;
        }
        models[0].flee[0] = models[1].flee[0] = 0.35f;
        models[0].flee[1] = 0.25f;
        models[1].flee[1] = 0.45f;
    }
    // Lab knobs 24-29: the verdict's weights (a life, health, threat, a carried gem) and flee models (enemy, ours).
    wts.alive *= std::exp(0.3f * LABK(24));
    wts.hp *= std::exp(0.3f * LABK(25));
    wts.threat *= std::exp(0.3f * LABK(26));
    wts.gem *= std::exp(0.3f * LABK(27));
    if (LABK(28) != 0.0f || LABK(29) != 0.0f)
        for (auto& mdl : models) {
            mdl.flee[1] = std::clamp(mdl.flee[1] + 0.1f * LABK(28), 0.02f, 0.9f);
            mdl.flee[0] = std::clamp(mdl.flee[0] + 0.1f * LABK(29), 0.02f, 0.9f);
        }
    float v[2][2] = {};
    int done = 0;
    std::uint64_t worst = 8000;
    int rounds = std::max(1, tune::kTsDecideRounds + static_cast<int>(std::lround(LABK(31)))); // lab knob 31: horizon
    std::uint64_t reserve = static_cast<std::uint64_t>(tune::kTsReserve);
    if (tune::kTsBudget) {
        // Budgeted search (APEX_TS_BUDGET): a playout costs ~0.7-1k fuel x units^2 (tools/simbench.py: 15k with 4
        // units, 42-49k with 8), so a big fight used to burn 40-70k on one playout, decide nothing and run the turn
        // out of fuel. Predict the cost first, shorten the horizon if that makes a full comparison fit, and never
        // start a model whose two playouts cannot both finish above the reserve.
        reserve = static_cast<std::uint64_t>(tune::kTsBudgetReserve);
        const auto n2 = static_cast<std::uint64_t>(s.n * s.n);
        worst = static_cast<std::uint64_t>(tune::kTsUnitCost) * n2 * static_cast<std::uint64_t>(rounds + 1) / 4;
        const std::uint64_t left = bc::fuel_remaining();
        while (rounds > 1 && left < reserve + 2 * worst) {
            --rounds;
            worst = static_cast<std::uint64_t>(tune::kTsUnitCost) * n2 * static_cast<std::uint64_t>(rounds + 1) / 4;
        }
        if (left < reserve + 2 * worst) return 0;
    }
    int n_models = 2;
    if (tune::kDet) {
        // Deterministic (APEX_DET): the plan depends on the fight size only. Predicted playout cost
        // kDetUnitCost per unit per simulated round; drop to one enemy model, then shorten the horizon, until the
        // playouts fit kDetTsBudget. The fuel left only matters below the safety floor.
        auto cost = [&](int r) {
            return static_cast<std::uint64_t>(tune::kDetUnitCost) * static_cast<std::uint64_t>(s.n) * static_cast<std::uint64_t>(r + 1);
        };
        while (static_cast<std::uint64_t>(n_models * 2) * cost(rounds) > static_cast<std::uint64_t>(tune::kDetTsBudget)) {
            if (n_models == 2) n_models = 1;
            else if (rounds > 2) --rounds; // a one-round horizon cannot tell a fight from a flight
            else A2RET(2, 0);
        }
        worst = cost(rounds);
        reserve = static_cast<std::uint64_t>(tune::kDetSafety);
    }
#if A2_TEL
    {
        const std::uint64_t prep = a2_f0 - bc::fuel_remaining();
        a2tel::td_prep(std::min(s.n, 8), prep);
    }
#endif
    ts_ran_round = round;
    for (int model = 0; model < n_models; ++model) {
        bool complete = true;
        for (int plan = 0; plan < 2; ++plan) { // 0 fight, 1 run
            const std::uint64_t left = bc::fuel_remaining();
            // Budgeted: only the playouts this model still needs must fit; unbudgeted: the old rule.
            const std::uint64_t need = tune::kTsBudget || tune::kDet ? static_cast<std::uint64_t>(2 - plan) * worst : 2 * worst;
            if (left < reserve + need) {
                complete = false;
                break;
            }
            ts::State c = s;
            ts::Policy pol = models[model];
            pol.root_mode = plan == 0 ? 1 : 2;
            ts::act(c, m, 0, pol); // our turn, now
            ts::rollout(c, m, pol, rounds);
            v[model][plan] = tune::kTsLocalNet ? plan_value(s, c, m, round, wts.alive) : ts::evaluate(c, wts);
            const std::uint64_t now = bc::fuel_remaining();
#if A2_TEL
            if (left > now) a2tel::td_cost(std::min(s.n, 8), std::min(rounds, 3), left - now);
#endif
            if (!tune::kDet && now < left) worst = std::max(worst, left - now);
        }
        if (!complete) break;
        ++done;
    }
#if APEX_PROFILE
    {
        const std::uint64_t out_fuel = bc::fuel_remaining();
        if (out_fuel < 35000)
            std::printf("TDLOW R%d units %d done %d worst %llu left %llu\n", round, s.n, done, static_cast<unsigned long long>(worst),
                static_cast<unsigned long long>(out_fuel));
    }
#endif
    if (done == 0) A2RET(3, 0);
    float fight = 0, run = 0;
    for (int k = 0; k < done; ++k) fight += v[k][0], run += v[k][1];
    fight /= static_cast<float>(done);
    run /= static_cast<float>(done);
#ifdef APEX_TSLOG
    std::printf("TD R%d %s units %d models %d fight %.1f run %.1f -> %s\n", round, bc::to_string(type).c_str(), s.n, done, fight, run,
        fight > run + tune::kTsDecideMargin ? "FIGHT" : run > fight + tune::kTsDecideMargin ? "RUN" : "-");
#endif
#if A2_TS_VIS
    fight += A2_TS_FIGHT_BIAS; // refit of the verdict for the vision-aware playouts (+ leans to fight)
#endif
    const float margin = std::max(0.0f, tune::kTsDecideMargin + LABK(30)); // lab knob 30: decide margin
    if (fight > run + margin) A2RET(5, 1);
    if (run > fight + margin) A2RET(6, -1);
    A2RET(4, 0);
#undef A2RET
}

// Team commander (APEX_TFC): plays three team plans forward APEX_TFC_ROUNDS rounds against both enemy models:
// everyone here fights as one (on one focus target), everyone runs, or each follows its own policy. Returns
// 1 (engage, focus = the enemy's handle), 2 (retreat) or 0 (no plan beats the status quo by the margin).
int Bot::team_decide(std::uint32_t& focus_handle) {
    PROF(tfc);
    focus_handle = 0;
    if (bc::fuel_remaining() < static_cast<std::uint64_t>(tune::kTsReserve) + 30000) return 0;
    ts::State s;
    ts::Map m;
    const EnemyRec* eref[ts::kMaxUnits] = {};
    if (!ts_snapshot(s, m, eref)) return 0;
    bool any_ally = false;
    for (int i = 1; i < s.n; ++i) any_ally |= s.u[i].team == 0;
    if (!any_ally && !tune::kTfcSolo) return 0;
    // Focus target: the enemy within 6 of us that dies fastest for what it is worth.
    int focus = -1;
    float best_key = 1e30f;
    for (int i = 1; i < s.n; ++i) {
        const ts::Unit& u = s.u[i];
        if (u.team != 1 || !u.alive() || ts::cheb(u.x, u.y, s.u[0].x, s.u[0].y) > 6) continue;
        const float key = (u.hp + u.shield) / (1.0f + static_cast<float>(u.gems) / 30.0f);
        if (key < best_key) best_key = key, focus = i;
    }
    if (focus < 0) return 0;
    const float t = std::min(1.0f, static_cast<float>(round) / 450.0f);
    const ts::Weights wts{NOVA_TD_LIFE0 + (NOVA_TD_LIFE1 - NOVA_TD_LIFE0) * t, 3.0f, tune::kTsThreat, 0.75f};
    int acted[2] = {0, 0};
    for (int i = 1; i < s.n; ++i)
        if (s.u[i].flags & ts::U_ACTED) ++acted[s.u[i].team];
    ts::Policy models[2];
    for (auto& mdl : models) {
        mdl.aggr[0] = mdl.aggr[1] = 1.4f; // engine-calibrated engagement for whoever follows the policy
        mdl.use_reset = true;
        mdl.first = acted[1] >= acted[0] ? 1 : 0;
        mdl.flee[0] = 0.35f;
        mdl.focus[0] = focus;
    }
    models[0].flee[1] = 0.25f;
    models[1].flee[1] = 0.45f;
    float v[2][3] = {};
    int done = 0;
    std::uint64_t worst = 8000;
    for (int model = 0; model < 2; ++model) {
        bool complete = true;
        for (int plan = 0; plan < 3; ++plan) { // 0 status quo, 1 all fight, 2 all run
            const std::uint64_t left = bc::fuel_remaining();
            if (left < static_cast<std::uint64_t>(tune::kTsReserve) + 2 * worst) {
                complete = false;
                break;
            }
            ts::State c = s;
            ts::Policy pol = models[model];
            pol.team_mode[0] = plan;
            ts::act(c, m, 0, pol);
            ts::rollout(c, m, pol, tune::kTfcRounds);
            v[model][plan] = ts::evaluate(c, wts);
            const std::uint64_t now = bc::fuel_remaining();
            if (now < left) worst = std::max(worst, left - now);
        }
        if (!complete) break;
        ++done;
    }
    if (done == 0) return 0;
    float mean[3] = {};
    for (int k = 0; k < done; ++k)
        for (int p2 = 0; p2 < 3; ++p2) mean[p2] += v[k][p2] / static_cast<float>(done);
#ifdef APEX_TSLOG
    std::printf("TFC R%d %s units %d models %d quo %.1f fight %.1f run %.1f\n", round, bc::to_string(type).c_str(), s.n, done, mean[0],
        mean[1], mean[2]);
#endif
    if (mean[1] >= mean[2] && mean[1] > mean[0] + (tune::packOn ? NOVA_PACK_MARGIN : tune::kTfcMargin)) {
        focus_handle = eref[focus] ? eref[focus]->id : 0;
        return focus_handle ? 1 : 0;
    }
    if (mean[2] > mean[1] && mean[2] > mean[0] + (tune::packOn ? NOVA_PACK_MARGIN : tune::kTfcMargin)) return 2;
    return 0;
}
// ---------------------------------------------------------------- caster micro (APEX_CMICRO)
// A ranged champion moves OR basic-attacks each turn (GameRules), and most caster nukes exclude walking, so every
// fight turn is a choice between holding a tile to shoot and stepping. Score each option: stay (best basic attack
// plus any ready spell) or step to a free neighbour (plus walk-compatible spells, cast from either tile), as damage
// dealt (with kill and stun bonuses) minus risk x the damage the visible enemies can put on that tile before our next
// turn: a step plus their basic range (two more with a ready dash), their ready offensive spells, less for enemies an
// ally of ours stands nearer to, nothing from enemies stunned or killed this turn. Awake camps add their hits.
bool Bot::caster_micro(const EnemyRec* target, bool engage) {
#if A2_TEL
    a2tel::CallCost a2_cost{7};
#endif
    (void)target;
    auto& me = bc::self();
    struct Threat {
        const EnemyRec* e;
        int reach;             // basic attack reach next turn: step + range (+2 with a dash ready)
        int sreach;            // offensive spell reach (cast range, +1 when the spell allows walking)
        float basic, spell;    // damage of each
        float cover;           // 1, or 0.6 when one of our allies stands nearer to it than the tile in question
        bool stunned;
        float value;           // what killing it is worth (life plus bag), in health points
    };
    Threat th[8];
    int nt = 0;
    for (const auto& e : w.enemies) {
        if (nt >= 8 || cheb(e.pos, pos) > 9 || e.hp <= 0) continue;
        Threat& t = th[nt++];
        t.e = &e;
        const Kit& k = kit_of(e.type);
        bool dash = false;
        float sval = 0.0f;
        int sr = -1;
        for (int s = 0; s < 2; ++s) {
            std::int32_t cd = 0;
            if (d::sdk_champion_cooldown(e.id, static_cast<std::uint32_t>(s), &cd) != 0) cd = 0; // unknown: ready
            if (cd != 0) continue;
            const KitSpell& ks = k.sp[s];
            if (ks.kind == ts::K_DASH) dash = true;
            if ((ks.kind == ts::K_DAMAGE || ks.kind == ts::K_CC || ks.kind == ts::K_AOE) && (ks.flags & ts::SF_ENEMY)) {
                const float v = ks.mod * e.focus;
                const int r = ks.range + ((ks.flags & ts::SF_EXCL_WALK) ? 0 : 1);
                if (v > sval) sval = v, sr = r;
            }
        }
        t.reach = e.range + 1 + (dash ? 2 : 0);
        t.sreach = sr;
        t.basic = e.strength;
        t.spell = sval;
        t.stunned = false;
        d::buff_data buffs[6];
        std::uint32_t nb = 0;
        if (d::sdk_champion_buff_data(e.id, buffs, 6, &nb) == 0)
            for (std::uint32_t i = 0; i < nb && i < 6; ++i)
                if (buffs[i].type == 1 && buffs[i].data.stun.duration > 0) t.stunned = true;
        if (e.tributing() || e.recalling()) t.stunned = true; // channelling: it will not hit back this turn
        t.value = 300.0f + 4.0f * static_cast<float>(e.gems);
        t.cover = 1.0f;
    }
    if (nt == 0) return false;
#if A2_TEL
    struct A2NtCost {
        const int& nt;
        std::uint64_t f0 = bc::fuel_remaining();
        std::uint32_t r0 = bc::round_number();
        ~A2NtCost() {
            a2tel::bump(14u * 4096 + static_cast<std::uint32_t>(nt) * 100 +
                static_cast<std::uint32_t>(std::min<std::uint64_t>(a2tel::spent(f0, r0) / 1000, 99)));
        }
    } a2_ntcost{nt};
#endif
    const float frac = hp / std::max(max_hp, 1.0f);
    float risk = tune::kCMicroRisk * std::exp(0.3f * LABK(32)) * (1.0f + 1.5f * (1.0f - frac)); // lab knob 32
    if (type == bc::champion_type::cassi) risk *= tune::kCiRisk; // her death takes Issac too
    if (NOVA_CMICRO_MELEE && type == bc::champion_type::issac) risk *= tune::kCiRisk; // so does his
    if (!engage) risk *= 1.5f;

#if A2_CMICRO_FAST
    // Each threat's hit on a tile and the awake camps reaching it depend on the tile only (nine candidates): compute
    // them once per tile and sum in the original order, so every danger value is bit-identical to the direct loop.
    struct TileDanger {
        vec2 q{-1, -1};
        float hit[8];
        float camp[32];
        int ncamp = 0;
    };
    TileDanger td_cache[9];
    int n_td = 0;
    // Awake camps that can reach any tile within 1 of us (within their range + 1 of us), in index order: the same camps,
    // in the same order, as World::awake_camps_near returns for each tile, without a map-wide scan per tile.
    int near_camps[32];
    int n_near = -1;
    auto camps_near = [&](vec2 q, float* out, int& n_out) {
        n_out = 0;
        if (!bit(w.hot_zone, q)) return;
        if (n_near < 0) {
            n_near = 0;
            for (std::size_t ci = 0; ci < w.camps.size() && n_near < 32; ++ci) {
                const auto& c = w.camps[ci];
                if (!c.dead && c.strength > 0 && c.hp < c.max_hp && cheb(c.pos, pos) <= c.range + 1) near_camps[n_near++] = static_cast<int>(ci);
            }
        }
        for (int k = 0; k < n_near && n_out < 32; ++k) {
            const auto& c = w.camps[static_cast<std::size_t>(near_camps[k])];
            if (cheb(c.pos, q) <= c.range) out[n_out++] = c.strength;
        }
    };
    auto tile_danger = [&](vec2 q) -> const TileDanger& {
        for (int k = 0; k < n_td; ++k)
            if (td_cache[k].q == q) return td_cache[k];
        TileDanger& c = td_cache[n_td < 9 ? n_td++ : 8];
        c.q = q;
        for (int i = 0; i < nt; ++i) {
            const Threat& t = th[i];
            const int dq = cheb(t.e->pos, q);
            float hit = (dq <= t.reach ? t.basic : 0.0f) + (dq <= t.sreach ? t.spell : 0.0f);
            if (hit > 0.0f)
                for (const auto& a : w.allies)
                    if (cheb(a.pos, t.e->pos) < dq) {
                        hit *= 0.6f;
                        break;
                    }
            c.hit[i] = hit;
        }
        camps_near(q, c.camp, c.ncamp);
        return c;
    };
    auto danger_at = [&](vec2 q, int stunned_i, int killed_i) {
        const TileDanger& c = tile_danger(q);
        float dmg = 0.0f;
        for (int i = 0; i < nt; ++i) {
            if (i == stunned_i || i == killed_i || th[i].stunned || c.hit[i] <= 0.0f) continue;
            dmg += c.hit[i];
        }
        for (int k = 0; k < c.ncamp; ++k) dmg += c.camp[k];
#if A2_CHECK
        { // the original computation, compared bit for bit (kind 16: 0 equal, 1 different)
            float ref = 0.0f;
            for (int i = 0; i < nt; ++i) {
                const Threat& t = th[i];
                if (i == stunned_i || i == killed_i || t.stunned) continue;
                const int dq = cheb(t.e->pos, q);
                float hit = (dq <= t.reach ? t.basic : 0.0f) + (dq <= t.sreach ? t.spell : 0.0f);
                if (hit <= 0.0f) continue;
                for (const auto& a : w.allies)
                    if (cheb(a.pos, t.e->pos) < dq) {
                        hit *= 0.6f;
                        break;
                    }
                ref += hit;
            }
            for (int ci : w.awake_camps_near(q)) ref += w.camps[ci].strength;
            a2tel::bump(16u * 4096 + (std::memcmp(&ref, &dmg, sizeof(float)) != 0 ? 1u : 0u));
        }
#endif
        return dmg;
    };
#else
    auto danger_at = [&](vec2 q, int stunned_i, int killed_i) {
        float dmg = 0.0f;
        for (int i = 0; i < nt; ++i) {
            const Threat& t = th[i];
            if (i == stunned_i || i == killed_i || t.stunned) continue;
            const int dq = cheb(t.e->pos, q);
            float hit = (dq <= t.reach ? t.basic : 0.0f) + (dq <= t.sreach ? t.spell : 0.0f);
            if (hit <= 0.0f) continue;
            for (const auto& a : w.allies)
                if (cheb(a.pos, t.e->pos) < dq) {
                    hit *= 0.6f;
                    break;
                }
            dmg += hit;
        }
        for (int ci : w.awake_camps_near(q)) dmg += w.camps[ci].strength;
        return dmg;
    };
#endif
    // Our spells usable against champions: slot, damage, stun, area radius (-1 single), walk-compatible.
    struct MySpell {
        int slot;
        float dmg;
        bool stun, reset;
        int radius, range;
        bool walk_ok;
    };
    MySpell ms[2];
    int nms = 0;
    for (int s = 0; s < 2; ++s) {
        if (!spell_ready(s)) continue;
        const auto& sp = spells[s];
        if (sp.kind == bc::ability_kind::attack_reset) {
            ms[nms++] = {s, 0.0f, false, true, -1, 0, true};
            continue;
        }
        if (!sp.enemies) continue;
        if (sp.kind == bc::ability_kind::damage || sp.kind == bc::ability_kind::cc || sp.kind == bc::ability_kind::aoe_damage)
            ms[nms++] = {s, sp.modifier * focus, sp.kind == bc::ability_kind::cc,
                false, sp.kind == bc::ability_kind::aoe_damage ? std::max(1, static_cast<int>(sp.radius)) : -1,
                static_cast<int>(sp.range), !sp.excludes_walk};
    }
    struct Option {
        vec2 to;
        int attack = -1;     // threat index for the basic attack (stay only)
        int spell = -1;      // index into ms
        int spell_on = -1;   // threat index (centre for area spells)
        bool cast_first = true;
        float score = -1e30f;
    };
    Option best;
    const bool can_attack = me.can_attack();
    const bool can_move = me.can_move();
    auto evaluate = [&](vec2 at, bool stay, int atk, int sp_i, int sp_on, vec2 cast_from) {
        float dmg_to[8] = {};
        int stunned_i = -1;
        float offense = 0.0f;
        if (sp_i >= 0) {
            const MySpell& s = ms[sp_i];
            if (s.reset) {
                if (atk < 0) return -1e30f;
                dmg_to[atk] += strength; // second basic attack
            } else {
                if (sp_on < 0 || cheb(cast_from, th[sp_on].e->pos) > s.range) return -1e30f;
                if (s.radius >= 0) {
                    for (int i = 0; i < nt; ++i)
                        if (cheb(th[i].e->pos, th[sp_on].e->pos) <= s.radius) dmg_to[i] += s.dmg;
                } else {
                    dmg_to[sp_on] += s.dmg;
                }
                if (s.stun && !th[sp_on].stunned) stunned_i = sp_on;
            }
        }
        if (atk >= 0) {
            // Ranged basic attacks end movement; melee champions may step first (NOVA_CMICRO_MELEE).
            if ((!stay && !melee) || !can_attack || cheb(at, th[atk].e->pos) > range) return -1e30f;
            dmg_to[atk] += strength;
        }
        int killed_i = -1;
        for (int i = 0; i < nt; ++i) {
            if (dmg_to[i] <= 0.0f) continue;
            const float eff = th[i].e->hp;
            offense += std::min(dmg_to[i], eff) * (1.0f + static_cast<float>(th[i].e->gems) / 30.0f) *
                (NOVA_STUN_FOCUS > 0.0f && th[i].stunned ? 1.0f + NOVA_STUN_FOCUS : 1.0f);
            if (dmg_to[i] >= eff) {
                offense += th[i].value;
                killed_i = i;
            }
        }
        if (stunned_i >= 0) offense += 60.0f; // a stunned champion cannot chase, flee or hit an ally either
        float danger = danger_at(at, stunned_i, killed_i);
        if (danger >= hp) danger *= 3.0f; // lethal tiles: almost never
        return offense - risk * danger;
    };
    auto consider = [&](vec2 at, bool stay, int atk, int sp_i, int sp_on, bool cast_first) {
        const vec2 from = cast_first ? pos : at;
        const float s = evaluate(at, stay, atk, sp_i, sp_on, from);
        if (s > best.score) {
            best.score = s;
            best.to = at;
            best.attack = atk;
            best.spell = sp_i;
            best.spell_on = sp_on;
            best.cast_first = cast_first;
        }
    };
    // Stay: every basic target (or none) with every spell choice.
    for (int a = -1; a < nt; ++a) {
        if (a >= 0 && (!can_attack || cheb(pos, th[a].e->pos) > range)) continue;
        consider(pos, true, a, -1, -1, true);
        for (int s = 0; s < nms; ++s) {
            if (ms[s].reset) {
                consider(pos, true, a, s, -1, true);
                continue;
            }
            for (int o = 0; o < nt; ++o) consider(pos, true, a, s, o, true);
        }
    }
    const float stay_score = best.score;
    // Steps: no basic attack; walk-compatible spells from either tile.
    if (can_move) {
        static const vec2 kSteps[8] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (vec2 dlt : kSteps) {
            const vec2 q = pos + dlt;
            if (q.x < 0 || q.y < 0 || q.x >= w.width || q.y >= w.height || bit(w.static_blocked, q) || bit(w.unit_tiles, q)) continue;
            consider(q, false, -1, -1, -1, true);
            if (melee && can_attack)
                for (int a = 0; a < nt; ++a) {
                    if (cheb(q, th[a].e->pos) > range) continue;
                    consider(q, false, a, -1, -1, true); // step, then hit
                    for (int s = 0; s < nms; ++s)
                        if (ms[s].reset) consider(q, false, a, s, -1, true);
                        else if (ms[s].walk_ok)
                            for (int o = 0; o < nt; ++o) consider(q, false, a, s, o, false);
                }
            for (int s = 0; s < nms; ++s) {
                if (!ms[s].walk_ok || ms[s].reset) continue;
                for (int o = 0; o < nt; ++o) {
                    consider(q, false, -1, s, o, true);
                    consider(q, false, -1, s, o, false);
                }
            }
        }
    }
    (void)stay_score;
#if A2_TEL
    // Split of the option-evaluation cost (kind 15) from the action execution that follows (kind 14 keeps the total).
    a2tel::bump(15u * 4096 + static_cast<std::uint32_t>(nt) * 100 +
        static_cast<std::uint32_t>(std::min<std::uint64_t>(a2tel::spent(a2_ntcost.f0, a2_ntcost.r0) / 1000, 99)));
#endif
    // Nothing to shoot and nothing threatens us here: leave the turn to farming.
    if (best.to == pos && best.attack < 0 && best.spell < 0 && danger_at(pos, -1, -1) <= 0.0f) return false;
    // Melee without a hit this turn: closing in, chasing and fleeing belong to the normal fight logic.
    if (melee && best.attack < 0 && best.spell < 0) return false;
    auto do_spell = [&]() {
        if (best.spell < 0 || cast_done) return;
        const MySpell& s = ms[best.spell];
        try {
            const auto ab = me.abilities()[s.slot];
            bool ok = false;
            if (s.reset) ok = ab.use();
            else if (s.radius >= 0) ok = ab.use(th[best.spell_on].e->pos);
            else ok = ab.use(th[best.spell_on].e->unit);
            if (ok) cast_done = true;
#ifdef APEX_SPELLSTAT
            if (ok && !s.reset) ++spellstat_enemy;
#endif
        } catch (const std::exception& ex) {
            LOG("cmicro cast error %s\n", ex.what());
        }
    };
    const bool reset_spell = best.spell >= 0 && ms[best.spell].reset;
    if (best.cast_first && !reset_spell) do_spell();
    if (best.to != pos) {
        try {
            if (me.move_absolute(best.to)) {
                pos = best.to;
                walked = true;
            }
        } catch (const std::exception& ex) {
            LOG("cmicro move error %s\n", ex.what());
        }
    }
    if (!best.cast_first) do_spell();
    if (best.attack >= 0) {
        const EnemyRec& e = *th[best.attack].e;
        if (attack_unit(e.unit, e.pos) && reset_spell) use_reset_and_attack(e.unit, e.pos);
    }
    return true;
}
