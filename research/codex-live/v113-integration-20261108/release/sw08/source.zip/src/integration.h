#pragma once
#include <cstdint>
// Same executable sections for all mechanism arms; only initialized data differs.
inline volatile std::uint32_t integration_flags[2] = {15, 1};
inline bool integration_enabled(std::uint32_t bit) {
    return integration_flags[1] == 1 && (integration_flags[0] & bit) != 0;
}
