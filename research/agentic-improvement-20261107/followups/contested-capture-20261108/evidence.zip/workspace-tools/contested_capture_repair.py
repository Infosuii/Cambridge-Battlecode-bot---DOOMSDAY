"""Repair release handoff and use matched full-eligibility guard controls."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import sys
import contested_capture_pilot as original
BASE=original.BASE
sys.path.insert(0,str(BASE/'autonomy'))
import benchmark
from native_job import lease
from parallel_native_audit import run as audit
from table_offsets import same_code
from store import DATA,save
from representative_search import STYLES

ID='contested-capture-release-repair-20261108'
WD=BASE/'training/runs/contested-capture-repair-20261108'
METHOD=original.METHOD
REPLACEMENTS=[
 ('if (release_control[1] != 1 || release_control[0] == 0) return false;', 'if (release_control[1] != 1) return false;'),
 ('if (gi < 0 && contested_release_group >= 0 && round < contested_release_until) gi = contested_release_group;',
  'const bool continuing = contested_release_group >= 0 && round < contested_release_until;\n    if (continuing) gi = contested_release_group;'),
 ('if (group.state != GroupState::reward || !bit(group.tiles, pos)) return false;',
  'if (group.state != GroupState::reward || (!continuing && !bit(group.tiles, pos))) return false;'),
 ('std::uint32_t anchor = my_id;', 'std::uint32_t anchor = bit(group.tiles, pos) ? my_id : 0xffffffffu;'),
 ('if (anchor == my_id) {','if (anchor == my_id || anchor == 0xffffffffu) {'),
 ('if (gi != contested_release_group || round >= contested_release_until) {',
  'if (release_control[0] == 0) return false; // matched control runs the same eligibility work\n    if (gi != contested_release_group || round >= contested_release_until) {'),
 ('    target_group = -1;\n    write_claim(-1);',
  '    if (target_group == gi) { target_group = -1; write_claim(-1); }')]
for old,new in REPLACEMENTS:
    assert METHOD.count(old)==1,old
    METHOD=METHOD.replace(old,new)

def patches(enabled):
    result=original.patches(enabled)
    old=original.METHOD.replace('ENABLED',str(enabled))
    assert result[1]['new'].count(old)==1
    result[1]['new']=result[1]['new'].replace(old,METHOD.replace('ENABLED',str(enabled)))
    return result
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    with lease(WD,ID) as status:
        benchmark.CONFIG['jobs']=16
        parents={'o':'auto_bank_arrive_original','l':'auto_bank_arrive_learned'}
        def build(job):
            tag,enabled=job;name=f'auto_cr8_{tag}_c{enabled}';src=benchmark.ARENA/'bots'/name/'src';source=benchmark.ARENA/'bots'/parents[tag]/'src';edits=patches(enabled)
            if not src.exists():benchmark.make(name,template=parents[tag],changes=edits)
            for p in source.iterdir():
                if not p.is_file():continue
                changes=[c for c in edits if c['path']==p.name]
                if changes:
                    text=p.read_text(encoding='utf-8')
                    for c in changes:assert text.count(c['old'])==1;text=text.replace(c['old'],c['new'])
                    assert (src/p.name).read_text(encoding='utf-8')==text
                else:assert (src/p.name).read_bytes()==p.read_bytes()
            return name,{'source':benchmark.digest(src),'wasm':sha(benchmark.build(name))}
        status(phase='Compiling repaired handoff/full-guard controls')
        with ThreadPoolExecutor(max_workers=2) as pool:variants=dict(pool.map(build,[(t,e) for t in parents for e in (0,1)]))
        for t in parents:assert same_code(benchmark.build(f'auto_cr8_{t}_c0'),benchmark.build(f'auto_cr8_{t}_c1'))
        previous=read(original.WD/'frozen-plan.json');maps={BASE/p:h for p,h in previous['maps'].items()}
        assert all(sha(p)==h for p,h in maps.items())
        cached_root=DATA/'benchmarks'/(original.ID+'-pilot');cached=read(cached_root/'results.json')
        assert sha(cached_root/'results.json')==read(cached_root/'both-team-audit.json')['results_sha256']
        plan={'script_sha256':sha(__file__),'v1_script_sha256':sha(original.__file__),'variants':variants,'maps':previous['maps'],
              'cached_results_sha256':sha(cached_root/'results.json'),'scope':'Same12 diagnostic maps. Full-eligibility on/off code identical outside data; handoff persists across new target and preserves the assigned job. No new tuning, no official actions, no strength promotion.'}
        if (WD/'frozen-plan.json').exists():assert read(WD/'frozen-plan.json')==plan
        else:save(WD/'frozen-plan.json',plan)
        label=ID+'-new';status(phase='Repaired on/off mechanism games',workers=16)
        rows=read(DATA/'benchmarks'/label/'results.json') if (DATA/'benchmarks'/label/'results.json').exists() else benchmark.run(label,list(variants),list(maps),STYLES)
        save(DATA/'benchmarks'/label/'both-team-audit.json',audit(label,8))
        combined=rows+cached;save(WD/'combined-results.json',combined)
        report={n:benchmark.compare(combined,n) for n in [*variants,*parents.values()]}
        save(WD/'outcomes.json',report)
        assert sha(__file__)==plan['script_sha256'] and sha(original.__file__)==plan['v1_script_sha256']
        for n,s in variants.items():assert benchmark.digest(benchmark.ARENA/'bots'/n/'src')==s['source'] and sha(benchmark.build(n))==s['wasm']
        print(json.dumps({n:{'ref_gain':r['gain'],'direct':r['direct_score'],'n':r['direct_n']} for n,r in report.items()}),flush=True)

if __name__=='__main__':main()
