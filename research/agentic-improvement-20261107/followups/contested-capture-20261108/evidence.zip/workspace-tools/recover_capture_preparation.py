"""Reconcile only the verified, terminated pre-game cache-preparation process."""
import ctypes
import json
from pathlib import Path
import shutil
import confirm_contested_capture as old


def main():
    runtime = old.read(old.WD / 'runtime.json')
    assert runtime['pid'] == 3844 and runtime['status'] == 'running'
    assert runtime['phase'] == 'Verifying frozen sources and exact cached raw controls'
    process = ctypes.windll.kernel32.OpenProcess(0x1000, False, 3844)
    if process:
        ctypes.windll.kernel32.CloseHandle(process)
        raise RuntimeError('Old process still exists; refusing lease recovery')
    assert not (old.WD / 'frozen-plan.json').exists()
    assert not (old.DATA / 'benchmarks' / (old.ID + '-new')).exists()
    supervisor = old.BASE / 'training/supervisor.json'
    lock = old.BASE / 'training/training.lock'
    assert old.read(supervisor) == runtime
    assert lock.read_text(encoding='utf-8') == '3844'
    archive = old.WD / 'failed-preparation-receipt.json'
    assert not archive.exists()
    old.save(archive, {'previous': runtime, 'diagnosis': '2538 of 2592 raw controls cached; adgato-gemcombat3 absent. No frozen plan or new benchmark existed.',
                       'recovery': 'Verified PID 3844 command and preparation phase, terminated it, verified absent. V2 runs 54 missing raw controls and caches build identities once.'})
    shutil.copy2(Path(old.__file__), old.WD / 'failed-preparation-script.py')
    stopped = dict(runtime, status='failed', error='Preparation cache completeness assumption; superseded by v2 before new games')
    old.save(old.WD / 'runtime.json', stopped)
    old.save(supervisor, stopped)
    lock.unlink()
    print('Verified stale preparation lease reconciled; no game results changed.')


if __name__ == '__main__':
    main()
