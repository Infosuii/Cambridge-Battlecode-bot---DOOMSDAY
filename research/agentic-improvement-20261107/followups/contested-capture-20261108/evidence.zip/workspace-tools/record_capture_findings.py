"""Record completed evidence and leave an accurate continuation handoff."""
from pathlib import Path
import json
import shutil
import sys
import numpy as np
import confirm_contested_capture_v2 as experiment

BASE, DATA, WD = experiment.BASE, experiment.DATA, experiment.WD
sys.path.insert(0, str(BASE / 'autonomy'))
from campaign import record
from store import now, save


def effect(rows, candidate, control, direct=False):
    indexed = {(r['candidate'], r['opponent'], r['map'], r['side']): r for r in rows}
    by_map, by_style, flips = {}, {}, {'wins': 0, 'losses': 0, 'same': 0}
    for row in rows:
        if row['candidate'] != candidate or (row['opponent'] == 'v111') != direct:
            continue
        old = indexed[(control, row['opponent'], row['map'], row['side'])]
        value = row['score'] - old['score']
        by_map.setdefault(row['map'], []).append(value)
        by_style.setdefault(row['opponent'], []).append(value)
        flips['wins' if value > 0 else 'losses' if value < 0 else 'same'] += 1
    values = np.asarray([np.mean(v) for _, v in sorted(by_map.items())])
    rng = np.random.default_rng(611921607)
    samples = values[rng.integers(len(values), size=(4000, len(values)))].mean(axis=1)
    return {'maps': len(values), 'cells': sum(len(v) for v in by_map.values()),
            'score_delta': float(values.mean()), 'map_cluster95': np.quantile(samples, [.025, .975]).tolist(),
            'by_style': {k: float(np.mean(v)) for k, v in by_style.items()}, 'flips': flips}


def main():
    assert experiment.read(WD / 'runtime.json')['status'] == 'complete'
    label = experiment.ID + '-combined'
    root = DATA / 'benchmarks' / label
    rows = experiment.read(root / 'results.json')
    audit = experiment.read(root / 'both-team-audit.json')
    assert audit['results_sha256'] == experiment.sha(root / 'results.json')
    assert audit['both_teams_zero_faults_and_codes'] and audit['cells'] == 6048
    outcomes = experiment.read(WD / 'outcomes.json')
    plan = experiment.read(WD / 'frozen-plan.json')
    effects = {}
    for arm in ('o', 'l'):
        on, off = f'auto_cr8_{arm}_c1', f'auto_cr8_{arm}_c0'
        effects[arm] = {'reference': effect(rows, on, off), 'direct': effect(rows, on, off, True)}
    save(WD / 'on-off-effects.json', effects)
    findings = {
        'at': now(), 'classification': 'Retry required; mechanism retained, no new promotion',
        'live_release': 'v112, auto_bank_arrive_learned, independently observed active at 06:14 UTC',
        'new_games': 1512 + 864 + 54 + 3456,
        'confirmation': {'maps': 48, 'new_candidate_games': 3456, 'new_control_games': 54,
                         'reused_control_cells': 2538, 'audited_cells': 6048,
                         'exposure': plan['scope'], 'outcomes': outcomes, 'on_off_effects': effects},
        'direct_loss_audit': experiment.read(DATA / 'experiments/direct-regressions-v112-20261108/summary.json'),
        'mechanism_replays': experiment.read(DATA / 'experiments/contested-capture-mechanism-20261108/report.json'),
        'limits': 'Diagnostic pilots are selected cases. The confirmation was not parameter-tuned, '
                  'but has older project exposure and is not a ladder-frequency sample. On/off pairs '
                  'have identical executable Wasm sections; source/scaffold overhead versus raw parents '
                  'remains part of deployment performance. No new official action was performed.',
        'next_action': 'Inspect whether leaving one anchor concedes the large reward. Test a coordinated '
                       'retention policy with sufficient defenders and handoff persistence, versus both '
                       'matched controls and raw parents. Check costs before another broad retune. '
                       'Require separate frozen validation before calling it a strength improvement.'}
    save(WD / 'findings.json', findings)
    for identity, path, mechanism in [
        ('direct-regressions-v112-20261108', DATA / 'experiments/direct-regressions-v112-20261108/summary.json',
         'Direct v111 losses decomposed into score sources, then selected exact replays decoded.'),
        ('contested-capture-release-20261108', experiment.prior.repair.original.WD / 'outcomes.json',
         'Release surplus low-bag healthy champions from a legally contested reward while retaining an anchor.'),
        ('contested-capture-release-repair-20261108', experiment.prior.repair.WD / 'outcomes.json',
         'Preserve release across new farm assignment, retain new target, match full eligibility checks.'),
        (experiment.ID, WD / 'findings.json',
         'Frozen 48-map, nine-style confirmation with complete exact control coverage and native audits.')]:
        record(identity, classification='Retry required', phase='completed local evidence',
               mechanism=mechanism, evidence=str(path), evidence_sha256=experiment.sha(path),
               official_actions=0, next_action=findings['next_action'])
    lines = ['# Contested capture repair: completed local evidence', '',
             'v112 remains the delivered experimental bot. No replacement was uploaded or activated.', '',
             'This continuation played 5,886 new local games. The final 48-map comparison contains '
             '6,048 audited cells, including 2,538 exact reused controls. Both teams had zero faults '
             'and diagnostic codes; fuel events were explicitly checked, not assumed absent.', '',
             '| Candidate | Reference gain vs v111 | Direct score vs v111 |',
             '|---|---:|---:|']
    for name, report in outcomes.items():
        comparison = report['comparison']
        lines.append(f"| {name} | {comparison['gain'] * 100:+.3f} pp | "
                     f"{comparison['direct_score']:g}/{comparison['direct_n']} |")
    lines += ['', 'Reference gains and direct scores are different comparisons. Candidate-wise 95% '
              'map-cluster intervals and paired on/off effects are in the accompanying JSON.', '',
              'The original failure was a contested capture, established in the unmodified replay '
              'through legal capture-state observations. Three healthy champions waited hundreds of '
              'rounds. The logging probe changed the trajectory and is explicitly excluded as '
              'evidence of the original decision.', '',
              'The repaired learned bot flipped the selected vault game against v111: common-horizon '
              'camp income rose from 442 to 884. Against nnm4 on the same map, a win became a loss: '
              'common-horizon camp income fell from 379 to 28, with deaths rising from four to twelve. '
              'This supports investigating objective retention; fewer idle rounds alone is not success.', '',
              'The initial confirmation stopped before games because it assumed complete cached '
              'controls after replacing exposed maps. The missing 54 controls were run explicitly. '
              'Maps and repair candidates were unchanged. Failed preparation and recovery receipts '
              'are preserved locally.', '', findings['limits'], '', 'Next: ' + findings['next_action'], '']
    text = '\n'.join(lines)
    (WD / 'FINDINGS.md').write_text(text, encoding='utf-8')
    current = BASE / 'CURRENT_WORK.md'
    marker = '\n## Completed capture-repair confirmation, 8 November 2026\n'
    existing = current.read_text(encoding='utf-8')
    if marker not in existing:
        current.write_text(existing + marker + '\n' + text, encoding='utf-8')
    local = Path(__file__).resolve().parent
    handoff = local / 'DELIVERY_HANDOFF.md'
    heading = '# Current state after capture-repair confirmation\n\n'
    old_handoff = handoff.read_text(encoding='utf-8')
    if not old_handoff.startswith(heading):
        handoff.write_text(heading + text + '\nEarlier delivery handoff follows as historical context; '
                           'its remaining-upload checklist is already completed.\n\n---\n\n' + old_handoff,
                           encoding='utf-8')
    print(json.dumps({'findings': str(WD / 'FINDINGS.md'),
                      'outcomes': {n: {'gain': r['comparison']['gain'],
                                       'direct': r['comparison']['direct_score']} for n, r in outcomes.items()},
                      'effects': effects}), flush=True)


if __name__ == '__main__':
    main()
