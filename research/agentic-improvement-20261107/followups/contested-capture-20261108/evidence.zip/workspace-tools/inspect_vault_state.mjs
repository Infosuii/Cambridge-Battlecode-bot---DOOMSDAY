import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const base='C:/projects/cambridge battlecode/work/agentic-improvement';
const {engine,defaultAssets}=await import(pathToFileURL(base+'/autonomy/replay/engine.mjs').href);
const root=base+'/autonomy/data/experiments/direct-regressions-v112-20261108';
const item=JSON.parse(fs.readFileSync(root+'/panel.json','utf8')).find(x=>x.map==='published/00vault');
const E=await engine(defaultAssets());E.load(fs.readFileSync(item.replay));
const {X,dv,check,out,args,tsnap}=E;
check(X.Game_API_Map_GetNumCampGroups(E.h,out));const count=dv().getUint32(out,true);
check(X.Game_API_Map_GetCampGroups(E.h,E.buf,count,out));
const ids=Array.from({length:count},(_,i)=>dv().getUint32(E.buf+4*i,true));
const physical=[];
for(const id of ids){
 check(X.Game_API_Map_CampGroup_GetCampInfo(E.h,id,E.buf,1000,out));const n=dv().getUint32(out,true);
 const members=Array.from({length:n},(_,i)=>dv().getUint32(E.buf+4*i,true));const tiles=[];
 for(const member of members){check(X.Game_API_Map_CampInfo_Get(E.h,member,out));tiles.push({x:dv().getInt32(out,true),y:dv().getInt32(out+4,true)});}
 physical.push({id,tiles});
}
check(X.Game_Visualiser_Timeline_GetMain(E.h,out));const main=dv().getBigUint64(out,true);
check(X.Game_Visualiser_Timeline_Seek(E.h,main,0,0));
const snapshots=[];let last=-1;
for(let i=0;i<200000;i++){
 check(X.Game_Visualiser_ReadTimelineState(E.h,tsnap));const d=dv();const round=d.getUint32(tsnap+8,true),phase=d.getUint32(tsnap+24,true);
 if(round!==last&&phase===10&&[40,50,100,200,300,375].includes(round)){
  const s=E.PC.I(d,tsnap);const observed=[];
  for(const group of physical){
   const rc=X.Game_API_CampGroup_GetCaptureState(E.h,E.perspective(1,5),group.id,out);
   observed.push({id:group.id,rc,...(!rc?{timer:dv().getInt32(out,true),capture_state:dv().getInt32(out+4,true)}:{})});
  }
  const visibleEnemies=s.champions.filter(c=>c.team===0&&c.alive).map(c=>({id:c.entity.index,rc:X.Game_API_Champion_Get(E.h,E.perspective(1,5),c.entity.index,E.buf)}));
  snapshots.push({round,state:s,observed,physical,visibleEnemies});last=round;
  if(snapshots.length===1){console.log('keys',JSON.stringify(Object.keys(s)));for(const k of Object.keys(s))if(/group|altar|spawn|capt/i.test(k))console.log(k,JSON.stringify(s[k]).slice(0,10000));}
 }
 if(round>375||d.getUint32(tsnap+28,true))break;
 check(X.Game_Visualiser_Timeline_ReplayNext(E.h,1));
}
fs.writeFileSync(root+'/vault-full-world-samples.json',JSON.stringify(snapshots,(_,v)=>typeof v==='bigint'?v.toString():v));
console.log('saved',snapshots.length);E.destroy();
