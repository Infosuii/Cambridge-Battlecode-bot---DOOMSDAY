"""Rank direct v111 losses by native score accounting, then decode six cases."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import shutil
import subprocess
import sys
import uuid
import zipfile
BASE=Path(r'C:\projects\cambridge battlecode\work\agentic-improvement')
sys.path.insert(0,str(BASE/'autonomy'))
from mistake_review import ledger, components
from native_capture import validate
from store import save
ROOT=BASE/'autonomy/data/experiments/direct-regressions-v112-20261108'
PARENT='auto_bank_arrive_learned'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    ROOT.mkdir(exist_ok=True)
    source=BASE/'training/runs/delivery-parent-comparison-20261108/pooled-results.json'
    rows=json.loads(source.read_text(encoding='utf-8'))
    direct=[r for r in rows if r['candidate']==PARENT and r['opponent']=='v111']
    assert len(direct)==328
    records=[]
    for r in direct:
        native=json.loads(Path(r['file']).read_text(encoding='utf-8'))
        assert all(validate(native,t,'3.0.0')==0 for t in ('teamA','teamB')) and not native['diagnostics']['codes']
        totals=ledger(native);team='team'+r['side'].upper();other='teamB' if team=='teamA' else 'teamA'
        parts=components(totals,team)
        assert abs(sum(parts.values())-(totals[team]['submitted']-totals[other]['submitted']))<1e-6
        records.append({**r,'parts':parts,'own':dict(totals[team]),'other':dict(totals[other]),
                        'rounds':native['match']['roundsCompleted'],'margin':sum(parts.values()),'native_sha256':sha(r['file'])})
    losses=[r for r in records if r['score']==0]
    selected=[];seen=set()
    def pick(label,key,predicate=lambda r:True):
        available=[r for r in losses if r['map'] not in seen and predicate(r)]
        if available:
            r=min(available,key=key);selected.append({'reason':label,**r});seen.add(r['map'])
    pick('unbanked-bag-deficit',lambda r:r['parts']['held'])
    pick('large-bag-no-banking',lambda r:-r['own']['held'],lambda r:r['own']['submitted']==0 and r['own']['held']>=100)
    pick('clean-farming-deficit',lambda r:r['parts']['camp_collection'],lambda r:r['own'].get('death',0)==0)
    pick('farming-deficit',lambda r:r['parts']['camp_collection'])
    pick('combat-transfer-deficit',lambda r:r['parts']['champion_collection']+r['parts']['champion_loss'])
    pick('fuel-heavy-loss',lambda r:-r['own'].get('fuelExhausted',0))
    grouped=Counter()
    for r in losses:
        p=r['parts'];scores={'farm':p['camp_collection'],'combat':p['champion_collection']+p['champion_loss'],'camp_loss':p['camp_loss'],'held':p['held']}
        grouped[min(scores,key=scores.get)]+=1
    save(ROOT/'all-direct-cells.json',records);save(ROOT/'selected.json',selected)
    save(ROOT/'summary.json',{'candidate':PARENT,'games':len(records),'score':sum(r['score'] for r in records),'losses':len(losses),
         'largest_grouped_shortfall':dict(grouped),'source_sha256':sha(source),'scope':'Direct candidate-v111 games only; native score decomposition is descriptive. One map per diagnostic case, no claim of failure frequency from selected extremes.'})
    panel=[]
    for r in selected:
        bundle=next(Path(r['replay']).glob('*.repl26a'))
        with zipfile.ZipFile(bundle) as z:raw=z.read('replay.repl26a')
        mid=str(uuid.uuid5(uuid.NAMESPACE_URL,'direct-v112:'+r['file']))
        replay=ROOT/(mid+'.repl26a');replay.write_bytes(raw)
        panel.append({'match':mid,'map':r['map'],'reason':r['reason'],'side':0 if r['side']=='a' else 1,'our_version':PARENT,
                      'replay':str(replay),'sha256':sha(replay),'summary':r['file'],'summary_sha256':r['native_sha256']})
    save(ROOT/'panel.json',panel)
    run=subprocess.run([shutil.which('node') or 'node',str(BASE/'autonomy/replay/review.mjs'),str(ROOT/'panel.json'),str(ROOT/'decoded.json')],cwd=BASE,capture_output=True,encoding='utf-8',errors='replace',timeout=180)
    (ROOT/'decoder.log').write_text(run.stdout+run.stderr,encoding='utf-8');assert run.returncode==0,run.stderr[-1000:]
    print(json.dumps({'summary':json.loads((ROOT/'summary.json').read_text(encoding='utf-8')),'selected':[{'reason':r['reason'],'map':r['map'],'side':r['side'],'margin':r['margin'],'held':r['own']['held'],'banked':r['own']['submitted'],'deaths':r['own'].get('death',0)} for r in selected]}))

if __name__=='__main__':main()
