"""Common-horizon diagnostics; distinguish idle release from objective concession."""
import review_capture_mechanism as mechanism
from mistake_review import ledger


def main():
    panel = mechanism.read(mechanism.ROOT / 'panel.json')
    grouped = {}
    for item in panel:
        grouped.setdefault(item['reason'], []).append(item)
    reports = []
    for reason, items in grouped.items():
        horizon = min(mechanism.read(i['summary'])['match']['roundsCompleted'] for i in items)
        for item in items:
            decoded = mechanism.read(mechanism.ROOT / ('decoded-' + item['match'] + '.json'))
            native = mechanism.read(item['summary'])
            team = 'teamA' if item['side'] == 0 else 'teamB'
            own = [b for b in decoded['bodies'] if b['team'] == team]
            snapshots = {}
            for t in (50, 100, 150, 300, 500):
                snapshots[t] = []
                for body in own:
                    state = next((h for h in body['history'] if h['round'] == t), None)
                    if state:
                        snapshots[t].append({'id': body['id'], 'alive': state['alive'],
                                             'pos': state.get('p'), 'gems': state['gems']})
            entries = lambda b: [c for c in b['collections'] if c['round'] <= horizon]
            report = {'reason': reason, 'candidate': item['our_version'],
                      'file': mechanism.Path(item['summary']).name,
                      'common_horizon': horizon, 'rounds': native['match']['roundsCompleted'],
                      'final_scores': decoded['final_scores'], 'final_ledger': ledger(native),
                      'common_horizon_camp_gems': sum(c['value'] for b in own for c in entries(b)
                                                      if c['context'] == 'campGroup'),
                      'common_horizon_deaths': sum(d['round'] <= horizon for b in own for d in b['deaths']),
                      'snapshots': snapshots}
            reports.append(report)
    mechanism.save(mechanism.ROOT / 'common-horizon-details.json', reports)
    print(mechanism.json.dumps([{k: v for k, v in r.items() if k != 'snapshots'} for r in reports]))


if __name__ == '__main__':
    main()
