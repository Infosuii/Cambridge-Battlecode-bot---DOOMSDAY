"""Small self-verifying supplement; preserve earlier published archives unchanged."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import confirm_contested_capture_v2 as experiment

BASE, DATA, WD = experiment.BASE, experiment.DATA, experiment.WD
LOCAL = Path(__file__).resolve().parent
OUT = LOCAL / 'research/agentic-improvement-20261107/followups/contested-capture-20261108'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert experiment.read(WD / 'runtime.json')['status'] == 'complete'
    assert (WD / 'FINDINGS.md').exists()
    assert not OUT.exists(), 'Existing supplement must be verified, never blindly replaced'
    OUT.mkdir(parents=True)
    files = {}
    def add(path):
        path = Path(path)
        assert path.is_file()
        name = path.relative_to(BASE).as_posix()
        if name in files:
            assert files[name] == path
        files[name] = path
    for folder in (experiment.prior.repair.original.WD, experiment.prior.repair.WD,
                   experiment.prior.WD, WD):
        for path in folder.glob('*'):
            if path.is_file() and path.suffix in ('.json', '.py', '.md'):
                add(path)
    labels = [experiment.prior.repair.original.ID + '-pilot', experiment.prior.repair.ID + '-new',
              experiment.ID + '-raw', experiment.ID + '-new', experiment.ID + '-combined']
    for label in labels:
        root = DATA / 'benchmarks' / label
        for name in ('manifest.json', 'results.json', 'both-team-audit.json',
                     'parallel-native-hashes.json', 'parallel-native-audit.json', 'lineage.json'):
            if (root / name).exists():
                add(root / name)
    for folder_name in ('direct-regressions-v112-20261108', 'contested-capture-mechanism-20261108'):
        folder = DATA / 'experiments' / folder_name
        for name in ('summary.json', 'selected.json', 'panel.json', 'decoded.json', 'report.json',
                     'common-horizon-details.json', 'vault-full-world-samples.json'):
            if (folder / name).exists():
                add(folder / name)
    for identity in ('direct-regressions-v112-20261108', 'contested-capture-release-20261108',
                     'contested-capture-release-repair-20261108', experiment.ID):
        add(DATA / 'experiments' / identity / 'record.json')
    variants = {**experiment.read(experiment.prior.repair.original.WD / 'frozen-plan.json')['variants'],
                **experiment.read(experiment.prior.repair.WD / 'frozen-plan.json')['variants']}
    for name, identity in variants.items():
        source = experiment.benchmark.ARENA / 'bots' / name / 'src'
        assert experiment.benchmark.digest(source) == identity['source']
        wasm = experiment.benchmark.build(name)
        assert sha(wasm) == identity['wasm']
        for path in source.rglob('*'):
            if path.is_file():
                add(path)
        add(wasm)
        for filename in ('build-receipt.json', 'candidate.json'):
            add(source.parent / filename)
    for path in set(experiment.read(WD / 'frozen-plan.json')['maps']) | set(
            experiment.read(experiment.prior.repair.original.WD / 'frozen-plan.json')['maps']):
        add(BASE / path)
    for name in ('direct_failure_audit.py', 'inspect_vault_state.mjs', 'probe_vault_waits.py',
                 'contested_capture_pilot.py', 'contested_capture_repair.py',
                 'confirm_contested_capture.py', 'confirm_contested_capture_v2.py',
                 'recover_capture_preparation.py', 'review_capture_mechanism.py',
                 'capture_regression_details.py', 'record_capture_findings.py',
                 'export_capture_findings.py', 'published_pool.py'):
        files['workspace-tools/' + name] = LOCAL / name
    archive = OUT / 'evidence.zip'
    index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for name, path in sorted(files.items()):
            assert '..' not in Path(name).parts and not Path(name).is_absolute()
            raw = path.read_bytes()
            zipped.writestr(name, raw)
            index.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        assert set(zipped.namelist()) == {row['path'] for row in index}
        for row in index:
            raw = zipped.read(row['path'])
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    manifest = {'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
                'verified_entries': len(index), 'entries': index,
                'exclusions': ['Raw native per-game captures', 'Replay bundles and full decoded round histories',
                               'Credentials and action database', 'Installed runtimes and compiler executables'],
                'scope': 'Experimental sources are research evidence; no release or ladder promotion of this repair. '
                         'Paths inside receipts refer to the original local cache. Earlier published evidence is unchanged.'}
    (OUT / 'index.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    shutil.copy2(WD / 'FINDINGS.md', OUT / 'README.md')
    shutil.copy2(WD / 'findings.json', OUT / 'findings.json')
    print(json.dumps({'archive': str(archive), 'sha256': manifest['archive_sha256'],
                      'bytes': manifest['archive_bytes'], 'verified_entries': len(index)}))


if __name__ == '__main__':
    main()
