"""Replay-based mechanism check for matched release controls, including regressions."""
from pathlib import Path
import json
import shutil
import subprocess
import uuid
import zipfile
import contested_capture_repair as experiment

BASE = experiment.BASE
ROOT = BASE / 'autonomy/data/experiments/contested-capture-mechanism-20261108'
read, sha, save = experiment.read, experiment.sha, experiment.save


def main():
    ROOT.mkdir(exist_ok=True)
    source = experiment.WD / 'combined-results.json'
    rows = read(source)
    off, on = 'auto_cr8_l_c0', 'auto_cr8_l_c1'
    keys = lambda r: (r['opponent'], r['map'], r['side'])
    indexed = {name: {keys(r): r for r in rows if r['candidate'] == name}
               for name in (off, on)}
    selected = [('known-idle-vault', ('v111', '00vault', 'b'))]
    regressions = sorted(k for k in indexed[off] if indexed[on][k]['score'] < indexed[off][k]['score'])
    improvements = sorted(k for k in indexed[off] if indexed[on][k]['score'] > indexed[off][k]['score'])
    if regressions:
        selected.append(('first-sorted-regression', regressions[0]))
    panel = []
    for reason, key in selected:
        for name in (off, on):
            row = indexed[name][key]
            bundle = next(Path(row['replay']).glob('*.repl26a'))
            mid = str(uuid.uuid5(uuid.NAMESPACE_URL, 'capture-mechanism:' + row['file']))
            path = ROOT / (mid + '.repl26a')
            with zipfile.ZipFile(bundle) as archive:
                path.write_bytes(archive.read('replay.repl26a'))
            panel.append({'match': mid, 'map': row['map'], 'reason': reason,
                          'side': 0 if row['side'] == 'a' else 1, 'our_version': name,
                          'replay': str(path), 'sha256': sha(path), 'summary': row['file'],
                          'summary_sha256': sha(row['file']), 'score': row['score']})
    save(ROOT / 'panel.json', panel)
    result = subprocess.run([shutil.which('node') or 'node', str(BASE / 'autonomy/replay/review.mjs'),
                             str(ROOT / 'panel.json'), str(ROOT / 'decoded.json')],
                            cwd=BASE, capture_output=True, encoding='utf-8', errors='replace', timeout=180)
    (ROOT / 'decoder.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    assert result.returncode == 0, result.stderr[-1500:]
    summaries = []
    for item in read(ROOT / 'decoded.json'):
        team = 'teamA' if item['side'] == 0 else 'teamB'
        own = [body for body in item['bodies'] if body['team'] == team]
        summaries.append({'candidate': item['our_version'], 'reason': item['reason'],
                          'map': item['map'], 'score': item['score'],
                          'score_roster_bag_parity': item['score_roster_bag_parity'],
                          'camp_gems': sum(body['camp_gems'] for body in own),
                          'deaths': sum(body['death_count'] for body in own),
                          'stationary_no_attack_cast_channel_samples': sum(
                              body['stationary_no_attack_cast_or_channel_samples'] for body in own),
                          'longest_stationary_runs': sorted([
                              dict(body_id=body['id'], **run) for body in own for run in body['stationary_runs']],
                              key=lambda run: run['end'] - run['start'], reverse=True)[:4]})
    report = {'input_sha256': sha(source), 'script_sha256': sha(__file__),
              'on_off_flips': {'improvements': len(improvements), 'regressions': len(regressions)},
              'cases': summaries,
              'limits': 'Selected diagnostic cases, not an effect-size estimate. Stationary waits can be intentional. '
                        'Replay state is offline evidence, never bot input. Matched on/off Wasm code identity '
                        'is recorded in the repair experiment; broader comparison is separate.'}
    save(ROOT / 'report.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
