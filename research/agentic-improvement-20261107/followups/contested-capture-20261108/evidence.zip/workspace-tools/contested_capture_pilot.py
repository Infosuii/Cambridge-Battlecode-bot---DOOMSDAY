"""Local mechanism pilot: free surplus bodies from a stalled contested reward."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import sys
BASE=Path(r'C:\projects\cambridge battlecode\work\agentic-improvement')
sys.path.insert(0,str(BASE/'autonomy'))
import benchmark
from native_job import lease
from parallel_native_audit import run as audit
from store import DATA,save
from table_offsets import same_code
from representative_search import STYLES

ID='contested-capture-release-20261108'
WD=BASE/'training/runs/contested-capture-pilot-20261108'
METHOD='''bool Bot::release_contested_capture() {
    static volatile int release_control[2] = {ENABLED, 1};
    if (release_control[1] != 1 || release_control[0] == 0) return false;
    int gi = target_group;
    if (gi < 0 && contested_release_group >= 0 && round < contested_release_until) gi = contested_release_group;
    if (gi < 0 || gi >= static_cast<int>(w.groups.size()) || gems >= 40 ||
        hp < 0.6f * max_hp || heading_home || win_now()) return false;
    const auto& group = w.groups[gi];
    if (group.state != GroupState::reward || !bit(group.tiles, pos)) return false;
    for (const auto& enemy : w.enemies)
        if (cheb(enemy.pos, pos) <= std::max(5, range + 1)) return false;
    std::uint32_t anchor = my_id;
    for (const auto& ally : w.allies) {
        if (ally.id >= anchor || ally.hp < 0.6f * ally.max_hp || !bit(group.tiles, ally.pos)) continue;
        try {
            const int bag = static_cast<int>(ally.unit.gem_count());
            if (bag >= 40 || ally_score + bag >= static_cast<int>(bc::constants::winning_gems)) continue;
        } catch (...) { continue; }
        anchor = ally.id;
    }
    if (anchor == my_id) {
        // Do not retain an old exclusion after the visible anchor has left.
        if (gi == contested_release_group && round < contested_release_until) {
            avoid_until[gi] = std::min(avoid_until[gi], round);
            contested_release_until = round;
        }
        return false;
    }
    d::camp_group_capture_state capture{};
    if (d::sdk_camp_group_capture_state(group.handle, &capture) != 0 || capture.state != 2) return false;
    if (round - my_claim_since < std::max(2, capture_time + 1) && gi != contested_release_group) return false;
    if (gi != contested_release_group || round >= contested_release_until) {
        contested_release_group = gi;
        contested_release_until = round + std::max(2 * capture_time, std::min(60, group.respawn));
    }
    avoid_until[gi] = std::max(avoid_until[gi], contested_release_until);
    if (nn_group == gi) nn_group = -1;
    target_group = -1;
    write_claim(-1);
    return true;
}

'''

def patches(enabled):
    return [
        {'path':'bot.h','old':'    int target_group = -1;','new':'    int contested_release_group = -1, contested_release_until = -1;\n    bool release_contested_capture();\n    int target_group = -1;'},
        {'path':'bot.cpp','old':'bool Bot::handle_enemies() {','new':METHOD.replace('ENABLED',str(enabled))+'bool Bot::handle_enemies() {'},
        {'path':'bot.cpp','old':'    const bool fought =\n','new':'    const bool released_capture = release_contested_capture();\n    const bool fought = !released_capture && (\n'},
        {'path':'bot.cpp','old':'        handle_enemies();\n','new':'        handle_enemies());\n'},
        {'path':'bot.cpp','old':'#ifdef A2_NN_NEED\n','new':'    if (round < contested_release_until) {\n        if (nn_group == contested_release_group) nn_group = -1;\n        if (best == contested_release_group) best = score_groups(1, best_need, best_score);\n    }\n#ifdef A2_NN_NEED\n'},
        {'path':'pressure.cpp','old':'        if (g.state != GroupState::reward || bit(g.tiles, pos)) continue;','new':'        if (g.state != GroupState::reward || bit(g.tiles, pos)) continue;\n        if (gi == contested_release_group && round < contested_release_until) continue;'}]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))

def main():
    with lease(WD,ID) as status:
        benchmark.CONFIG['jobs']=16
        parents={'o':'auto_bank_arrive_original','l':'auto_bank_arrive_learned'}
        jobs=[(f'auto_cc8_{tag}_c{enabled}',parent,enabled) for tag,parent in parents.items() for enabled in (0,1)]
        def build(job):
            name,parent,enabled=job;changes=patches(enabled);target=benchmark.ARENA/'bots'/name/'src';source=benchmark.ARENA/'bots'/parent/'src'
            if not target.exists():benchmark.make(name,template=parent,changes=changes)
            for p in source.iterdir():
                if not p.is_file():continue
                relevant=[c for c in changes if c['path']==p.name]
                if relevant:
                    text=p.read_text(encoding='utf-8')
                    for c in relevant:assert text.count(c['old'])==1,(name,c['old']);text=text.replace(c['old'],c['new'])
                    assert (target/p.name).read_text(encoding='utf-8')==text
                else:assert (target/p.name).read_bytes()==p.read_bytes()
            return name,{'source':benchmark.digest(target),'wasm':sha(benchmark.build(name))}
        status(phase='Compiling fixed-code matched on/off controls')
        with ThreadPoolExecutor(max_workers=2) as pool:identities=dict(pool.map(build,jobs))
        for tag in parents:assert same_code(benchmark.build(f'auto_cc8_{tag}_c0'),benchmark.build(f'auto_cc8_{tag}_c1'))
        maps=[benchmark.ARENA/'maps'/(n+'.map26a') for n in ['00vault','04comb','04orchard','00stampede','00contest','03homonoliths','04barbell','00dunes']]
        roles=read(DATA/'experiments/bounded-retune-data-20261107/data-plan.json')['roles']['train']
        maps += [BASE/p for p in roles if 'maps_rt7_train' in p][:4]
        assert len(maps)==12 and len({sha(p) for p in maps})==12
        names=['v111',*parents.values(),*identities]
        plan={'script_sha256':sha(__file__),'variants':identities,'parents':{n:{'source':benchmark.digest(benchmark.ARENA/'bots'/n/'src'),'wasm':sha(benchmark.build(n))} for n in ['v111',*parents.values()]},
              'maps':{str(p.relative_to(BASE)):sha(p) for p in maps},'styles':list(STYLES),
              'scope':'Diagnostic12map panel selected from known failure geometry plus four previously used synthetic cases. On/off pairs identical in every non-custom/non-data Wasm section. Raw parents measure scaffold footprint. No official actions, no strength claim from this pilot.'}
        frozen=WD/'frozen-plan.json'
        if frozen.exists():assert read(frozen)==plan
        else:save(frozen,plan)
        status(phase='Matched mechanism pilot',workers=16)
        label=ID+'-pilot';rows=read(DATA/'benchmarks'/label/'results.json') if (DATA/'benchmarks'/label/'results.json').exists() else benchmark.run(label,names,maps,STYLES)
        result=audit(label,8);save(DATA/'benchmarks'/label/'both-team-audit.json',result)
        reports={n:benchmark.compare(rows,n) for n in names if n!='v111'}
        save(WD/'outcomes.json',reports)
        assert sha(__file__)==plan['script_sha256']
        for n,spec in {**identities,**plan['parents']}.items():
            assert benchmark.digest(benchmark.ARENA/'bots'/n/'src')==spec['source'] and sha(benchmark.build(n))==spec['wasm']
        print(json.dumps(reports),flush=True)

if __name__=='__main__':main()
