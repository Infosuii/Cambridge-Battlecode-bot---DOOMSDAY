"""Complete the frozen 48-map comparison, running absent raw controls explicitly."""
from pathlib import Path
import hashlib
import itertools
import json
import sys
import confirm_contested_capture as prior

BASE = prior.BASE
benchmark = prior.benchmark
DATA = prior.DATA
save = prior.save
ID = 'contested-capture-confirm-v2-20261108'
WD = BASE / 'training/runs' / ID


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def controls(maps):
    """Reuse exact artifacts, but never assume replacement maps were already played."""
    wanted = set(maps.values())
    cells, receipts = {}, []
    labels = ['bounded-delivery-retune-20261107-' + s for s in
              ('o-train', 'l-train', 'o-fresh', 'l-fresh', 'final_a', 'final_b', 'published')]
    labels += ['delivery-parent-diagnostic-20261108-' + s for s in
               ('final_a', 'final_b', 'published')]
    expected = {n: sha(benchmark.build(n)) for n in set(prior.RAW) | set(prior.STYLES)}
    for label in labels:
        root = DATA / 'benchmarks' / label
        manifest = read(root / 'manifest.json')
        results = root / 'results.json'
        assert read(root / 'both-team-audit.json')['results_sha256'] == sha(results)
        receipts.append({'label': label, 'results_sha256': sha(results)})
        hashes = {Path(p).stem: h for p, h in manifest['maps'].items()}
        for row in read(results):
            if row['candidate'] not in prior.RAW or hashes[row['map']] not in wanted:
                continue
            assert all(manifest['wasm_hashes'][n] == expected[n]
                       for n in (row['candidate'], row['opponent']))
            key = (row['candidate'], row['opponent'], row['map'], row['side'])
            if key in cells:
                assert all(cells[key][k] == row[k] for k in ('score', 'faults', 'fuel_exhaustions'))
            else:
                cells[key] = row
    required = set(itertools.product(prior.RAW, prior.STYLES,
                                    [Path(p).stem for p in maps], ('a', 'b')))
    assert set(cells) <= required
    missing_maps = sorted({key[2] for key in required - set(cells)})
    return cells, receipts, missing_maps, required


def main():
    assert read(prior.repair.WD / 'runtime.json')['status'] == 'complete'
    with prior.lease(WD, ID) as status:
        benchmark.CONFIG['jobs'] = 16
        variants = read(prior.repair.WD / 'frozen-plan.json')['variants']
        maps, strata, replacements = prior.choose_maps()
        for n, identity in variants.items():
            assert benchmark.digest(benchmark.ARENA / 'bots' / n / 'src') == identity['source']
            assert sha(benchmark.build(n)) == identity['wasm']
        cached, receipts, missing, required = controls(maps)
        dependencies = [Path(__file__), Path(prior.__file__), Path(prior.repair.__file__),
                        Path(prior.repair.original.__file__), Path(__file__).parent / 'published_pool.py']
        plan = {'dependencies': {str(p): sha(p) for p in dependencies},
                'variants': variants, 'maps': maps, 'strata': strata,
                'replacements': replacements, 'cached_controls': len(cached),
                'missing_control_maps': missing, 'cache_receipts': receipts,
                'cli_sha256': sha(prior.CLI), 'sdk': benchmark.digest(benchmark.ARENA / 'sdk/cpp'),
                'scope': 'Same prospective 48-map selector and immutable repair as failed preparation. '
                         'Run absent raw-control map panels instead of assuming a full cache. '
                         'No candidate outcome has been seen on this panel. Older project exposure remains. '
                         'No official actions; further frozen validation required for promotion.'}
        frozen = WD / 'frozen-plan.json'
        if frozen.exists():
            assert read(frozen) == plan
        else:
            save(frozen, plan)
        if missing:
            status(phase='Running missing raw controls', maps=len(missing), cached=len(cached))
            label = ID + '-raw'
            root = DATA / 'benchmarks' / label
            rows = read(root / 'results.json') if (root / 'results.json').exists() else benchmark.run(
                label, prior.RAW, [BASE / p for p in maps if Path(p).stem in missing], prior.STYLES)
            save(root / 'both-team-audit.json', prior.audit(label, 8))
            for row in rows:
                key = (row['candidate'], row['opponent'], row['map'], row['side'])
                if key in cached:
                    assert all(cached[key][k] == row[k] for k in ('score', 'faults', 'fuel_exhaustions'))
                else:
                    cached[key] = row
        assert set(cached) == required
        status(phase='Forty-eight-map on/off confirmation', workers=16)
        label = ID + '-new'
        root = DATA / 'benchmarks' / label
        rows = read(root / 'results.json') if (root / 'results.json').exists() else benchmark.run(
            label, list(variants), [BASE / p for p in maps], prior.STYLES)
        save(root / 'both-team-audit.json', prior.audit(label, 8))
        combined = rows + list(cached.values())
        target = DATA / 'benchmarks' / (ID + '-combined')
        manifest = read(root / 'manifest.json')
        manifest['candidates'] = list(variants) + prior.RAW
        manifest['wasm_hashes'].update({n: sha(benchmark.build(n)) for n in prior.RAW})
        if (target / 'results.json').exists():
            assert read(target / 'results.json') == combined
        else:
            save(target / 'manifest.json', manifest)
            save(target / 'results.json', combined)
        save(target / 'lineage.json', {'new': label, 'cached': receipts, 'missing_raw': ID + '-raw'})
        save(target / 'both-team-audit.json', prior.audit(target.name, 8))
        status(phase='Computing frozen comparisons and uncertainty')
        reports = {n: {'comparison': benchmark.compare(combined, n),
                       'reference_cluster95': prior.reference_ci(combined, n),
                       'direct_cluster95': prior.direct_ci(combined, n)}
                   for n in list(variants) + prior.RAW[1:]}
        save(WD / 'outcomes.json', reports)
        assert all(sha(p) == h for p, h in plan['dependencies'].items())
        assert sha(prior.CLI) == plan['cli_sha256']
        assert benchmark.digest(benchmark.ARENA / 'sdk/cpp') == plan['sdk']
        assert all(sha(BASE / p) == h for p, h in maps.items())
        for n, identity in variants.items():
            assert benchmark.digest(benchmark.ARENA / 'bots' / n / 'src') == identity['source']
            assert sha(benchmark.build(n)) == identity['wasm']
        print(json.dumps(reports), flush=True)


if __name__ == '__main__':
    main()
