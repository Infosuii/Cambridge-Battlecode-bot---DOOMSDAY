"""Instrumented branch tracing only; require observed parity before attribution."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile
BASE=Path(r'C:\projects\cambridge battlecode\work\agentic-improvement')
sys.path.insert(0,str(BASE/'autonomy'))
import benchmark
from native_capture import validate
from store import DATA,CLI,save
ROOT=DATA/'experiments/direct-regressions-v112-20261108/vault-probe'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    case=next(r for r in read(ROOT.parent/'selected.json') if r['map']=='published/00vault')
    name='probe_vault_wait_l1';anchor='auto_bank_arrive_learned'
    marker='    drop_ward();\n'
    trace='''    if (round >= 20 && round <= 100) {
        int gv = -1, gd = -1; float gh = -1;
        if (target_group >= 0 && target_group < static_cast<int>(w.groups.size())) {
            const auto& pg = w.groups[target_group];
            gv = static_cast<int>(pg.state); gh = pg.hp_left(w.camps);
            gd = pg.camps.empty() ? -1 : cheb(w.camps[pg.camps[0]].pos, pos);
        }
        std::printf("VW %d %d %s %d %d %d %d %.1f %d %d %.1f %d %d %d %d %d\\n", round, slot, mode,
            pos.x, pos.y, gems, gold, static_cast<double>(hp), target_group, gv, static_cast<double>(gh), gd,
            staging_since, staging_walk_since, cast_done?1:0, walked?1:0);
    }
'''
    # Existing dist helper is source-specific; use only fields already present
    # in the normal turn, without adding a new pathfinding query.
    patch={'path':'bot.cpp','old':marker,'new':trace+marker}
    if not (benchmark.ARENA/'bots'/name/'src').exists():benchmark.make(name,template=anchor,changes=[patch])
    src=benchmark.ARENA/'bots'/name/'src';parent=benchmark.ARENA/'bots'/anchor/'src'
    for p in parent.iterdir():
        if p.is_file():
            expected=p.read_text(encoding='utf-8').replace(marker,trace+marker) if p.name=='bot.cpp' else None
            assert (src/p.name).read_text(encoding='utf-8')==expected if expected is not None else (src/p.name).read_bytes()==p.read_bytes()
    native=ROOT/'native.json';folder=ROOT/'replay'
    if not native.exists():
        builds=[benchmark.build('v111'),benchmark.build(name)]
        with (ROOT/'run.log').open('w',encoding='utf-8') as log:
            subprocess.run([str(CLI),'run',*[str(p) for p in builds],'--map',str(benchmark.ARENA/'maps/00vault.map26a'),
                            '--release','--log-limit','8388608','-o',str(folder),'--statistics',str(native),'--json'],cwd=benchmark.ARENA,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    d=read(native);assert all(validate(d,t,'3.0.0')==0 for t in ('teamA','teamB')) and not d['diagnostics']['codes']
    with zipfile.ZipFile(next(folder.glob('*.repl26a'))) as z:out=z.read('team-b.stdout').replace(b'\0',b'\n').decode('utf-8',errors='replace')
    lines=[s for s in out.splitlines() if s.startswith('VW ')];(ROOT/'trace.txt').write_text('\n'.join(lines),encoding='utf-8')
    original=read(case['file']);report={'native_identical':sha(native)==sha(case['file']),'outcome':d['match']['outcome'],
           'original_outcome':original['match']['outcome'],'source':benchmark.digest(src),'wasm':sha(benchmark.build(name)),
           'modes':{str(slot):dict(__import__('collections').Counter(s.split()[3] for s in lines if int(s.split()[2])==slot)) for slot in range(4)},
           'scope':'Instrumented normal release trace; changes code/fuel. Branch observations are diagnostic, not strength evidence. Native equality is checked separately.'}
    save(ROOT/'report.json',report);print(json.dumps(report));print('\n'.join(lines[:12]))

if __name__=='__main__':main()
