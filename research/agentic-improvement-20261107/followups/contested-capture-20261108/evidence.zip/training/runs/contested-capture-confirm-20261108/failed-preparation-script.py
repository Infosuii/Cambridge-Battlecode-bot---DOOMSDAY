"""Forty-eight-map mechanism confirmation; reuse exact frozen raw controls."""
from pathlib import Path
import hashlib
import json
import random
import re
import sys
import contested_capture_repair as repair
BASE=repair.BASE
sys.path.insert(0,str(BASE/'autonomy'));sys.path.insert(0,str(BASE))
import benchmark
from native_job import lease
from parallel_native_audit import run as audit
from store import DATA,CLI,save
from representative_search import STYLES
from bounded_delivery_retune import direct_ci,reference_ci
from published_pool import verified_pool,canonical

ID='contested-capture-confirm-20261108'
WD=BASE/'training/runs/contested-capture-confirm-20261108'
RAW=['v111','auto_bank_arrive_original','auto_bank_arrive_learned']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def choose_maps():
    data=read(DATA/'experiments/bounded-retune-data-20261107/data-plan.json')
    maps=dict(data['roles']['fresh']);strata=dict(data['strata']['fresh'])
    pilot=read(repair.original.WD/'frozen-plan.json');used=set(pilot['maps'].values())
    catalog=read(DATA/'experiments/bounded-delivery-retune-20261107-platform-spotcheck/live-map-catalog.json')
    official=verified_pool(benchmark.ARENA/'maps',Path(__file__).resolve().parent/'live-map-audit-20261108/maps',catalog['maps'])
    cpp=(benchmark.ARENA/'bots/auto_bank_arrive_original/src/bot.cpp').read_text(encoding='utf-8');a=cpp.index('kRows[]');b=cpp.index('for (const auto& r : kRows)',a)
    named={canonical(s) for s in re.findall(r'//\s+([^:\s]+):',cpp[a:b])}
    replacements=[];rng=random.Random(611911607)
    for p,h in list(maps.items()):
        if h not in used:continue
        kind=strata[p];assert kind in ('named_profile','other_published')
        candidates=[r for r in official if r['sha256'] not in used|set(maps.values()) and (canonical(r['name']) in named)==(kind=='named_profile')]
        selected=rng.choice(sorted(candidates,key=lambda r:r['name']));new=str(Path(selected['file']).relative_to(BASE))
        del maps[p];del strata[p];maps[new]=selected['sha256'];strata[new]=kind
        replacements.append({'old':p,'new':new,'reason':'Feature-pilot exposure exclusion; geometry/catalog stratum only, no outcome used'})
    assert len(maps)==len(set(maps.values()))==48 and not set(maps.values())&used
    return maps,strata,replacements

def cached_controls(maps):
    wanted=set(maps.values());cells={};receipts=[]
    labels=['bounded-delivery-retune-20261107-'+s for s in ('o-train','l-train','o-fresh','l-fresh','final_a','final_b','published')]
    labels+=['delivery-parent-diagnostic-20261108-'+s for s in ('final_a','final_b','published')]
    expected={n:sha(benchmark.build(n)) for n in RAW}
    for label in labels:
        root=DATA/'benchmarks'/label;manifest=read(root/'manifest.json');path=root/'results.json'
        assert read(root/'both-team-audit.json')['results_sha256']==sha(path)
        receipts.append({'label':label,'results_sha256':sha(path)})
        hashes={Path(p).stem:h for p,h in manifest['maps'].items()}
        for r in read(path):
            if r['candidate'] not in RAW or hashes[r['map']] not in wanted:continue
            assert manifest['wasm_hashes'][r['candidate']]==expected[r['candidate']]
            assert manifest['wasm_hashes'][r['opponent']]==sha(benchmark.build(r['opponent']))
            key=(r['candidate'],r['opponent'],hashes[r['map']],r['side'])
            if key in cells:
                assert all(cells[key][k]==r[k] for k in ('score','faults','fuel_exhaustions'))
            else:cells[key]=r
    assert len(cells)==3*48*18
    return list(cells.values()),receipts

def main():
    assert read(repair.WD/'runtime.json')['status']=='complete'
    with lease(WD,ID) as status:
        benchmark.CONFIG['jobs']=16
        variants=read(repair.WD/'frozen-plan.json')['variants'];maps,strata,replacements=choose_maps()
        status(phase='Verifying frozen sources and exact cached raw controls')
        for n,s in variants.items():assert benchmark.digest(benchmark.ARENA/'bots'/n/'src')==s['source'] and sha(benchmark.build(n))==s['wasm']
        cached,cache_receipts=cached_controls(maps)
        plan={'script_sha256':sha(__file__),'map_selector_sha256':sha(Path(__file__).resolve().parent/'published_pool.py'),
              'variants':variants,'maps':maps,'strata':strata,'replacements':replacements,'cache_receipts':cache_receipts,
              'cli_sha256':sha(CLI),'sdk':benchmark.digest(benchmark.ARENA/'sdk/cpp'),
              'scope':'48maps unplayed by this repair family:24current-official published (12named proxy/12other) plus24prior synthetic across five families. Some maps have older project exposure; not globally unseen. No parameter search or official actions. Qualify for further frozen validation, not promote on this panel alone.'}
        frozen=WD/'frozen-plan.json'
        if frozen.exists():assert read(frozen)==plan
        else:save(frozen,plan)
        status(phase='Forty-eight-map on/off confirmation',workers=16)
        label=ID+'-new';root=DATA/'benchmarks'/label
        rows=read(root/'results.json') if (root/'results.json').exists() else benchmark.run(label,list(variants),[BASE/p for p in maps],STYLES)
        save(root/'both-team-audit.json',audit(label,8))
        combined=rows+cached;target=DATA/'benchmarks'/(ID+'-combined');manifest=read(root/'manifest.json')
        manifest['candidates']=list(variants)+RAW
        manifest['wasm_hashes'].update({n:sha(benchmark.build(n)) for n in RAW})
        if (target/'results.json').exists():assert read(target/'results.json')==combined
        else:save(target/'manifest.json',manifest);save(target/'results.json',combined)
        save(target/'lineage.json',{'new':label,'cached':cache_receipts})
        save(target/'both-team-audit.json',audit(target.name,8))
        reports={n:{'comparison':benchmark.compare(combined,n),'reference_cluster95':reference_ci(combined,n),'direct_cluster95':direct_ci(combined,n)} for n in list(variants)+RAW[1:]}
        save(WD/'outcomes.json',reports)
        assert sha(__file__)==plan['script_sha256'] and sha(CLI)==plan['cli_sha256']
        assert all(sha(BASE/p)==h for p,h in maps.items())
        for n,s in variants.items():assert benchmark.digest(benchmark.ARENA/'bots'/n/'src')==s['source'] and sha(benchmark.build(n))==s['wasm']
        print(json.dumps(reports),flush=True)

if __name__=='__main__':main()
